
// src/lib/bestQualifiers.ts
import type { GeneratedMatch, TournamentTeam } from '@/types/tournament';
import { calculateFftGroupStandings, type FftGroupStanding } from '@/lib/fftStandings';

export type GroupForBest = {
  name: string;
  teamIds: string[];
  orderedTeamIds?: string[];
};

export type BestPlacementCandidate = {
  groupName: string;
  position: number;
  team: TournamentTeam;
  standing: Pick<
    FftGroupStanding,
    'played' | 'wins' | 'losses' | 'setsWon' | 'setsLost' | 'setsDiff' | 'gamesWon' | 'gamesLost' | 'gamesDiff' | 'points'
  >;
  reason: string;
};

export function selectBestPlacementsAcrossGroups(args: {
  position: number;
  count: number;
  groups: GroupForBest[];
  teams: TournamentTeam[];
  matches: GeneratedMatch[];
}): { selected: BestPlacementCandidate[]; candidates: BestPlacementCandidate[] } {
  const { position, count, groups, teams, matches } = args;

  const candidates: BestPlacementCandidate[] = [];

  for (const g of groups) {
    const standings = calculateFftGroupStandings(g.teamIds, teams, matches);
    const idx = Math.max(0, position - 1);
    const s = standings[idx];
    if (!s) continue;

    candidates.push({
      groupName: g.name,
      position,
      team: s.team,
      standing: {
        played: s.played,
        wins: s.wins,
        losses: s.losses,
        setsWon: s.setsWon,
        setsLost: s.setsLost,
        setsDiff: s.setsDiff,
        gamesWon: s.gamesWon,
        gamesLost: s.gamesLost,
        gamesDiff: s.gamesDiff,
        points: s.points,
      },
      reason: `Comparaison inter-poules (place ${position}) : points > diff sets > diff jeux`,
    });
  }

  const sorted = [...candidates].sort((a, b) => {
    if (b.standing.points !== a.standing.points) return b.standing.points - a.standing.points;
    if (b.standing.setsDiff !== a.standing.setsDiff) return b.standing.setsDiff - a.standing.setsDiff;
    if (b.standing.gamesDiff !== a.standing.gamesDiff) return b.standing.gamesDiff - a.standing.gamesDiff;
    if (b.standing.wins !== a.standing.wins) return b.standing.wins - a.standing.wins;
    if (a.groupName !== b.groupName) return a.groupName.localeCompare(b.groupName);
    return a.team.id.localeCompare(b.team.id);
  });

  return {
    candidates: sorted,
    selected: sorted.slice(0, Math.max(0, count)),
  };
}
