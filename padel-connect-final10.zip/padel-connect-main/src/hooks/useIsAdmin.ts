import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function useIsAdmin() {
  return useQuery({
    queryKey: ['admin', 'isAdmin'],
    queryFn: async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const user = sessionData.session?.user;
      if (!user) return { isAdmin: false };

      const { data, error } = await supabase
        .from('admin_users')
        .select('user_id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) return { isAdmin: false };
      return { isAdmin: !!data };
    },
    staleTime: 30_000,
  });
}
