// FFT categories supported by the platform: P25, P50, P100, P250
// (Higher categories like P500+ are intentionally out of scope for this product.)
export type CategoryCode = 'P25' | 'P50' | 'P100' | 'P250';
export type Gender = 'H' | 'F' | 'Mixte';
export type UserRole = 'player' | 'club_admin' | 'admin';

export interface Club {
  id: string;
  name: string;
  email: string;
  address: string;
  city: string;
  postal_code: string;
  region: string;
  created_at: string;
  updated_at: string;
}

export interface Tournament {
  id: string;
  club_id: string | null;
  club?: Club;
  title: string;
  description: string;
  address: string;
  city: string;
  postal_code: string;
  region: string;
  category_code: CategoryCode;
  gender: Gender;
  start_date: string;
  end_date: string;
  max_teams: number;
  official_registration_url: string | null;
  is_managed_by_platform: boolean;
  created_at: string;
  updated_at: string;
  registrations_count?: number;
  latitude?: number;
  longitude?: number;
  image_url?: string | null;
  referee_name?: string | null;
  price?: number | null;
}

export interface Registration {
  id: string;
  tournament_id: string;
  team_name: string | null;
  player1_name: string;
  player2_name: string;
  player1_email: string;
  player2_email: string;
  created_at: string;
  updated_at: string;
}

export interface User {
  id: string;
  email: string;
  role: UserRole;
}

export interface TournamentFilters {
  region?: string;
  city?: string;
  start_date?: string;
  end_date?: string;
  category?: CategoryCode;
  gender?: Gender;
  max_distance?: number;
}

export interface Match {
  match: number;
  teamA: string;
  teamB: string;
}

export interface AuthState {
  club: Club | null;
  isAuthenticated: boolean;
}
