import { Database } from '@/integrations/supabase/types';

// Tournament format types
export type TournamentFormat = 'knockout' | 'groups_knockout' | 'round_robin' | 'direct_entry';
export type DrawSizeMode = 'auto' | 'manual';
export type TeamStatus = 'confirmed' | 'pending' | 'waiting';
export type GameFormat = Database['public']['Enums']['game_format'];

export interface ClubTournament {
  id: string;
  club_id: string;
  title: string;
  description?: string;
  start_date: string;
  /** Optional local start time (HH:MM). If not set, assume 09:00. */
  start_time?: string;
  end_date: string;
  registration_deadline?: string;
  location?: string;
  city?: string;
  region?: string;
  latitude?: number;
  longitude?: number;
  category_code?: string;
  gender?: string;
  max_teams?: number;
  price?: number;
  /** Refund window in hours before tournament start (e.g. 24, 48). */
  refund_deadline_hours?: number;
  /** Optional organiser-provided note about refunds (fees, exceptions, etc.). */
  refund_policy_text?: string;
  image_url?: string;
  referee_name?: string;
  referee_level?: string;
  format: TournamentFormat;
  draw_size_mode: DrawSizeMode;
  draw_size_manual?: number;
  final_draw_size?: number;
  seeds_direct_count: number;
  group_size: number;
  /** If true, organiser can define uneven group sizes via group_sizes_csv (e.g. "4,4,3"). */
  use_custom_groups?: boolean;
  /** CSV list of group sizes, used when use_custom_groups is true. */
  group_sizes_csv?: string;
  qualifiers_per_group: number;
  /** Optional: number of additional qualifiers across groups (e.g. best 2nd / best 3rd). */
  extra_qualifiers_count?: number;
  /** Optional: placement for additional qualifiers (2 => best 2nd, 3 => best 3rd). */
  extra_qualifiers_position?: number;
  byes_priority_for_seeds: boolean;
  draw_generated: boolean;
  draw_locked: boolean;
  random_seed?: number;
  game_format?: GameFormat;
  created_at: string;
  updated_at: string;
}

export type PaymentStatus = 'pending' | 'paid';

export interface TournamentTeam {
  id: string;
  tournament_id: string;
  name: string;
  player1_name: string;
  player1_email?: string;
  player2_name?: string;
  player2_email?: string;
  seed_rank?: number;
  status: TeamStatus;
  slot_position?: number;
  player1_payment_status?: PaymentStatus;
  player2_payment_status?: PaymentStatus;
  player1_has_license?: boolean;
  player2_has_license?: boolean;
  created_at: string;
  updated_at: string;
}

export interface TournamentGroup {
  id: string;
  tournament_id: string;
  name: string;
  group_order: number;
  created_at: string;
}

export interface GroupTeam {
  id: string;
  group_id: string;
  team_id: string;
  points: number;
  matches_played: number;
  matches_won: number;
  matches_lost: number;
  sets_won: number;
  sets_lost: number;
  games_won: number;
  games_lost: number;
  ranking_position?: number;
  team?: TournamentTeam;
}

export interface TournamentMatch {
  id: string;
  tournament_id: string;
  group_id?: string;
  round_name: string;
  round_order: number;
  match_order: number;
  team_a_id?: string;
  team_b_id?: string;
  is_bye: boolean;
  score_a?: string;
  score_b?: string;
  winner_id?: string;
  next_match_id?: string;
  slot_index?: number;
  started_at?: string;
  completed_at?: string;
  created_at: string;
  updated_at: string;
  team_a?: TournamentTeam;
  team_b?: TournamentTeam;
}

// Draw generation types
export interface DrawSlot {
  position: number;
  team_id?: string;
  is_bye: boolean;
  seed_rank?: number;
}

export interface DrawResult {
  slots: DrawSlot[];
  matches: GeneratedMatch[];
  rounds: RoundInfo[];
}

export interface GeneratedMatch {
  id?: string;
  round_name: string;
  round_order: number;
  match_order: number;
  slot_a: number;
  slot_b: number;
  team_a_id?: string;
  team_b_id?: string;
  is_bye: boolean;
  winner_id?: string;
  score_a?: string;
  score_b?: string;
  /**
   * FFT (P25 -> P500): affects group standings points.
   * - normal: standard match result
   * - wo: walkover / forfait (loser gets -2 pts in group standings)
   * - dq: disqualification (loser gets -1 pt in group standings)
   * - not_played: no result (does not count)
   */
  result_type?: 'normal' | 'wo' | 'dq' | 'not_played';
  /** Optional: was the WO justified (informational / audit) */
  wo_justified?: boolean | null;
  /** Optional admin note for referee decisions */
  admin_note?: string | null;
}

export interface RoundInfo {
  name: string;
  order: number;
  match_count: number;
}

export interface GroupResult {
  groups: GroupInfo[];
  matches: GeneratedMatch[];
  exemptSeeds?: string[];
  finalBracket?: DrawResult;
}

export interface GroupInfo {
  name: string;
  order: number;
  team_ids: string[];
}

// CSV import type
export interface CSVTeamRow {
  name: string;
  player1_name: string;
  player1_email?: string;
  player2_name?: string;
  player2_email?: string;
  seed_rank?: number;
}