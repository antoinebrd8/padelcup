import { TournamentTeam, DrawSlot, DrawResult, GeneratedMatch, RoundInfo, GroupResult, GroupInfo, ClubTournament } from '@/types/tournament';

// Seeded random number generator for deterministic draws
class SeededRandom {
  private seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  next(): number {
    this.seed = (this.seed * 1103515245 + 12345) & 0x7fffffff;
    return this.seed / 0x7fffffff;
  }

  shuffle<T>(array: T[]): T[] {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }
}

// Get next power of 2 >= n
function nextPowerOf2(n: number): number {
  let power = 1;
  while (power < n) {
    power *= 2;
  }
  return power;
}

// Get round name based on remaining teams
function getRoundName(drawSize: number, roundOrder: number): string {
  const remaining = drawSize / Math.pow(2, roundOrder);
  if (remaining === 2) return 'Finale';
  if (remaining === 4) return 'Demi-finales';
  if (remaining === 8) return 'Quarts de finale';
  if (remaining === 16) return '1/8e de finale';
  if (remaining === 32) return '1/16e de finale';
  if (remaining === 64) return '1/32e de finale';
  if (remaining === 128) return '1/64e de finale';
  return `Tour ${roundOrder + 1}`;
}

/**
 * Standard seed placement positions following tennis/padel seeding rules.
 * TDS1 at top, TDS2 at bottom, TDS3/4 in opposite halves, etc.
 * This ensures top seeds don't meet until late rounds.
 */
function getSeedPositions(drawSize: number): number[] {
  if (drawSize === 2) return [0, 1];
  if (drawSize === 4) return [0, 3, 2, 1];
  if (drawSize === 8) return [0, 7, 4, 3, 2, 5, 6, 1];
  if (drawSize === 16) {
    // Standard 16-draw seeding: 1,16,8,9,4,13,5,12,2,15,7,10,3,14,6,11
    // Positions: TDS1→0, TDS2→15, TDS3→8, TDS4→7, TDS5→4, TDS6→11, TDS7→12, TDS8→3
    return [0, 15, 8, 7, 4, 11, 12, 3, 2, 13, 10, 5, 6, 9, 14, 1];
  }
  if (drawSize === 32) {
    // Standard 32-draw seeding positions
    return [0, 31, 16, 15, 8, 23, 24, 7, 4, 27, 20, 11, 12, 19, 28, 3,
            2, 29, 18, 13, 10, 21, 26, 5, 6, 25, 22, 9, 14, 17, 30, 1];
  }
  if (drawSize === 64) {
    // Standard 64-draw seeding positions
    return [0, 63, 32, 31, 16, 47, 48, 15, 8, 55, 40, 23, 24, 39, 56, 7,
            4, 59, 36, 27, 20, 43, 52, 11, 12, 51, 44, 19, 28, 35, 60, 3,
            2, 61, 34, 29, 18, 45, 50, 13, 10, 53, 42, 21, 26, 37, 58, 5,
            6, 57, 38, 25, 22, 41, 54, 9, 14, 49, 46, 17, 30, 33, 62, 1];
  }
  
  // For larger sizes, build recursively
  const positions: number[] = [0, drawSize - 1];
  let seeds = 2;
  
  while (seeds < drawSize) {
    const newPositions: number[] = [];
    const sectionSize = drawSize / seeds;
    
    for (let i = 0; i < positions.length; i++) {
      const pos = positions[i];
      const section = Math.floor(pos / sectionSize);
      const sectionStart = section * sectionSize;
      const sectionEnd = sectionStart + sectionSize - 1;
      
      newPositions.push(pos);
      if (pos === sectionStart) {
        newPositions.push(sectionEnd);
      } else {
        newPositions.push(sectionStart);
      }
    }
    
    positions.length = 0;
    positions.push(...newPositions);
    seeds *= 2;
  }
  
  return positions.slice(0, drawSize);
}

/**
 * Get standard matchup structure for a given draw size.
 * Returns the seed/ranking positions that should be placed at each slot.
 * Following standard tennis bracket logic where:
 * - In 16-draw: TDS1 vs E16, TDS8 vs E9, TDS4 vs E13, etc.
 * - Byes go to top seeds when teams < draw size
 */
function getStandardBracketOrder(drawSize: number): number[] {
  // This returns the ranking position that should go at each slot
  // For 16-draw: [1,16,9,8,5,12,13,4,3,14,11,6,7,10,15,2]
  // Meaning slot 0 = seed 1, slot 1 = seed 16, slot 2 = seed 9, etc.
  
  if (drawSize === 2) return [1, 2];
  if (drawSize === 4) return [1, 4, 3, 2];
  if (drawSize === 8) return [1, 8, 5, 4, 3, 6, 7, 2];
  if (drawSize === 16) {
    return [1, 16, 9, 8, 5, 12, 13, 4, 3, 14, 11, 6, 7, 10, 15, 2];
  }
  if (drawSize === 32) {
    return [
      1, 32, 17, 16, 9, 24, 25, 8, 5, 28, 21, 12, 13, 20, 29, 4,
      3, 30, 19, 14, 11, 22, 27, 6, 7, 26, 23, 10, 15, 18, 31, 2
    ];
  }
  if (drawSize === 64) {
    return [
      1, 64, 33, 32, 17, 48, 49, 16, 9, 56, 41, 24, 25, 40, 57, 8,
      5, 60, 37, 28, 21, 44, 53, 12, 13, 52, 45, 20, 29, 36, 61, 4,
      3, 62, 35, 30, 19, 46, 51, 14, 11, 54, 43, 22, 27, 38, 59, 6,
      7, 58, 39, 26, 23, 42, 55, 10, 15, 50, 47, 18, 31, 34, 63, 2
    ];
  }
  
  // Build recursively for larger sizes
  const order: number[] = [1, drawSize];
  let size = 2;
  
  while (size < drawSize) {
    const newOrder: number[] = [];
    for (let i = 0; i < order.length; i++) {
      const rank = order[i];
      newOrder.push(rank);
      // The complementary rank
      newOrder.push(size * 2 + 1 - rank);
    }
    order.length = 0;
    order.push(...newOrder);
    size *= 2;
  }
  
  return order;
}

// FFT convention (practical): TdS #2 placed in the top half, TdS #1 in the bottom half.
// This guarantees that 1 and 2 cannot meet before the final.
function ensureTopTwoSeedsOppositeHalves(slots: DrawSlot[], drawSize: number) {
  const half = drawSize / 2;
  const idx1 = slots.findIndex(s => s.seed_rank === 1 && s.team_id);
  const idx2 = slots.findIndex(s => s.seed_rank === 2 && s.team_id);
  if (idx1 === -1 || idx2 === -1) return;

  const inTop = (idx: number) => idx < half;

  // If both end up in same half, swap their positions.
  if (inTop(idx1) === inTop(idx2)) {
    const tmp = { team_id: slots[idx1].team_id, seed_rank: slots[idx1].seed_rank };
    slots[idx1].team_id = slots[idx2].team_id;
    slots[idx1].seed_rank = slots[idx2].seed_rank;
    slots[idx2].team_id = tmp.team_id;
    slots[idx2].seed_rank = tmp.seed_rank;
    return;
  }

  // Also enforce orientation: seed #2 in top, seed #1 in bottom.
  if (!inTop(idx2) || inTop(idx1)) {
    const tmp = { team_id: slots[idx1].team_id, seed_rank: slots[idx1].seed_rank };
    slots[idx1].team_id = slots[idx2].team_id;
    slots[idx1].seed_rank = slots[idx2].seed_rank;
    slots[idx2].team_id = tmp.team_id;
    slots[idx2].seed_rank = tmp.seed_rank;
  }
}

// Generate knockout draw with proper seeding
export function generateKnockoutDraw(
  tournament: ClubTournament,
  teams: TournamentTeam[],
  randomSeed?: number
): DrawResult {
  const confirmedTeams = teams.filter(t => t.status === 'confirmed');
  const n = confirmedTeams.length;
  
  if (n < 2) {
    return { slots: [], matches: [], rounds: [] };
  }
  
  // Calculate draw size
  let drawSize: number;
  if (tournament.draw_size_mode === 'manual' && tournament.draw_size_manual) {
    drawSize = tournament.draw_size_manual;
  } else {
    drawSize = nextPowerOf2(n);
  }
  
  // Ensure draw size is at least n and power of 2
  drawSize = Math.max(nextPowerOf2(n), drawSize);
  
  const byes = drawSize - n;
  const rng = new SeededRandom(randomSeed ?? Date.now());
  
  // Separate seeded and unseeded teams
  const seededTeams = confirmedTeams
    .filter(t => t.seed_rank !== null && t.seed_rank !== undefined)
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  const unseededTeams = confirmedTeams.filter(t => t.seed_rank === null || t.seed_rank === undefined);
  
  // Shuffle unseeded teams to assign random ranking positions
  const shuffledUnseeded = rng.shuffle(unseededTeams);
  
  // Create a ranked list: seeded teams first (by seed), then shuffled unseeded
  // This gives us the "ranking" 1 to N where:
  // - Positions 1 to seededTeams.length = seeded teams
  // - Remaining positions = shuffled unseeded teams
  const rankedTeams: (TournamentTeam | null)[] = [];
  
  // Place seeded teams at their seed positions
  for (let i = 0; i < seededTeams.length; i++) {
    const team = seededTeams[i];
    const targetRank = (team.seed_rank ?? i + 1) - 1; // 0-indexed
    while (rankedTeams.length <= targetRank) {
      rankedTeams.push(null);
    }
    rankedTeams[targetRank] = team;
  }
  
  // Fill gaps and add unseeded teams
  let unseededIndex = 0;
  for (let i = 0; i < n; i++) {
    if (i >= rankedTeams.length) {
      rankedTeams.push(shuffledUnseeded[unseededIndex++]);
    } else if (rankedTeams[i] === null) {
      rankedTeams[i] = shuffledUnseeded[unseededIndex++];
    }
  }
  
  // Get the standard bracket order (which ranking goes where)
  const bracketOrder = getStandardBracketOrder(drawSize);
  
  // Initialize slots
  const slots: DrawSlot[] = Array.from({ length: drawSize }, (_, i) => ({
    position: i,
    is_bye: false,
  }));
  
  // Place teams and byes according to standard bracket structure
  // bracketOrder tells us which "ranking" should be at each slot
  // Rankings > n become byes (meaning top seeds get byes)
  
  for (let slotIndex = 0; slotIndex < drawSize; slotIndex++) {
    const requiredRank = bracketOrder[slotIndex]; // 1-indexed ranking for this slot
    
    if (requiredRank <= n) {
      // This slot gets a team
      const team = rankedTeams[requiredRank - 1];
      if (team) {
        slots[slotIndex].team_id = team.id;
        slots[slotIndex].seed_rank = team.seed_rank;
      }
    } else {
      // This slot is a bye (ranking > number of teams)
      slots[slotIndex].is_bye = true;
    }
  }

  // Ensure TdS #1 and #2 are never in the same half (and keep FFT orientation).
  ensureTopTwoSeedsOppositeHalves(slots, drawSize);
  
  // Generate rounds and matches
  const rounds: RoundInfo[] = [];
  const matches: GeneratedMatch[] = [];
  
  let currentSize = drawSize;
  let roundOrder = 0;
  
  while (currentSize >= 2) {
    const matchCount = currentSize / 2;
    const roundName = getRoundName(drawSize, roundOrder);
    
    rounds.push({
      name: roundName,
      order: roundOrder,
      match_count: matchCount,
    });
    
    // Only generate first round matches with team assignments
    if (roundOrder === 0) {
      for (let i = 0; i < matchCount; i++) {
        const slotA = i * 2;
        const slotB = i * 2 + 1;
        const teamA = slots[slotA];
        const teamB = slots[slotB];
        
        const isBye = teamA.is_bye || teamB.is_bye;
        let winnerId: string | undefined;
        
        if (isBye) {
          // Determine winner if one side is bye
          if (teamA.is_bye && teamB.team_id) {
            winnerId = teamB.team_id;
          } else if (teamB.is_bye && teamA.team_id) {
            winnerId = teamA.team_id;
          }
        }
        
        matches.push({
          round_name: roundName,
          round_order: roundOrder,
          match_order: i,
          slot_a: slotA,
          slot_b: slotB,
          team_a_id: teamA.team_id,
          team_b_id: teamB.team_id,
          is_bye: isBye,
          winner_id: winnerId,
        });
      }
    } else {
      // Future rounds - just create placeholder matches
      for (let i = 0; i < matchCount; i++) {
        matches.push({
          round_name: roundName,
          round_order: roundOrder,
          match_order: i,
          slot_a: -1,
          slot_b: -1,
          is_bye: false,
        });
      }
    }
    
    currentSize /= 2;
    roundOrder++;
  }
  
  return { slots, matches, rounds };
}

// Generate direct entry draw (top seeds enter at a later round)
export function generateDirectEntryDraw(
  tournament: ClubTournament,
  teams: TournamentTeam[],
  randomSeed?: number
): DrawResult {
  const confirmedTeams = teams.filter(t => t.status === 'confirmed');
  const finalDrawSize = tournament.final_draw_size ?? 16;
  const directSeeds = tournament.seeds_direct_count ?? 0;
  
  // Direct entry seeds
  const seededTeams = confirmedTeams
    .filter(t => t.seed_rank !== null && t.seed_rank !== undefined && t.seed_rank <= directSeeds)
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  
  // Other teams that need to qualify
  const otherTeams = confirmedTeams.filter(t => !seededTeams.includes(t));
  
  // For simplicity, generate a standard knockout with direct seeds placed at their entry positions
  return generateKnockoutDraw(
    { ...tournament, draw_size_mode: 'manual', draw_size_manual: finalDrawSize },
    confirmedTeams,
    randomSeed
  );
}

// Generate final bracket structure for groups_knockout with exempt seeds
export function generateFinalBracketForGroups(
  tournament: ClubTournament,
  teams: TournamentTeam[],
  numGroups: number,
  randomSeed?: number
): DrawResult {
  const directSeeds = tournament.seeds_direct_count || 0;
  const qualifiersPerGroup = tournament.qualifiers_per_group || 2;
  // Optional extra qualifiers across groups (e.g. "meilleur 2e" / "meilleur 3e").
  const extraQualifiers = (tournament as any).extra_qualifiers_count ? Number((tournament as any).extra_qualifiers_count) : 0;
  const totalFinalTeams = directSeeds + (numGroups * qualifiersPerGroup) + Math.max(0, extraQualifiers);
  
  // Calculate draw size (power of 2)
  const drawSize = nextPowerOf2(totalFinalTeams);
  const byes = drawSize - totalFinalTeams;
  
  const rng = new SeededRandom(randomSeed ?? Date.now());
  
  // Get exempt seeds (TdS who skip groups)
  const seededTeams = teams
    .filter(t => t.status === 'confirmed' && t.seed_rank !== null && t.seed_rank !== undefined && t.seed_rank <= directSeeds)
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  
  // Get bracket order for proper placement
  const bracketOrder = getStandardBracketOrder(drawSize);
  
  // Initialize slots
  const slots: DrawSlot[] = Array.from({ length: drawSize }, (_, i) => ({
    position: i,
    is_bye: false,
  }));
  
  // Build ranked participants list:
  // 1-directSeeds = exempt seeds
  // After that = group qualifiers (placeholders)
  // Rankings > totalFinalTeams = byes
  
  for (let slotIndex = 0; slotIndex < drawSize; slotIndex++) {
    const requiredRank = bracketOrder[slotIndex];
    
    if (requiredRank <= directSeeds) {
      // This slot is for an exempt seed
      const team = seededTeams[requiredRank - 1];
      if (team) {
        slots[slotIndex].team_id = team.id;
        slots[slotIndex].seed_rank = team.seed_rank;
      }
    } else if (requiredRank <= totalFinalTeams) {
      // This slot is for a group qualifier (placeholder)
      slots[slotIndex].is_bye = false;
      // slot stays empty - will be filled after group phase
    } else {
      // This slot is a bye
      slots[slotIndex].is_bye = true;
    }
  }

  // Ensure TdS #1 and #2 are never in the same half (and keep FFT orientation).
  ensureTopTwoSeedsOppositeHalves(slots, drawSize);
  
  // Generate rounds and matches
  const rounds: RoundInfo[] = [];
  const matches: GeneratedMatch[] = [];
  
  let currentSize = drawSize;
  let roundOrder = 0;
  
  while (currentSize >= 2) {
    const matchCount = currentSize / 2;
    const roundName = getRoundName(drawSize, roundOrder);
    
    rounds.push({
      name: roundName,
      order: roundOrder,
      match_count: matchCount,
    });
    
    if (roundOrder === 0) {
      for (let i = 0; i < matchCount; i++) {
        const slotA = i * 2;
        const slotB = i * 2 + 1;
        const teamA = slots[slotA];
        const teamB = slots[slotB];
        
        const isBye = teamA.is_bye || teamB.is_bye;
        let winnerId: string | undefined;
        
        if (isBye) {
          if (teamA.is_bye && teamB.team_id) {
            winnerId = teamB.team_id;
          } else if (teamB.is_bye && teamA.team_id) {
            winnerId = teamA.team_id;
          }
        }
        
        matches.push({
          round_name: roundName,
          round_order: roundOrder,
          match_order: i,
          slot_a: slotA,
          slot_b: slotB,
          team_a_id: teamA.team_id,
          team_b_id: teamB.team_id,
          is_bye: isBye,
          winner_id: winnerId,
        });
      }
    } else {
      for (let i = 0; i < matchCount; i++) {
        matches.push({
          round_name: roundName,
          round_order: roundOrder,
          match_order: i,
          slot_a: -1,
          slot_b: -1,
          is_bye: false,
        });
      }
    }
    
    currentSize /= 2;
    roundOrder++;
  }
  
  return { slots, matches, rounds };
}



// Generate ordered round-robin schedule for a pool (3 to 6 teams supported)
function generatePoolSchedule(teamIds: string[]): Array<[string, string]> {
  const n = teamIds.length;
  // Explicit orders for 3 and 4 (as requested)
  if (n === 3) {
    const [A,B,C] = teamIds;
    return [[A,B],[A,C],[B,C]];
  }
  if (n === 4) {
    const [A,B,C,D] = teamIds;
    return [[A,B],[C,D],[A,C],[B,D],[A,D],[B,C]];
  }

  // Circle method for 5 and 6 (odd: includes a BYE each round)
  const list: Array<string | null> = [...teamIds];
  if (n % 2 === 1) list.push(null); // bye slot
  const size = list.length;
  const rounds = size - 1;
  const schedule: Array<[string,string]> = [];

  // For n=5, we want a specific balanced order close to the user's example.
  // We'll use the circle method but keep the first team fixed to match the example feel.
  let arr = [...list];
  for (let r = 0; r < rounds; r++) {
    // Pairings
    for (let i = 0; i < size/2; i++) {
      const a = arr[i];
      const b = arr[size - 1 - i];
      if (a && b) schedule.push([a,b]);
    }
    // Rotate (keep first fixed)
    const fixed = arr[0];
    const rest = arr.slice(1);
    rest.unshift(rest.pop()!);
    arr = [fixed, ...rest];
  }

  return schedule;
}
// Generate groups + knockout draw
export function generateGroupsKnockoutDraw(
  tournament: ClubTournament,
  teams: TournamentTeam[],
  randomSeed?: number
): GroupResult & { finalBracket?: DrawResult } {
  const confirmedTeams = teams.filter(t => t.status === 'confirmed');
  const n = confirmedTeams.length;
  const groupSize = tournament.group_size || 4;
  const minGroupSize = 3;
  const directSeeds = tournament.seeds_direct_count || 0;
  
  const rng = new SeededRandom(randomSeed ?? Date.now());
  
  // Teams that go to groups (excluding exempt seeds)
  const exemptSeeds = confirmedTeams
    .filter(t => t.seed_rank !== null && t.seed_rank !== undefined && t.seed_rank <= directSeeds)
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  
  const teamsForGroups = confirmedTeams.filter(t => !exemptSeeds.includes(t));
  const numTeamsForGroups = teamsForGroups.length;
  
  // Calculate group sizes
  // If organiser provided custom group sizes (e.g. "4,4,3"), use them.
  const customEnabled = (tournament as any).use_custom_groups;
  const customCsv = ((tournament as any).group_sizes_csv as string | null | undefined) || '';
  let groupSizes: number[] = [];
  if (customEnabled && customCsv.trim()) {
    groupSizes = customCsv
      .split(',')
      .map(s => parseInt(s.trim(), 10))
      // En poules FFT-like, on évite les poules de 2 : minimum 3 équipes.
      .filter(v => Number.isFinite(v) && v >= minGroupSize);
  }

  const computeAutoGroupSizes = (teamsCount: number, targetSize: number, minSize: number): number[] => {
    if (teamsCount <= 0) return [];

    // Petit tournoi : une seule poule
    if (teamsCount <= targetSize) {
      return [Math.max(minSize, Math.min(targetSize, teamsCount))];
    }

    const full = Math.floor(teamsCount / targetSize);
    const remainder = teamsCount % targetSize;
    const sizes: number[] = Array.from({ length: full }, () => targetSize);

    if (remainder === 0) return sizes;
    if (remainder >= minSize) {
      sizes.push(remainder);
      return sizes;
    }

    // remainder = 1 ou 2 -> rééquilibrage
    const needed = minSize - remainder;
    for (let i = 0; i < needed; i++) {
      const idx = sizes.length - 1 - i;
      if (idx < 0) break;
      if (sizes[idx] - 1 < minSize) {
        const alt = sizes.findIndex(s => s - 1 >= minSize);
        if (alt === -1) break;
        sizes[alt] -= 1;
      } else {
        sizes[idx] -= 1;
      }
    }
    sizes.push(minSize);
    return sizes;
  };

  if (!groupSizes.length) {
    groupSizes = computeAutoGroupSizes(numTeamsForGroups, groupSize, minGroupSize);
  }

  // Ensure sizes total matches the number of teams for groups (tolerate organiser input).
  const totalCapacity = groupSizes.reduce((a, b) => a + b, 0);
  if (totalCapacity < numTeamsForGroups) {
    // Add missing spots to last group
    groupSizes[groupSizes.length - 1] += (numTeamsForGroups - totalCapacity);
  } else if (totalCapacity > numTeamsForGroups) {
    // Remove extra spots from the end (do not go below 2)
    let extra = totalCapacity - numTeamsForGroups;
    for (let i = groupSizes.length - 1; i >= 0 && extra > 0; i--) {
      // Ne pas descendre sous la taille mini
      const reducible = Math.max(0, groupSizes[i] - minGroupSize);
      const dec = Math.min(extra, reducible);
      groupSizes[i] -= dec;
      extra -= dec;
    }
  }

  const numGroups = groupSizes.length;
  
  // Separate seeded (non-exempt) and unseeded teams for groups
  const seededTeamsForGroups = teamsForGroups
    .filter(t => t.seed_rank !== null && t.seed_rank !== undefined)
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  const unseededTeams = rng.shuffle(
    teamsForGroups.filter(t => t.seed_rank === null || t.seed_rank === undefined)
  );

  // Helper: compute a "snake" (serpent) fill order across groups, respecting custom capacities.
  // Example with 4 groups: A,B,C,D then D,C,B,A then A,B,C,D ...
  // If capacities differ (e.g. 4,4,3,3), groups that reached capacity are skipped.
  const buildSnakeSlotOrder = (sizes: number[]): number[] => {
    const g = sizes.length;
    const placed = Array.from({ length: g }, () => 0);
    const total = sizes.reduce((a, b) => a + b, 0);
    const order: number[] = [];
    let row = 0;
    while (order.length < total) {
      const seq = row % 2 === 0
        ? Array.from({ length: g }, (_, i) => i)
        : Array.from({ length: g }, (_, i) => g - 1 - i);
      let progressed = false;
      for (const idx of seq) {
        if (placed[idx] < sizes[idx]) {
          order.push(idx);
          placed[idx] += 1;
          progressed = true;
        }
      }
      // Safety: if organiser gave weird sizes (e.g. all zeros), prevent infinite loop
      if (!progressed) break;
      row += 1;
    }
    return order;
  };
  
  // Initialize groups
  const groups: GroupInfo[] = Array.from({ length: numGroups }, (_, i) => ({
    name: `Poule ${String.fromCharCode(65 + i)}`,
    order: i,
    team_ids: [],
  }));

  // Distribute teams into groups.
  // If organiser ranked ALL teams (1..N), use deterministic "serpent" distribution.
  // Otherwise: place seeded teams by rotation and fill the rest randomly.
  const allRankedForGroups = teamsForGroups.length > 0 && teamsForGroups.every(
    t => t.seed_rank !== null && t.seed_rank !== undefined
  );

  if (allRankedForGroups) {
    const slotOrder = buildSnakeSlotOrder(groupSizes);
    const ranked = seededTeamsForGroups;
    for (let i = 0; i < ranked.length; i++) {
      const g = slotOrder[i] ?? (i % numGroups);
      if (groups[g].team_ids.length < groupSizes[g]) {
        groups[g].team_ids.push(ranked[i].id);
      } else {
        // Fallback: find next group with capacity
        const alt = groups.findIndex((gr, idx) => gr.team_ids.length < groupSizes[idx]);
        if (alt !== -1) groups[alt].team_ids.push(ranked[i].id);
      }
    }
  } else {
    // Distribute seeds across groups (simple rotation, respecting capacity)
    let gIdx = 0;
    for (const team of seededTeamsForGroups) {
      let attempts = 0;
      while (attempts < numGroups && groups[gIdx].team_ids.length >= groupSizes[gIdx]) {
        gIdx = (gIdx + 1) % numGroups;
        attempts++;
      }
      groups[gIdx].team_ids.push(team.id);
      gIdx = (gIdx + 1) % numGroups;
    }
  }
  
  // Distribute unseeded teams
  let unseededIndex = 0;
  for (let i = 0; i < groups.length; i++) {
    const group = groups[i];
    const cap = groupSizes[i];
    while (group.team_ids.length < cap && unseededIndex < unseededTeams.length) {
      group.team_ids.push(unseededTeams[unseededIndex].id);
      unseededIndex++;
    }
  }
  
  // Generate group stage matches (round-robin within each group)
  const matches: GeneratedMatch[] = [];

  groups.forEach((group) => {
    const teamIds = group.team_ids;
    const schedule = generatePoolSchedule(teamIds);

    schedule.forEach(([a, b], idx) => {
      matches.push({
        round_name: group.name,
        round_order: 0,
        match_order: idx,
        slot_a: -1,
        slot_b: -1,
        team_a_id: a,
        team_b_id: b,
        is_bye: false,
      });
    });
  });

  // Generate final bracket if there are exempt seeds or groups
  let finalBracket: DrawResult | undefined;
  if (numGroups > 0 || directSeeds > 0) {
    finalBracket = generateFinalBracketForGroups(
      tournament,
      confirmedTeams,
      numGroups,
      randomSeed
    );
  }
  
  return { groups, matches, exemptSeeds: exemptSeeds.map(t => t.id), finalBracket };
}

// Generate round-robin (championship) draw
export function generateRoundRobinDraw(
  teams: TournamentTeam[],
  randomSeed?: number
): GeneratedMatch[] {
  const confirmedTeams = teams.filter(t => t.status === 'confirmed');
  const rng = new SeededRandom(randomSeed ?? Date.now());
  const shuffledTeams = rng.shuffle(confirmedTeams);
  
  const matches: GeneratedMatch[] = [];
  let matchOrder = 0;
  
  // Generate all matches (each team plays each other once)
  for (let i = 0; i < shuffledTeams.length; i++) {
    for (let j = i + 1; j < shuffledTeams.length; j++) {
      matches.push({
        round_name: 'Championnat',
        round_order: 0,
        match_order: matchOrder++,
        slot_a: -1,
        slot_b: -1,
        team_a_id: shuffledTeams[i].id,
        team_b_id: shuffledTeams[j].id,
        is_bye: false,
      });
    }
  }
  
  return matches;
}

// Main draw generation function
export function generateDraw(
  tournament: ClubTournament,
  teams: TournamentTeam[],
  randomSeed?: number
): { knockoutDraw?: DrawResult; groupDraw?: GroupResult; roundRobinMatches?: GeneratedMatch[] } {
  const seed = randomSeed ?? Math.floor(Math.random() * 1000000);
  
  switch (tournament.format) {
    case 'knockout':
      return { knockoutDraw: generateKnockoutDraw(tournament, teams, seed) };
    
    case 'direct_entry':
      return { knockoutDraw: generateDirectEntryDraw(tournament, teams, seed) };
    
    case 'groups_knockout':
      return { groupDraw: generateGroupsKnockoutDraw(tournament, teams, seed) };
    
    case 'round_robin':
      return { roundRobinMatches: generateRoundRobinDraw(teams, seed) };
    
    default:
      return { knockoutDraw: generateKnockoutDraw(tournament, teams, seed) };
  }
}

// Export to CSV
export function exportMatchesToCSV(matches: GeneratedMatch[], teams: TournamentTeam[]): string {
  const teamMap = new Map(teams.map(t => [t.id, t.name]));
  
  const header = 'Match,Round,Team A,Team B,Winner\n';
  const rows = matches.map((m, i) => {
    const teamA = m.team_a_id ? teamMap.get(m.team_a_id) ?? 'TBD' : (m.is_bye ? 'BYE' : 'TBD');
    const teamB = m.team_b_id ? teamMap.get(m.team_b_id) ?? 'TBD' : (m.is_bye ? 'BYE' : 'TBD');
    const winner = m.winner_id ? teamMap.get(m.winner_id) ?? '' : '';
    return `${i + 1},${m.round_name},"${teamA}","${teamB}","${winner}"`;
  }).join('\n');
  
  return header + rows;
}

// Export teams to CSV
export function exportTeamsToCSV(teams: TournamentTeam[]): string {
  const header = 'Name,Player 1,Player 1 Email,Player 2,Player 2 Email,Seed Rank,Status\n';
  const rows = teams.map(t => 
    `"${t.name}","${t.player1_name}","${t.player1_email ?? ''}","${t.player2_name ?? ''}","${t.player2_email ?? ''}",${t.seed_rank ?? ''},${t.status}`
  ).join('\n');
  
  return header + rows;
}

// Parse CSV import
export function parseTeamsCSV(csvContent: string): Array<{
  name: string;
  player1_name: string;
  player1_email?: string;
  player2_name?: string;
  player2_email?: string;
  seed_rank?: number;
  status?: 'confirmed' | 'pending' | 'waiting';
}> {
  const lines = csvContent.trim().split('\n');
  if (lines.length < 2) return [];
  
  // Skip header
  const dataLines = lines.slice(1);
  
  return dataLines.map(line => {
    // Simple CSV parsing (handles quoted fields)
    const fields: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (const char of line) {
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        fields.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    fields.push(current.trim());
    
    return {
      name: fields[0] || '',
      player1_name: fields[1] || '',
      player1_email: fields[2] || undefined,
      player2_name: fields[3] || undefined,
      player2_email: fields[4] || undefined,
      seed_rank: fields[5] ? parseInt(fields[5], 10) : undefined,
      status: (() => {
        const s = (fields[6] || '').trim().toLowerCase();
        return (s === 'confirmed' || s === 'pending' || s === 'waiting') ? (s as any) : undefined;
      })(),
    };
  }).filter(t => t.name && t.player1_name);
}