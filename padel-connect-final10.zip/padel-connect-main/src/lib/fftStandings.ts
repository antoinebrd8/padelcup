import type { GeneratedMatch, TournamentTeam } from '@/types/tournament';

export type FftGroupStanding = {
  team: TournamentTeam;
  played: number;
  wins: number;
  losses: number;
  setsWon: number;
  setsLost: number;
  setsDiff: number;
  gamesWon: number;
  gamesLost: number;
  gamesDiff: number;
  /** FFT poules: 2 victoire / 1 défaite / -1 défaite DQ / -2 défaite WO */
  points: number;
};

type ScoreAgg = { setsA: number; setsB: number; gamesA: number; gamesB: number };

/**
 * Supports both score formats used in the app:
 * - "6/4/0" + "4/6/0" (sets as slash-separated games)
 * - "6-4 6-4" (space-separated sets with dash)
 */
export function parseScoresFlexible(scoreA?: string, scoreB?: string): ScoreAgg {
  const a = (scoreA ?? '').trim();
  const b = (scoreB ?? '').trim();
  if (!a && !b) return { setsA: 0, setsB: 0, gamesA: 0, gamesB: 0 };

  // Slash format: each side is a list of games per set
  if (a.includes('/') || b.includes('/')) {
    const arrA = a ? a.split('/').map(x => parseInt(x, 10) || 0) : [];
    const arrB = b ? b.split('/').map(x => parseInt(x, 10) || 0) : [];
    const len = Math.max(arrA.length, arrB.length);
    let setsA = 0;
    let setsB = 0;
    let gamesA = 0;
    let gamesB = 0;
    for (let i = 0; i < len; i++) {
      const ga = arrA[i] ?? 0;
      const gb = arrB[i] ?? 0;
      gamesA += ga;
      gamesB += gb;
      if (ga > gb) setsA++;
      else if (gb > ga) setsB++;
    }
    return { setsA, setsB, gamesA, gamesB };
  }

  // Dash format: scoreA contains tokens like "6-4" (or any side)
  const tokens = a.split(/\s+/).filter(Boolean);
  let setsA = 0;
  let setsB = 0;
  let gamesA = 0;
  let gamesB = 0;
  for (const t of tokens) {
    const m = t.match(/^(\d+)-(\d+)$/);
    if (!m) continue;
    const ga = parseInt(m[1], 10);
    const gb = parseInt(m[2], 10);
    gamesA += ga;
    gamesB += gb;
    if (ga > gb) setsA++;
    else if (gb > ga) setsB++;
  }
  return { setsA, setsB, gamesA, gamesB };
}

function pointsForLoser(resultType?: GeneratedMatch['result_type']): number {
  if (resultType === 'wo') return -2;
  if (resultType === 'dq') return -1;
  return 1; // normal loss
}

function computeStanding(
  teamId: string,
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  eligibleIds: Set<string>
): FftGroupStanding | null {
  const team = teams.find(t => t.id === teamId);
  if (!team) return null;

  const relevant = matches.filter(m => {
    if (!m.winner_id) return false;
    if (!m.team_a_id || !m.team_b_id) return false;
    if (!eligibleIds.has(m.team_a_id) || !eligibleIds.has(m.team_b_id)) return false;
    return m.team_a_id === teamId || m.team_b_id === teamId;
  });

  let wins = 0;
  let losses = 0;
  let setsWon = 0;
  let setsLost = 0;
  let gamesWon = 0;
  let gamesLost = 0;
  let points = 0;

  for (const match of relevant) {
    const isA = match.team_a_id === teamId;
    const won = match.winner_id === teamId;
    const loserId = won ? (isA ? match.team_b_id! : match.team_a_id!) : teamId;

    if (won) {
      wins++;
      points += 2;
    } else {
      losses++;
      points += pointsForLoser(match.result_type);
    }

    // Only compute sets/games if we have a score; WO/DQ often has none.
    const myScore = isA ? match.score_a : match.score_b;
    const oppScore = isA ? match.score_b : match.score_a;
    const { setsA, setsB, gamesA, gamesB } = parseScoresFlexible(myScore, oppScore);
    setsWon += setsA;
    setsLost += setsB;
    gamesWon += gamesA;
    gamesLost += gamesB;
  }

  return {
    team,
    played: wins + losses,
    wins,
    losses,
    setsWon,
    setsLost,
    setsDiff: setsWon - setsLost,
    gamesWon,
    gamesLost,
    gamesDiff: gamesWon - gamesLost,
    points,
  };
}

export type FftTieBreakOrders = Record<string, string[]>;

function sortWithMiniLeague(
  standings: FftGroupStanding[],
  matches: GeneratedMatch[],
  tieBreakOrders?: FftTieBreakOrders
): FftGroupStanding[] {
  // Initial sort by global criteria
  const baseSorted = [...standings].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.setsDiff !== a.setsDiff) return b.setsDiff - a.setsDiff;
    if (b.gamesDiff !== a.gamesDiff) return b.gamesDiff - a.gamesDiff;
    // draw order (tirage au sort) if provided for that tie block
    if (tieBreakOrders) {
      for (const order of Object.values(tieBreakOrders)) {
        const ia = order.indexOf(a.team.id);
        const ib = order.indexOf(b.team.id);
        if (ia !== -1 && ib !== -1) return ia - ib;
      }
    }
    // fallback deterministic
    return a.team.id.localeCompare(b.team.id);
  });

  // For each tie block, re-apply criteria only within the tied teams.
  const out: FftGroupStanding[] = [];
  let i = 0;
  while (i < baseSorted.length) {
    const start = i;
    const key = baseSorted[i];
    while (
      i < baseSorted.length &&
      baseSorted[i].points === key.points &&
      baseSorted[i].setsDiff === key.setsDiff &&
      baseSorted[i].gamesDiff === key.gamesDiff
    ) {
      i++;
    }
    const block = baseSorted.slice(start, i);
    if (block.length <= 1) {
      out.push(...block);
      continue;
    }

    const ids = new Set(block.map(s => s.team.id));
    const mini = block
      .map(s => computeStanding(s.team.id, block.map(b => b.team), matches, ids))
      .filter(Boolean) as FftGroupStanding[];

    // If mini-league produced something meaningful, sort by mini criteria, then fallback to deterministic.
    mini.sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.setsDiff !== a.setsDiff) return b.setsDiff - a.setsDiff;
      if (b.gamesDiff !== a.gamesDiff) return b.gamesDiff - a.gamesDiff;
      if (tieBreakOrders) {
        for (const order of Object.values(tieBreakOrders)) {
          const ia = order.indexOf(a.team.id);
          const ib = order.indexOf(b.team.id);
          if (ia !== -1 && ib !== -1) return ia - ib;
        }
      }
      return a.team.id.localeCompare(b.team.id);
    });

    // Keep original full stats objects, but ordered as mini
    const fullById = new Map(block.map(s => [s.team.id, s] as const));
    out.push(...mini.map(m => fullById.get(m.team.id)!).filter(Boolean));
  }

  return out;
}

/**
 * FFT-compliant group standings for P25 -> P500.
 * Points: 2 win / 1 loss / -1 loss by DQ / -2 loss by WO
 * Tie-break: points > setsDiff > gamesDiff, then re-apply among tied teams (mini-league).
 */
export function calculateFftGroupStandings(
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  opts?: { tieBreakOrders?: FftTieBreakOrders }
): FftGroupStanding[] {
  const eligibleIds = new Set(groupTeamIds);
  const raw = groupTeamIds
    .map(id => computeStanding(id, teams, matches, eligibleIds))
    .filter(Boolean) as FftGroupStanding[];

  return sortWithMiniLeague(raw, matches, opts?.tieBreakOrders);
}

// Detect tie groups where FFT criteria (including mini-league) still don't separate teams.
// When this happens, FFT allows a "tirage au sort"; the organizer UI can persist a tieBreakOrder
// and pass it back into calculateFftGroupStandings.
export function detectUnresolvedTieGroups(
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  opts?: { tieBreakOrders?: FftTieBreakOrders }
): string[][] {
  const standings = calculateFftGroupStandings(groupTeamIds, teams, matches, opts);
  const out: string[][] = [];
  let current: string[] = [];

  const hasOrderForBoth = (aId: string, bId: string): boolean => {
    const orders = opts?.tieBreakOrders;
    if (!orders) return false;
    return Object.values(orders).some((o) => o.includes(aId) && o.includes(bId));
  };

  for (let i = 0; i < standings.length - 1; i++) {
    const a = standings[i];
    const b = standings[i + 1];
    if (
      a.points === b.points &&
      a.setsDiff === b.setsDiff &&
      a.gamesDiff === b.gamesDiff &&
      !hasOrderForBoth(a.team.id, b.team.id)
    ) {
      if (current.length === 0) current.push(a.team.id);
      if (!current.includes(b.team.id)) current.push(b.team.id);
    } else {
      if (current.length > 1) out.push([...current]);
      current = [];
    }
  }
  if (current.length > 1) out.push([...current]);

  // unique by set
  const uniq = new Map<string, string[]>();
  for (const g of out) uniq.set([...g].sort().join(','), g);
  return [...uniq.values()];
}
