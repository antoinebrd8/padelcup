// src/lib/standingExplanations.ts
import type { GeneratedMatch, TournamentTeam } from '@/types/tournament';
import {
  calculateFftGroupStandings,
  detectUnresolvedTieGroups,
  type FftGroupStanding,
  type FftTieBreakOrders,
} from '@/lib/fftStandings';

export type ExplainedStanding = FftGroupStanding & {
  /** Human readable explanation of why this team is placed above/below others when tied. */
  tie_break_explanation?: string;
};

/**
 * Returns FFT group standings + optional tie-break explanations.
 * - Sorting is delegated to calculateFftGroupStandings (FFT-like rules + mini-league).
 * - When teams remain tied, detectUnresolvedTieGroups flags them. If a tieBreakOrders is provided,
 *   we mention that the order comes from the organizer's draw ("tirage au sort").
 */
export function calculateFftGroupStandingsExplained(
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  opts?: { tieBreakOrders?: FftTieBreakOrders }
): ExplainedStanding[] {
  const standings = calculateFftGroupStandings(groupTeamIds, teams, matches, opts);

  // Build explanation map based on unresolved tie groups
  const tieGroups = detectUnresolvedTieGroups(groupTeamIds, teams, matches, opts);
  if (!tieGroups.length) return standings as ExplainedStanding[];

  const map = new Map<string, string>();

  for (const tg of tieGroups) {
    // If organizer provided an explicit order, we assume it's used to break the tie
    const hasCustomOrder =
      !!opts?.tieBreakOrders &&
      Object.values(opts.tieBreakOrders).some(order => order && order.length && tg.every(id => order.includes(id)));

    const msg = hasCustomOrder
      ? 'Égalité départagée par tirage au sort (ordre saisi par l’organisateur)'
      : 'Égalité non départagée par les critères FFT : tirage au sort requis';

    tg.forEach(id => map.set(id, msg));
  }

  return (standings as ExplainedStanding[]).map(s => ({
    ...s,
    tie_break_explanation: map.get(s.team.id),
  }));
}
