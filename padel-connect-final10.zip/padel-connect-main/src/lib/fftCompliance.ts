import type { CategoryCode, Gender } from '@/types';
import type { GameFormat } from '@/lib/gameFormatConfig';

export type RefereeLevel = 'JAP1' | 'JAP2' | 'JAT3' | 'INTERNATIONAL';

export type FftRuleCheck = {
  errors: string[];
  warnings: string[];
};

// --- Helpers
const parseDateOnly = (d?: string | null): Date | null => {
  if (!d) return null;
  // Stored as YYYY-MM-DD
  const dt = new Date(`${d}T00:00:00`);
  return Number.isNaN(dt.getTime()) ? null : dt;
};

export const daysBetween = (a: Date, b: Date) => {
  const ms = b.getTime() - a.getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24));
};

export const parseRankingPosition = (ranking?: string | null): number | null => {
  if (!ranking) return null;
  const raw = String(ranking).trim().toUpperCase();
  if (!raw) return null;
  if (raw === 'NC' || raw === 'NON CLASSE' || raw === 'NON CLASSÉ') return 999999;
  // Common formats: "1234", "N°1234", "#1234", "1 234"
  const digits = raw.replace(/[^0-9]/g, '');
  if (!digits) return null;
  const n = parseInt(digits, 10);
  return Number.isFinite(n) ? n : null;
};

// --- FFT constraints derived from the 2026 guides
// CUT restrictions: players in the TOP N (inclusive) are forbidden.
// Source: "Les cuts pour les tournois" / CDC Seniors par paires.
// - P25: H TOP 30.000, F TOP 3.000
// - P50: H TOP 10.000, F TOP 1.000
// - P100: H TOP 3.000, F TOP 300
// - P250: H TOP 800, F TOP 100
// For Mixed: same interdictions as H/F for P100 and below; no limitation for P250 Mixed.
export const getCutForCategory = (
  category: CategoryCode | null | undefined,
  gender: Gender | null | undefined
): { menTopInclusive?: number; womenTopInclusive?: number; note?: string } => {
  if (!category || !gender) return {};
  const base = {
    P25: { menTopInclusive: 30000, womenTopInclusive: 3000 },
    P50: { menTopInclusive: 10000, womenTopInclusive: 1000 },
    P100: { menTopInclusive: 3000, womenTopInclusive: 300 },
    P250: { menTopInclusive: 800, womenTopInclusive: 100 },
  } as const;

  const rule = base[category];
  if (gender === 'H') return { menTopInclusive: rule.menTopInclusive };
  if (gender === 'F') return { womenTopInclusive: rule.womenTopInclusive };
  // Mixed
  if (category === 'P250') {
    return { note: 'Mixte P250 : pas de limitation de classement (cut).' };
  }
  // P100 and below: same interdictions for men and women.
  return {
    menTopInclusive: rule.menTopInclusive,
    womenTopInclusive: rule.womenTopInclusive,
  };
};

export const getAllowedGameFormatsForCategory = (category?: CategoryCode | null) => {
  // CDC Seniors par paires:
  // - P25: C1/C2/D1/D2/E/F (E ou F conseillés)
  // - P50/P100/P250: tout sauf E et F
  // Our app stores a single game_format for the tournament; we enforce the strictest constraint here.
  const all: GameFormat[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'D1', 'D2', 'E', 'F', 'G'];
  if (!category) return all;
  if (category === 'P25') return ['C1', 'C2', 'D1', 'D2', 'E', 'F', 'G'];
  if (category === 'P50' || category === 'P100' || category === 'P250') {
    return all.filter(f => f !== 'E' && f !== 'F' && f !== 'G');
  }
  return all;
};

export const getMinTeamsForCategory = (category?: CategoryCode | null, gender?: Gender | null) => {
  // CDC Seniors par paires (min pairs):
  // - P25: H/F/Mix >= 4
  // - P50: H/F/Mix >= 4
  // - P100: F >= 4, H/Mix >= 8
  // - P250: F >= 4, H/Mix >= 12
  if (!category || !gender) return null;
  if (category === 'P25' || category === 'P50') return 4;
  if (category === 'P100') return gender === 'F' ? 4 : 8;
  if (category === 'P250') return gender === 'F' ? 4 : 12;
  return null;
};

export const getRequiredRefereeLevel = (category?: CategoryCode | null): RefereeLevel | null => {
  if (!category) return null;
  // Guide (JAP competence):
  // - JAP1: P25/P50/P100 only
  // - JAP2: P250 (compétence élargie)
  if (category === 'P25' || category === 'P50' || category === 'P100') return 'JAP1';
  if (category === 'P250') return 'JAP2';
  return null;
};

export const compareRefereeLevel = (actual?: RefereeLevel | null, required?: RefereeLevel | null): boolean => {
  if (!required) return true;
  if (!actual) return false;
  const order: RefereeLevel[] = ['JAP1', 'JAP2', 'JAT3', 'INTERNATIONAL'];
  return order.indexOf(actual) >= order.indexOf(required);
};

export const validateTournamentFftCompliance = (args: {
  category?: CategoryCode | null;
  gender?: Gender | null;
  start_date?: string | null;
  registration_deadline?: string | null;
  max_teams?: number | null;
  game_format?: GameFormat | null;
  referee_level?: RefereeLevel | null;
}) : FftRuleCheck => {
  const { category, gender, start_date, registration_deadline, max_teams, game_format, referee_level } = args;
  const errors: string[] = [];
  const warnings: string[] = [];

  // Allowed game formats
  if (category && game_format) {
    const allowed = getAllowedGameFormatsForCategory(category);
    if (!allowed.includes(game_format)) {
      errors.push(`Format de jeu ${game_format} non conforme pour ${category}.`);
    }
    if (game_format === 'G') {
      warnings.push('Format G (meilleur de 3 super tie-breaks) est un format custom (non homologué FFT). À utiliser pour des animations / tournois internes.');
    }
    if (category === 'P25' && (game_format === 'E' || game_format === 'F')) {
      warnings.push('Sur P25, les formats E/F sont possibles (et conseillés), mais attention : la FFT impose aussi des contraintes de nombre de matchs/jour et de repos.');
    }
  }

  // Minimum teams (pairs) suggested/required
  const minTeams = getMinTeamsForCategory(category, gender);
  if (minTeams && typeof max_teams === 'number' && max_teams > 0 && max_teams < minTeams) {
    errors.push(`Nombre de paires maximum trop faible : minimum FFT = ${minTeams} paires pour ${category} ${gender}.`);
  }

  // Referee level
  const requiredLevel = getRequiredRefereeLevel(category);
  if (requiredLevel) {
    if (!referee_level) {
      errors.push(`Niveau de juge-arbitre requis manquant : au minimum ${requiredLevel} pour ${category}.`);
    } else if (!compareRefereeLevel(referee_level, requiredLevel)) {
      errors.push(`Niveau de juge-arbitre insuffisant : ${category} nécessite au minimum ${requiredLevel}.`);
    }
  }

  return { errors, warnings };
};

export const checkTeamCutEligibility = (args: {
  category?: CategoryCode | null;
  gender?: Gender | null;
  player1Ranking?: string | null;
  player2Ranking?: string | null;
}) => {
  const { category, gender, player1Ranking, player2Ranking } = args;
  const cut = getCutForCategory(category, gender);
  const p1 = parseRankingPosition(player1Ranking);
  const p2 = parseRankingPosition(player2Ranking);

  const problems: string[] = [];
  if (!category || !gender) return { eligible: true, problems, cut };
  if (gender === 'H') {
    if (cut.menTopInclusive && ((p1 !== null && p1 <= cut.menTopInclusive) || (p2 !== null && p2 <= cut.menTopInclusive))) {
      problems.push(`Interdit : TOP ${cut.menTopInclusive} messieurs (inclus) pour ${category}.`);
    }
  } else if (gender === 'F') {
    if (cut.womenTopInclusive && ((p1 !== null && p1 <= cut.womenTopInclusive) || (p2 !== null && p2 <= cut.womenTopInclusive))) {
      problems.push(`Interdit : TOP ${cut.womenTopInclusive} dames (inclus) pour ${category}.`);
    }
  } else {
    if (cut.note) return { eligible: true, problems, cut };
    // Mixed: apply both cuts when applicable
    if (cut.menTopInclusive && (p1 !== null && p1 <= cut.menTopInclusive)) {
      problems.push(`Interdit : TOP ${cut.menTopInclusive} messieurs (inclus) en mixte ${category}.`);
    }
    if (cut.menTopInclusive && (p2 !== null && p2 <= cut.menTopInclusive)) {
      problems.push(`Interdit : TOP ${cut.menTopInclusive} messieurs (inclus) en mixte ${category}.`);
    }
    if (cut.womenTopInclusive && (p1 !== null && p1 <= cut.womenTopInclusive)) {
      problems.push(`Interdit : TOP ${cut.womenTopInclusive} dames (inclus) en mixte ${category}.`);
    }
    if (cut.womenTopInclusive && (p2 !== null && p2 <= cut.womenTopInclusive)) {
      problems.push(`Interdit : TOP ${cut.womenTopInclusive} dames (inclus) en mixte ${category}.`);
    }
  }

  const eligible = problems.length === 0;
  return { eligible, problems, cut };
};
