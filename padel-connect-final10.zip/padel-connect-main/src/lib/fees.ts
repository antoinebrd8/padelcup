// Centralised pricing helpers
// Organizer sets a base price (per player).
// Player pays base + Padel Cup fee.

export const PADEL_CUP_FEE_PER_PLAYER_EUR = 4;

export function playerTotalPrice(basePerPlayer: number): number {
  const base = Number.isFinite(basePerPlayer) ? basePerPlayer : 0;
  return Math.max(0, base + PADEL_CUP_FEE_PER_PLAYER_EUR);
}

export function teamTotalPrice(basePerPlayer: number): number {
  const base = Number.isFinite(basePerPlayer) ? basePerPlayer : 0;
  return Math.max(0, base * 2 + PADEL_CUP_FEE_PER_PLAYER_EUR * 2);
}
