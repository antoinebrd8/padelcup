// Centralized game format configuration used across organizer/live/TV/public views.
// Aligned with FFT formats (A1..F) + an extra custom format (G) requested.

export type GameFormat = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'D1' | 'D2' | 'E' | 'F' | 'G';

export type GameFormatConfig = {
  label: string;
  /** Short human description */
  description: string;

  /**
   * Number of "regular" sets for the match when applicable.
   * - A1/A2: 3
   * - B/C: 2 (with deciding super TB)
   * - D/F: 1
   * - E: 0 (pure super TB)
   * - G: 0 (pure super TB, best-of-3)
   */
  sets: 0 | 1 | 2 | 3;

  /** Whether there is a deciding Super Tie-Break (10 points) after the regular sets. */
  hasDecidingSuperTB: boolean;

  /** Max number of score inputs shown in UI (we always store as "a/b/c" style strings). */
  maxScoreInputs: 1 | 2 | 3;

  /** Sets / mini-sets needed to win. For superTB-only formats, it is 1 or 2 (G). */
  setsToWin: 1 | 2;

  /** Whether 'point décisif' (no-ad) is used */
  decisivePoint: boolean;

  /** True when all score inputs are super tie-breaks (points), not games. */
  isSuperTBOnly: boolean;
};

export const GAME_FORMAT_CONFIG: Record<GameFormat, GameFormatConfig> = {
  A1: {
    label: 'A1 (3 sets)',
    description: '3 sets à 6 jeux, TB à 6-6, sans point décisif',
    sets: 3,
    hasDecidingSuperTB: false,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: false,
    isSuperTBOnly: false,
  },
  A2: {
    label: 'A2 (3 sets + PD)',
    description: '3 sets à 6 jeux, TB à 6-6, avec point décisif',
    sets: 3,
    hasDecidingSuperTB: false,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: true,
    isSuperTBOnly: false,
  },
  B1: {
    label: 'B1 (2 sets + ST)',
    description: '2 sets à 6 jeux, TB à 6-6 ; 3e = super TB (10 pts), sans point décisif',
    sets: 2,
    hasDecidingSuperTB: true,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: false,
    isSuperTBOnly: false,
  },
  B2: {
    label: 'B2 (2 sets + ST + PD)',
    description: '2 sets à 6 jeux, TB à 6-6 ; 3e = super TB (10 pts), avec point décisif',
    sets: 2,
    hasDecidingSuperTB: true,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: true,
    isSuperTBOnly: false,
  },
  C1: {
    label: 'C1 (2 sets courts + ST)',
    description: '2 sets à 4 jeux, TB à 4-4 ; 3e = super TB (10 pts), sans point décisif',
    sets: 2,
    hasDecidingSuperTB: true,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: false,
    isSuperTBOnly: false,
  },
  C2: {
    label: 'C2 (2 sets courts + ST + PD)',
    description: '2 sets à 4 jeux, TB à 4-4 ; 3e = super TB (10 pts), avec point décisif',
    sets: 2,
    hasDecidingSuperTB: true,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: true,
    isSuperTBOnly: false,
  },
  D1: {
    label: 'D1 (1 set - 9 jeux)',
    description: '1 set à 9 jeux, TB à 8-8, sans point décisif',
    sets: 1,
    hasDecidingSuperTB: false,
    maxScoreInputs: 1,
    setsToWin: 1,
    decisivePoint: false,
    isSuperTBOnly: false,
  },
  D2: {
    label: 'D2 (1 set - 9 jeux + PD)',
    description: '1 set à 9 jeux, TB à 8-8, avec point décisif',
    sets: 1,
    hasDecidingSuperTB: false,
    maxScoreInputs: 1,
    setsToWin: 1,
    decisivePoint: true,
    isSuperTBOnly: false,
  },
  E: {
    label: 'E (Super TB)',
    description: '1 super tie-break à 10 points (format court)',
    sets: 0,
    hasDecidingSuperTB: false,
    maxScoreInputs: 1,
    setsToWin: 1,
    decisivePoint: true,
    isSuperTBOnly: true,
  },
  F: {
    label: 'F (1 set court + PD)',
    description: '1 set à 4 jeux, TB à 3-3, avec point décisif',
    sets: 1,
    hasDecidingSuperTB: false,
    maxScoreInputs: 1,
    setsToWin: 1,
    decisivePoint: true,
    isSuperTBOnly: false,
  },
  G: {
    label: 'G (2 Super TB gagnants)',
    description: 'Match au meilleur de 3 super tie-breaks à 10 points (2 gagnants)',
    sets: 0,
    hasDecidingSuperTB: false,
    maxScoreInputs: 3,
    setsToWin: 2,
    decisivePoint: true,
    isSuperTBOnly: true,
  },
};

/**
 * Determines how many score inputs to show, based on current score and format.
 * - For B/C formats: show 2 inputs until 1-1, then show 3rd (deciding super TB).
 * - For A formats: show 2 if match already decided 2-0, else 3.
 * - For G: show 2 superTBs until 1-1, then show 3rd.
 */
export function getNumScoreInputs(
  setsA: number[] | null | undefined,
  setsB: number[] | null | undefined,
  format: GameFormat | null | undefined
): 1 | 2 | 3 {
  const f = (format || 'B1') as GameFormat;
  const cfg = GAME_FORMAT_CONFIG[f];
  const a = setsA ?? [];
  const b = setsB ?? [];

  // Single input formats
  if (cfg.maxScoreInputs === 1) return 1;

  // Best-of-3 superTB (G)
  if (f === 'G') {
    const winsA = (a[0] > b[0] ? 1 : 0) + (a[1] > b[1] ? 1 : 0);
    const winsB = (b[0] > a[0] ? 1 : 0) + (b[1] > a[1] ? 1 : 0);
    if (winsA >= 2 || winsB >= 2) return 2;
    // If two played and tied 1-1 -> need 3rd
    const playedSecond = (a[1] || 0) > 0 || (b[1] || 0) > 0;
    if (playedSecond && winsA === 1 && winsB === 1) return 3;
    return 2;
  }

  // B/C formats (2 sets + deciding ST)
  if (cfg.sets === 2 && cfg.hasDecidingSuperTB) {
    const winsA = (a[0] > b[0] ? 1 : 0) + (a[1] > b[1] ? 1 : 0);
    const winsB = (b[0] > a[0] ? 1 : 0) + (b[1] > a[1] ? 1 : 0);
    if (winsA === 1 && winsB === 1) return 3;
    // If 2-0 or 0-2, we can stop at 2
    if (winsA === 2 || winsB === 2) return 2;
    return 2;
  }

  // A formats (3 sets)
  if (cfg.sets === 3) {
    const winsA = (a[0] > b[0] ? 1 : 0) + (a[1] > b[1] ? 1 : 0);
    const winsB = (b[0] > a[0] ? 1 : 0) + (b[1] > a[1] ? 1 : 0);
    if (winsA === 2 || winsB === 2) return 2;
    return 3;
  }

  return cfg.maxScoreInputs;
}

export function getSetsNeededToWin(format: GameFormat | null | undefined): 1 | 2 {
  const f = (format || 'B1') as GameFormat;
  return GAME_FORMAT_CONFIG[f]?.setsToWin ?? 2;
}
