export const FFT_LICENSE_REGEX = /^\d{7}[A-Za-z]$/;

export function isValidFftLicenseNumber(value: string | null | undefined): boolean {
  if (!value) return false;
  return FFT_LICENSE_REGEX.test(value.trim());
}
