import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { PlayerAuthProvider } from "@/contexts/PlayerAuthContext";

// Pages
import Index from "./pages/Index";
import Tournaments from "./pages/Tournaments";
import TournamentDetail from "./pages/TournamentDetail";
import ClubLogin from "./pages/club/Login";
import ClubRegister from "./pages/club/Register";
import ClubDashboard from "./pages/club/Dashboard";
import TournamentCreate from "./pages/club/TournamentCreate";
import TournamentEdit from "./pages/club/TournamentEdit";
import TournamentRegistrations from "./pages/club/TournamentRegistrations";
import TournamentTeams from "./pages/club/TournamentTeams";
import TournamentDraw from "./pages/club/TournamentDraw";
import TournamentManagement from "./pages/club/TournamentManagement";
import TournamentLiveDisplay from "./pages/TournamentLiveDisplay";
import PlayerLogin from "./pages/player/Login";
import PlayerRegister from "./pages/player/Register";
import PlayerDashboard from "./pages/player/Dashboard";
import NotFound from "./pages/NotFound";
import DebugFormats from "./pages/debug/Formats";

// Admin
import AdminLogin from "./pages/admin/Login";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminClubRequests from "./pages/admin/ClubRequests";
import AdminClubRequestDetail from "./pages/admin/ClubRequestDetail";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <PlayerAuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/tournaments" element={<Tournaments />} />
              <Route path="/tournaments/:id" element={<TournamentDetail />} />
              <Route path="/club/login" element={<ClubLogin />} />
              <Route path="/club/register" element={<ClubRegister />} />
              <Route path="/club/dashboard" element={<ClubDashboard />} />
              <Route path="/club/tournaments/create" element={<TournamentCreate />} />
              <Route path="/club/tournaments/:id/edit" element={<TournamentEdit />} />
              <Route path="/club/tournaments/:id/registrations" element={<TournamentRegistrations />} />
              <Route path="/club/tournaments/:id/teams" element={<TournamentTeams />} />
              <Route path="/club/tournaments/:id/draw" element={<TournamentDraw />} />
              <Route path="/club/tournaments/:id/manage" element={<TournamentManagement />} />
              <Route path="/live/:id" element={<TournamentLiveDisplay />} />
              <Route path="/player/login" element={<PlayerLogin />} />
              <Route path="/player/register" element={<PlayerRegister />} />
              <Route path="/player/dashboard" element={<PlayerDashboard />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/club-requests" element={<AdminClubRequests />} />
              <Route path="/admin/club-requests/:id" element={<AdminClubRequestDetail />} />
              <Route path="/debug/formats" element={<DebugFormats />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </PlayerAuthProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
