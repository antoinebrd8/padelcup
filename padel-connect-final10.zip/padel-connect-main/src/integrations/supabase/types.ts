export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      club_tournaments: {
        Row: {
          byes_priority_for_seeds: boolean
          allow_on_site_license: boolean
          category_code: string | null
          city: string | null
          club_id: string
          created_at: string
          description: string | null
          draw_generated: boolean
          draw_locked: boolean
          draw_size_manual: number | null
          draw_size_mode: Database["public"]["Enums"]["draw_size_mode"]
          end_date: string
          extra_qualifiers_count: number | null
          extra_qualifiers_position: number | null
          final_draw_size: number | null
          format: Database["public"]["Enums"]["tournament_format"]
          game_format: Database["public"]["Enums"]["game_format"] | null
          gender: string | null
          group_size: number | null
          group_sizes_csv: string | null
          id: string
          image_url: string | null
          latitude: number | null
          location: string | null
          longitude: number | null
          max_teams: number | null
          price: number | null
          refund_deadline_hours: number | null
          refund_policy_text: string | null
          qualifiers_per_group: number | null
          random_seed: number | null
          referee_name: string | null
          referee_level: Database["public"]["Enums"]["referee_level"] | null
          region: string | null
          registration_deadline: string | null
          seeds_direct_count: number | null
          start_date: string
          start_time: string | null
          start_at: string | null
          title: string
          updated_at: string
          use_custom_groups: boolean | null
        }
        Insert: {
          byes_priority_for_seeds?: boolean
          allow_on_site_license?: boolean
          category_code?: string | null
          city?: string | null
          club_id: string
          created_at?: string
          description?: string | null
          draw_generated?: boolean
          draw_locked?: boolean
          draw_size_manual?: number | null
          draw_size_mode?: Database["public"]["Enums"]["draw_size_mode"]
          end_date: string
          extra_qualifiers_count?: number | null
          extra_qualifiers_position?: number | null
          final_draw_size?: number | null
          format?: Database["public"]["Enums"]["tournament_format"]
          game_format?: Database["public"]["Enums"]["game_format"] | null
          gender?: string | null
          group_size?: number | null
          group_sizes_csv?: string | null
          id?: string
          image_url?: string | null
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          max_teams?: number | null
          price?: number | null
          refund_deadline_hours?: number | null
          refund_policy_text?: string | null
          qualifiers_per_group?: number | null
          random_seed?: number | null
          referee_name?: string | null
          referee_level?: Database["public"]["Enums"]["referee_level"] | null
          region?: string | null
          registration_deadline?: string | null
          seeds_direct_count?: number | null
          start_date: string
          start_time?: string | null
          start_at?: string | null
          title: string
          updated_at?: string
          use_custom_groups?: boolean | null
        }
        Update: {
          byes_priority_for_seeds?: boolean
          allow_on_site_license?: boolean
          category_code?: string | null
          city?: string | null
          club_id?: string
          created_at?: string
          description?: string | null
          draw_generated?: boolean
          draw_locked?: boolean
          draw_size_manual?: number | null
          draw_size_mode?: Database["public"]["Enums"]["draw_size_mode"]
          end_date?: string
          extra_qualifiers_count?: number | null
          extra_qualifiers_position?: number | null
          final_draw_size?: number | null
          format?: Database["public"]["Enums"]["tournament_format"]
          game_format?: Database["public"]["Enums"]["game_format"] | null
          gender?: string | null
          group_size?: number | null
          group_sizes_csv?: string | null
          id?: string
          image_url?: string | null
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          max_teams?: number | null
          price?: number | null
          refund_deadline_hours?: number | null
          refund_policy_text?: string | null
          qualifiers_per_group?: number | null
          random_seed?: number | null
          referee_name?: string | null
          referee_level?: Database["public"]["Enums"]["referee_level"] | null
          region?: string | null
          registration_deadline?: string | null
          seeds_direct_count?: number | null
          start_date?: string
          start_time?: string | null
          start_at?: string | null
          title?: string
          updated_at?: string
          use_custom_groups?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "club_tournaments_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      clubs: {
        Row: {
          address: string | null
          city: string | null
          commercial_name: string | null
          country: string | null
          created_at: string
          email: string
          id: string
          legal_name: string | null
          logo_url: string | null
          name: string
          phone: string | null
          postal_code: string | null
          region: string | null
          registration_status: string | null
          representative_email: string | null
          representative_first_name: string | null
          representative_last_name: string | null
          representative_phone: string | null
          representative_role: string | null
          rna_number: string | null
          siren_siret: string | null
          structure_type: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address?: string | null
          city?: string | null
          commercial_name?: string | null
          country?: string | null
          created_at?: string
          email: string
          id?: string
          legal_name?: string | null
          logo_url?: string | null
          name: string
          phone?: string | null
          postal_code?: string | null
          region?: string | null
          registration_status?: string | null
          representative_email?: string | null
          representative_first_name?: string | null
          representative_last_name?: string | null
          representative_phone?: string | null
          representative_role?: string | null
          rna_number?: string | null
          siren_siret?: string | null
          structure_type?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address?: string | null
          city?: string | null
          commercial_name?: string | null
          country?: string | null
          created_at?: string
          email?: string
          id?: string
          legal_name?: string | null
          logo_url?: string | null
          name?: string
          phone?: string | null
          postal_code?: string | null
          region?: string | null
          registration_status?: string | null
          representative_email?: string | null
          representative_first_name?: string | null
          representative_last_name?: string | null
          representative_phone?: string | null
          representative_role?: string | null
          rna_number?: string | null
          siren_siret?: string | null
          structure_type?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      admin_users: {
        Row: {
          user_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          created_at?: string
        }
        Update: {
          user_id?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      club_requests: {
        Row: {
          id: string
          created_at: string
          structure_type: string | null
          legal_name: string
          commercial_name: string | null
          address: string | null
          city: string | null
          postal_code: string | null
          country: string | null
          siren_siret: string | null
          rna_number: string | null
          contact_email: string
          contact_phone: string | null
          representative_first_name: string | null
          representative_last_name: string | null
          representative_role: string | null
          representative_email: string
          representative_phone: string | null
          website: string | null
          courts_count: number | null
          message: string | null
          logo_url: string | null
          status: string
          reviewed_at: string | null
          reviewed_by: string | null
          rejection_reason: string | null
          internal_note: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          structure_type?: string | null
          legal_name: string
          commercial_name?: string | null
          address?: string | null
          city?: string | null
          postal_code?: string | null
          country?: string | null
          siren_siret?: string | null
          rna_number?: string | null
          contact_email: string
          contact_phone?: string | null
          representative_first_name?: string | null
          representative_last_name?: string | null
          representative_role?: string | null
          representative_email: string
          representative_phone?: string | null
          website?: string | null
          courts_count?: number | null
          message?: string | null
          logo_url?: string | null
          status?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          rejection_reason?: string | null
          internal_note?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          structure_type?: string | null
          legal_name?: string
          commercial_name?: string | null
          address?: string | null
          city?: string | null
          postal_code?: string | null
          country?: string | null
          siren_siret?: string | null
          rna_number?: string | null
          contact_email?: string
          contact_phone?: string | null
          representative_first_name?: string | null
          representative_last_name?: string | null
          representative_role?: string | null
          representative_email?: string
          representative_phone?: string | null
          website?: string | null
          courts_count?: number | null
          message?: string | null
          logo_url?: string | null
          status?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          rejection_reason?: string | null
          internal_note?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "club_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      favorite_partners: {
        Row: {
          created_at: string
          id: string
          partner_player_id: string
          player_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          partner_player_id: string
          player_id: string
        }
        Update: {
          created_at?: string
          id?: string
          partner_player_id?: string
          player_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorite_partners_partner_player_id_fkey"
            columns: ["partner_player_id"]
            isOneToOne: false
            referencedRelation: "players"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "favorite_partners_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "players"
            referencedColumns: ["id"]
          },
        ]
      }
      group_teams: {
        Row: {
          games_lost: number
          games_won: number
          group_id: string
          id: string
          matches_lost: number
          matches_played: number
          matches_won: number
          points: number
          ranking_position: number | null
          sets_lost: number
          sets_won: number
          team_id: string
        }
        Insert: {
          games_lost?: number
          games_won?: number
          group_id: string
          id?: string
          matches_lost?: number
          matches_played?: number
          matches_won?: number
          points?: number
          ranking_position?: number | null
          sets_lost?: number
          sets_won?: number
          team_id: string
        }
        Update: {
          games_lost?: number
          games_won?: number
          group_id?: string
          id?: string
          matches_lost?: number
          matches_played?: number
          matches_won?: number
          points?: number
          ranking_position?: number | null
          sets_lost?: number
          sets_won?: number
          team_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_teams_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "tournament_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_teams_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "tournament_teams"
            referencedColumns: ["id"]
          },
        ]
      }
      player_tournaments: {
        Row: {
          created_at: string
          id: string
          partner_name: string | null
          player_id: string
          ranking_position: number | null
          result: string | null
          tournament_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          partner_name?: string | null
          player_id: string
          ranking_position?: number | null
          result?: string | null
          tournament_id: string
        }
        Update: {
          created_at?: string
          id?: string
          partner_name?: string | null
          player_id?: string
          ranking_position?: number | null
          result?: string | null
          tournament_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "player_tournaments_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "players"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "player_tournaments_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "club_tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      players: {
        Row: {
          avatar_url: string | null
          bio: string | null
          city: string | null
          created_at: string
          date_of_birth: string | null
          email: string
          first_name: string
          id: string
          last_name: string
          latitude: number | null
          license_number: string | null
          longitude: number | null
          phone: string | null
          postal_code: string | null
          ranking: string | null
          region: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          city?: string | null
          created_at?: string
          date_of_birth?: string | null
          email: string
          first_name: string
          id?: string
          last_name: string
          latitude?: number | null
          license_number?: string | null
          longitude?: number | null
          phone?: string | null
          postal_code?: string | null
          ranking?: string | null
          region?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          city?: string | null
          created_at?: string
          date_of_birth?: string | null
          email?: string
          first_name?: string
          id?: string
          last_name?: string
          latitude?: number | null
          license_number?: string | null
          longitude?: number | null
          phone?: string | null
          postal_code?: string | null
          ranking?: string | null
          region?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tournament_groups: {
        Row: {
          created_at: string
          group_order: number
          id: string
          name: string
          tournament_id: string
        }
        Insert: {
          created_at?: string
          group_order?: number
          id?: string
          name: string
          tournament_id: string
        }
        Update: {
          created_at?: string
          group_order?: number
          id?: string
          name?: string
          tournament_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_groups_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "club_tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_matches: {
        Row: {
          completed_at: string | null
          created_at: string
          group_id: string | null
          id: string
          is_bye: boolean
          match_order: number
          next_match_id: string | null
          round_name: string
          round_order: number
          score_a: string | null
          score_b: string | null
          slot_index: number | null
          started_at: string | null
          team_a_id: string | null
          team_b_id: string | null
          tournament_id: string
          updated_at: string
          winner_id: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          group_id?: string | null
          id?: string
          is_bye?: boolean
          match_order?: number
          next_match_id?: string | null
          round_name: string
          round_order?: number
          score_a?: string | null
          score_b?: string | null
          slot_index?: number | null
          started_at?: string | null
          team_a_id?: string | null
          team_b_id?: string | null
          tournament_id: string
          updated_at?: string
          winner_id?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          group_id?: string | null
          id?: string
          is_bye?: boolean
          match_order?: number
          next_match_id?: string | null
          round_name?: string
          round_order?: number
          score_a?: string | null
          score_b?: string | null
          slot_index?: number | null
          started_at?: string | null
          team_a_id?: string | null
          team_b_id?: string | null
          tournament_id?: string
          updated_at?: string
          winner_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tournament_matches_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "tournament_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_next_match_id_fkey"
            columns: ["next_match_id"]
            isOneToOne: false
            referencedRelation: "tournament_matches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_team_a_id_fkey"
            columns: ["team_a_id"]
            isOneToOne: false
            referencedRelation: "tournament_teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_team_b_id_fkey"
            columns: ["team_b_id"]
            isOneToOne: false
            referencedRelation: "tournament_teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "club_tournaments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tournament_matches_winner_id_fkey"
            columns: ["winner_id"]
            isOneToOne: false
            referencedRelation: "tournament_teams"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_teams: {
        Row: {
          created_at: string
          id: string
          name: string
          player1_email: string | null
          player1_has_license: boolean | null
          player1_name: string
          player1_payment_status: string | null
          player2_email: string | null
          player2_has_license: boolean | null
          player2_name: string | null
          player2_payment_status: string | null
          seed_rank: number | null
          slot_position: number | null
          status: Database["public"]["Enums"]["team_status"]
          tournament_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          player1_email?: string | null
          player1_has_license?: boolean | null
          player1_name: string
          player1_payment_status?: string | null
          player2_email?: string | null
          player2_has_license?: boolean | null
          player2_name?: string | null
          player2_payment_status?: string | null
          seed_rank?: number | null
          slot_position?: number | null
          status?: Database["public"]["Enums"]["team_status"]
          tournament_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          player1_email?: string | null
          player1_has_license?: boolean | null
          player1_name?: string
          player1_payment_status?: string | null
          player2_email?: string | null
          player2_has_license?: boolean | null
          player2_name?: string | null
          player2_payment_status?: string | null
          seed_rank?: number | null
          slot_position?: number | null
          status?: Database["public"]["Enums"]["team_status"]
          tournament_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_teams_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "club_tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "club" | "player"
      draw_size_mode: "auto" | "manual"
      game_format:
        | "A1"
        | "A2"
        | "B1"
        | "B2"
        | "C1"
        | "C2"
        | "D1"
        | "D2"
        | "E"
        | "F"
        | "G"
      team_status: "confirmed" | "pending" | "waiting"
      referee_level: "JAP1" | "JAP2" | "JAT3" | "INTERNATIONAL"
      tournament_format:
        | "knockout"
        | "groups_knockout"
        | "round_robin"
        | "direct_entry"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["club", "player"],
      draw_size_mode: ["auto", "manual"],
      game_format: ["A1", "A2", "B1", "B2", "C1", "C2", "D1", "D2", "E", "F", "G"],
      team_status: ["confirmed", "pending", "waiting"],
      tournament_format: [
        "knockout",
        "groups_knockout",
        "round_robin",
        "direct_entry",
      ],
    },
  },
} as const
