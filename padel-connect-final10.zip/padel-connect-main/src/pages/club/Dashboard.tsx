import { useState, useEffect } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Edit, Users, Trophy, Calendar, Settings, Trash2, Building2, Mail, Phone, MapPin, Link2 } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { ClubTournament } from '@/types/tournament';

const ClubDashboard = () => {
  const { isAuthenticated, club, isLoading: authLoading, refreshClub } = useAuth();
  const { toast } = useToast();
  const [tournaments, setTournaments] = useState<ClubTournament[]>([]);
  const [registrationCounts, setRegistrationCounts] = useState<Record<string, { confirmed: number; waiting: number }>>({});
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [editClubOpen, setEditClubOpen] = useState(false);
  const [savingClub, setSavingClub] = useState(false);
  const [clubForm, setClubForm] = useState({
    name: '',
    email: '',
    phone: '',
    show_email: true,
    show_phone: true,
    address: '',
    city: '',
    region: '',
    logo_url: '',
  });

  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [logoUploading, setLogoUploading] = useState(false);

  useEffect(() => {
    if (club) {
      fetchTournaments();
      setClubForm({
        name: club.name || '',
        email: club.email || '',
        phone: club.phone || '',
        show_email: (club as any).show_email ?? true,
        show_phone: (club as any).show_phone ?? true,
        address: club.address || '',
        city: club.city || '',
        region: club.region || '',
        logo_url: club.logo_url || '',
      });
      setLogoPreview(club.logo_url || '');
      setLogoFile(null);
    } else if (!authLoading) {
      // No club yet, stop loading
      setLoading(false);
    }
  }, [club, authLoading]);

  const handleSaveClub = async () => {
    if (!club) return;
    setSavingClub(true);
    try {
      let logoUrl = clubForm.logo_url?.trim() || null;

      // If user selected an image file, upload it to Supabase Storage and store public URL
      if (logoFile) {
        setLogoUploading(true);
        const ext = (logoFile.name.split('.').pop() || 'png').toLowerCase();
        const filePath = `${club.id}/${Date.now()}.${ext}`;

        const { error: uploadError } = await supabase.storage
          .from('club-logos')
          .upload(filePath, logoFile, { upsert: true, contentType: logoFile.type });

        if (uploadError) throw uploadError;

        const { data: publicData } = supabase.storage.from('club-logos').getPublicUrl(filePath);
        logoUrl = publicData?.publicUrl || logoUrl;
      }

      const payload = {
        name: clubForm.name?.trim() || club.name,
        email: clubForm.email?.trim() || club.email,
        phone: clubForm.phone?.trim() || null,
        show_email: !!clubForm.show_email,
        show_phone: !!clubForm.show_phone,
        address: clubForm.address?.trim() || null,
        city: clubForm.city?.trim() || null,
        region: clubForm.region?.trim() || null,
        logo_url: logoUrl,
      } as any;

      const { error } = await supabase.from('clubs').update(payload).eq('id', club.id);
      if (error) throw error;

      await refreshClub();
      toast({
        title: 'Informations mises à jour',
        description: 'Les informations du club ont bien été enregistrées.',
      });
      setEditClubOpen(false);
      setLogoFile(null);
    } catch (e: any) {
      console.error(e);
      toast({
        title: 'Erreur',
        description: e?.message || "Impossible d'enregistrer les informations du club.",
        variant: 'destructive',
      });
    } finally {
      setSavingClub(false);
      setLogoUploading(false);
    }
  };

  // Keep counters in sync when teams change (registrations / payments / waitlist)
  useEffect(() => {
    if (!club) return;
    if (!tournaments.length) return;

    const tournamentIds = tournaments.map((t) => t.id);

    const channel = supabase
      .channel('club-dashboard-teams')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tournament_teams' },
        (payload: any) => {
          const row = payload?.new ?? payload?.old;
          const tid = row?.tournament_id;
          if (!tid) return;
          if (!tournamentIds.includes(tid)) return;
          // Simple + reliable: re-fetch counts
          fetchRegistrationCounts(tournamentIds);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [club?.id, tournaments.map((t) => t.id).join('|')]);

  const fetchRegistrationCounts = async (tournamentIds: string[]) => {
    if (!tournamentIds.length) {
      setRegistrationCounts({});
      return;
    }

    const { data: teams, error } = await supabase
      .from('tournament_teams')
      .select('tournament_id,status')
      .in('tournament_id', tournamentIds);

    if (error || !teams) return;

    const counts: Record<string, { confirmed: number; waiting: number }> = {};
    for (const team of teams as any[]) {
      const tid = team.tournament_id as string;
      if (!counts[tid]) counts[tid] = { confirmed: 0, waiting: 0 };

      if (team.status === 'waiting') counts[tid].waiting += 1;
      else if (team.status === 'confirmed') counts[tid].confirmed += 1;
      // 'pending' does not count as a confirmed registration
    }
    setRegistrationCounts(counts);
  };

  const fetchTournaments = async () => {
    if (!club) return;
    
    const { data, error } = await supabase
      .from('club_tournaments')
      .select('*')
      .eq('club_id', club.id)
      .order('start_date', { ascending: false });

    if (!error && data) {
      setTournaments(data as unknown as ClubTournament[]);
      
      // Fetch registration counts for all tournaments
      const tournamentIds = data.map(t => t.id);
      await fetchRegistrationCounts(tournamentIds);
    }
    setLoading(false);
  };

  const handleDeleteTournament = async (tournamentId: string) => {
    setDeletingId(tournamentId);

    try {
      // Delete associated matches first
      await supabase
        .from('tournament_matches')
        .delete()
        .eq('tournament_id', tournamentId);

      // Delete associated teams
      await supabase
        .from('tournament_teams')
        .delete()
        .eq('tournament_id', tournamentId);

      // Delete associated groups
      await supabase
        .from('tournament_groups')
        .delete()
        .eq('tournament_id', tournamentId);

      // Delete the tournament
      const { error } = await supabase
        .from('club_tournaments')
        .delete()
        .eq('id', tournamentId);

      if (error) throw error;

      toast({
        title: "Tournoi supprimé",
        description: "Le tournoi a été supprimé avec succès.",
      });

      // Refresh list
      setTournaments(prev => prev.filter(t => t.id !== tournamentId));
      setRegistrationCounts(prev => {
        const next = { ...prev };
        delete (next as any)[tournamentId];
        return next;
      });
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de supprimer le tournoi",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  if (authLoading) {
    return (
      <Layout>
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/club/login" replace />;
  }

  const upcomingTournaments = tournaments.filter(t => new Date(t.start_date) > new Date());

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl md:text-3xl font-bold">Dashboard</h1>
                <p className="text-muted-foreground">{club?.name}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="accent" asChild>
                  <Link to="/club/tournaments/create">
                    <Plus className="mr-2 h-4 w-4" />
                    Créer un tournoi
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8">
          {/* Club Info Card */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center justify-between gap-4">
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Informations du club
                </CardTitle>

                <Dialog open={editClubOpen} onOpenChange={setEditClubOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" />
                      Modifier
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Modifier les informations du club</DialogTitle>
                      <DialogDescription>
                        Ces informations seront affichées sur vos tournois (nom du club, ville, etc.).
                      </DialogDescription>
                    </DialogHeader>

                    <div className="grid gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="club-name">Nom du club</Label>
                        <Input
                          id="club-name"
                          value={clubForm.name}
                          onChange={(e) => setClubForm((p) => ({ ...p, name: e.target.value }))}
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="club-email">Email</Label>
                        <Input
                          id="club-email"
                          type="email"
                          value={clubForm.email}
                          onChange={(e) => setClubForm((p) => ({ ...p, email: e.target.value }))}
                        />
                        <div className="flex items-center justify-between rounded-md border p-3">
                          <div className="space-y-0.5">
                            <p className="text-sm font-medium">Afficher l'email sur l'annonce</p>
                            <p className="text-xs text-muted-foreground">Visible pour les joueurs sur la page tournoi</p>
                          </div>
                          <Switch
                            checked={!!clubForm.show_email}
                            onCheckedChange={(checked) => setClubForm((p) => ({ ...p, show_email: checked }))}
                          />
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="club-phone">Téléphone</Label>
                        <Input
                          id="club-phone"
                          value={clubForm.phone}
                          onChange={(e) => setClubForm((p) => ({ ...p, phone: e.target.value }))}
                        />
                        <div className="flex items-center justify-between rounded-md border p-3">
                          <div className="space-y-0.5">
                            <p className="text-sm font-medium">Afficher le téléphone sur l'annonce</p>
                            <p className="text-xs text-muted-foreground">Visible pour les joueurs sur la page tournoi</p>
                          </div>
                          <Switch
                            checked={!!clubForm.show_phone}
                            onCheckedChange={(checked) => setClubForm((p) => ({ ...p, show_phone: checked }))}
                          />
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="club-address">Adresse</Label>
                        <Input
                          id="club-address"
                          value={clubForm.address}
                          onChange={(e) => setClubForm((p) => ({ ...p, address: e.target.value }))}
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="club-city">Ville</Label>
                          <Input
                            id="club-city"
                            value={clubForm.city}
                            onChange={(e) => setClubForm((p) => ({ ...p, city: e.target.value }))}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="club-region">Région</Label>
                          <Input
                            id="club-region"
                            value={clubForm.region}
                            onChange={(e) => setClubForm((p) => ({ ...p, region: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Label>Logo du club</Label>

                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                            {logoPreview ? (
                              <img src={logoPreview} alt="Logo du club" className="h-full w-full object-cover" />
                            ) : (
                              <Building2 className="h-6 w-6 text-muted-foreground" />
                            )}
                          </div>

                          <div className="flex-1">
                            <Input
                              id="club-logo-file"
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0] || null;
                                setLogoFile(file);
                                if (file) {
                                  const url = URL.createObjectURL(file);
                                  setLogoPreview(url);
                                }
                              }}
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              PNG/JPG recommandé. Le logo sera affiché sur vos tournois.
                            </p>
                          </div>
                        </div>

                        <div className="grid gap-2 mt-2">
                          <Label htmlFor="club-logo-url" className="text-xs text-muted-foreground">Ou coller une URL (optionnel)</Label>
                          <Input
                            id="club-logo-url"
                            value={clubForm.logo_url}
                            onChange={(e) => setClubForm((p) => ({ ...p, logo_url: e.target.value }))}
                            placeholder="https://..."
                          />
                        </div>
                      </div>
                    </div>

                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditClubOpen(false)} disabled={savingClub || logoUploading}>
                        Annuler
                      </Button>
                      <Button variant="accent" onClick={handleSaveClub} disabled={savingClub || !clubForm.name.trim()}>
                        {savingClub ? 'Enregistrement...' : 'Enregistrer'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <Building2 className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Nom</p>
                    <p className="font-medium">{club?.name || '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <Mail className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{club?.email || '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <Phone className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Téléphone</p>
                    <p className="font-medium">{club?.phone || '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ville</p>
                    <p className="font-medium">{club?.city || '-'}{club?.region ? `, ${club.region}` : ''}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Tournois</CardDescription>
                <CardTitle className="text-3xl">{tournaments.length}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Trophy className="h-4 w-4 mr-1" />
                  Total des tournois
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>À venir</CardDescription>
                <CardTitle className="text-3xl">{upcomingTournaments.length}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4 mr-1" />
                  Tournois à venir
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Tirages générés</CardDescription>
                <CardTitle className="text-3xl">
                  {tournaments.filter(t => t.draw_generated).length}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Settings className="h-4 w-4 mr-1" />
                  Tableaux prêts
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Vos tournois</CardTitle>
              <CardDescription>Gérez vos tournois, équipes et tirages</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : tournaments.length === 0 ? (
                <div className="text-center py-12">
                  <Trophy className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Aucun tournoi</h3>
                  <p className="text-muted-foreground mb-4">Créez votre premier tournoi</p>
                  <Button variant="accent" asChild>
                    <Link to="/club/tournaments/create">
                      <Plus className="mr-2 h-4 w-4" />
                      Créer un tournoi
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {tournaments.map((tournament) => {
                    const isPast = new Date(tournament.end_date) < new Date();
                    const formatLabel = {
                      knockout: 'Knockout',
                      groups_knockout: 'Poules + KO',
                      round_robin: 'Round-robin',
                      direct_entry: 'Entrée directe',
                    }[tournament.format];

                    return (
                      <div
                        key={tournament.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg border bg-card gap-4"
                      >
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Link 
                              to={tournament.draw_generated 
                                ? `/club/tournaments/${tournament.id}/draw` 
                                : `/club/tournaments/${tournament.id}/teams`
                              }
                              className="font-semibold hover:text-primary transition-colors hover:underline"
                            >
                              {tournament.title}
                            </Link>
                            <Badge variant={isPast ? 'secondary' : 'platform'}>
                              {isPast ? 'Terminé' : 'À venir'}
                            </Badge>
                            <Badge variant="outline">{formatLabel}</Badge>
                            {tournament.draw_generated && (
                              <Badge variant={tournament.draw_locked ? 'success' : 'secondary'}>
                                {tournament.draw_locked ? 'Tirage validé' : 'Tirage en cours'}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(tournament.start_date), 'd MMM yyyy', { locale: fr })}
                            {tournament.city && ` • ${tournament.city}`}
                            {' • '}
                            <span className="font-medium text-foreground">
                              {registrationCounts[tournament.id]?.confirmed ?? 0}/{tournament.max_teams || '∞'} équipes
                            </span>
                          </p>

                          {tournament.max_teams && (
                            <div
                              className={`text-xs mt-1 ${
                                ((registrationCounts[tournament.id]?.confirmed ?? 0) >= tournament.max_teams)
                                  ? 'text-red-600 font-semibold'
                                  : 'text-muted-foreground'
                              }`}
                            >
                              {((registrationCounts[tournament.id]?.confirmed ?? 0) >= tournament.max_teams)
                                ? 'Complet'
                                : `${tournament.max_teams - (registrationCounts[tournament.id]?.confirmed ?? 0)} place(s) restante(s)`}
                              {((registrationCounts[tournament.id]?.waiting ?? 0) > 0) && ` • Liste d’attente : ${registrationCounts[tournament.id]?.waiting}`}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={async (e) => {
                              e.preventDefault();
                              const link = `${window.location.origin}/tournaments/${tournament.id}`;
                              try { await navigator.clipboard.writeText(link); } catch {}
                              toast({
                                title: "Lien copié",
                                description: link,
                              });
                            }}
                          >
                            <Link2 className="h-4 w-4 mr-1" />
                            Copier lien
                          </Button>

                          <Button variant="accent" size="sm" asChild>
                            <Link to={`/club/tournaments/${tournament.id}/manage`}>
                              <Trophy className="h-4 w-4 mr-1" />
                              Gérer
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/club/tournaments/${tournament.id}/edit`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="text-destructive hover:text-destructive hover:bg-destructive/10"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Supprimer ce tournoi ?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Cette action est irréversible. Le tournoi "{tournament.title}" sera définitivement supprimé
                                  avec toutes les équipes et matchs associés.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => handleDeleteTournament(tournament.id)}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  disabled={deletingId === tournament.id}
                                >
                                  {deletingId === tournament.id ? 'Suppression...' : 'Supprimer'}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default ClubDashboard;