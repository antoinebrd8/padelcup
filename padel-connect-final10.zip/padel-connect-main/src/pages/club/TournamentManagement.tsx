import { useState, useMemo, useEffect, useRef } from 'react';
import { Link, useParams, Navigate, useSearchParams } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ClubTournament, TournamentTeam, DrawResult, GroupResult, GeneratedMatch } from '@/types/tournament';
import { generateDraw, exportMatchesToCSV, generateFinalBracketForGroups } from '@/lib/drawEngine';
import {ArrowLeft, 
  CreditCard, 
  Shuffle, 
  Trophy, 
  Medal,
  ExternalLink,
  Lock,
  Users, Link2, Printer} from 'lucide-react';

// Import tab components
import { PaymentLicenseTab } from '@/components/club/tournament/PaymentLicenseTab';
import { FinalResultsTab } from '@/components/club/tournament/FinalResultsTab';
import { DrawTab } from '@/components/club/tournament/DrawTab';
import { LiveTournamentTab } from '@/components/club/tournament/LiveTournamentTab';

const TournamentManagement = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const { isAuthenticated, club } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get tab from URL or default to 'payments'
  const currentTab = searchParams.get('tab') || 'payments';
  
  // Local draw state
  const [localDraw, setLocalDraw] = useState<{
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  } | null>(null);

  const localDrawRef = useRef(localDraw);
  useEffect(() => {
    localDrawRef.current = localDraw;
  }, [localDraw]);

  // IMPORTANT: keep hooks before any early return (auth/loading/not-found)
  // so React hook order never changes between renders.
  const isTournamentFinished = useMemo(() => {
    if (!localDraw) return false;
    const all: any[] = [];
    if (localDraw.knockoutDraw?.matches) all.push(...localDraw.knockoutDraw.matches);
    if (localDraw.groupDraw?.matches) all.push(...localDraw.groupDraw.matches);
    if (localDraw.roundRobinMatches) all.push(...localDraw.roundRobinMatches);
    const matches = all.filter((m) => m && !m.is_bye);
    if (matches.length === 0) return false;
    return matches.every((m) => !!m.winner_id);
  }, [localDraw]);

  // Fetch tournament
  const { data: tournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ['tournament', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data as ClubTournament | null;
    },
    enabled: !!id && isAuthenticated,
  });

  // Fetch teams with realtime subscription
  const { data: teams = [], isLoading: teamsLoading } = useQuery({
    queryKey: ['tournament-teams', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tournament_teams')
        .select('*')
        .eq('tournament_id', id)
        .order('seed_rank', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data as TournamentTeam[];
    },
    enabled: !!id && isAuthenticated,
  });

  // Realtime subscription for participants updates (inscriptions / désinscriptions / paiements)
  useEffect(() => {
    if (!id) return;

    const channel = supabase
      .channel(`tournament-teams-realtime-${id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tournament_teams',
          filter: `tournament_id=eq.${id}`,
        },
        () => {
          // Keep UI in sync: counters + draw participants list must refresh instantly.
          queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, queryClient]);

  // Fetch players for license info
  const { data: players = [] } = useQuery({
    queryKey: ['players-for-tournament', id, teams.length],
    queryFn: async () => {
      // Licences can be stored either in `players` (legacy) or in `profiles` (account data).
      // We scope queries to the tournament participants emails to avoid relying on full-table access under RLS.
      const emails = Array.from(
        new Set(
          teams
            .flatMap(t => [t.player1_email, t.player2_email])
            .filter(Boolean)
            .map(e => String(e).trim().toLowerCase())
        )
      );

      if (emails.length === 0) return [];

      const [playersRes, profilesRes] = await Promise.all([
        supabase.from('players').select('email, license_number').in('email', emails),
        supabase.from('profiles').select('email, license_number').in('email', emails),
      ]);

      const byEmail = new Map<string, { email: string; license_number?: string | null }>();

      (playersRes.data || []).forEach((p: any) => {
        const key = String(p?.email || '').trim().toLowerCase();
        if (!key) return;
        byEmail.set(key, { email: key, license_number: p.license_number ?? null });
      });

      (profilesRes.data || []).forEach((p: any) => {
        const key = String(p?.email || '').trim().toLowerCase();
        if (!key) return;
        const existing = byEmail.get(key);
        // Prefer profiles when present (user account is the most up-to-date source)
        if (!existing || existing.license_number == null) {
          byEmail.set(key, { email: key, license_number: p.license_number ?? null });
        }
      });

      // If RLS blocked access or some emails are missing, hydrate missing licences via SECURITY DEFINER RPC (one-by-one).
      const missing = emails.filter(e => !byEmail.has(e) || byEmail.get(e)?.license_number == null);
      if (missing.length > 0) {
        await Promise.all(
          missing.map(async (email) => {
            try {
              const { data } = await supabase.rpc('find_player_by_email', { p_email: email });
              const row = Array.isArray(data) ? data[0] : data;
              const lic = row?.license_number ?? null;
              if (lic != null) byEmail.set(email, { email, license_number: lic });
            } catch {
              // ignore
            }
          })
        );
      }

      return Array.from(byEmail.values());
    },
    enabled: !!id && isAuthenticated && teams.length > 0,
  });


  // Update tournament mutation
  const updateTournamentMutation = useMutation({
    mutationFn: async (updates: Partial<ClubTournament>) => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament', id] });
    },
  });

  // Computed values
  // Registration logic:
  // - Only the first `max_teams` teams are eligible for the draw (confirmed + pending).
  // - Waiting teams must NOT appear in the draw participants list.
  const maxTeams = useMemo(() => tournament?.max_teams || 0, [tournament?.max_teams]);

  const waitingTeams = useMemo(
    () => teams.filter(t => t.status === 'waiting'),
    [teams]
  );

  const registeredTeams = useMemo(
    () => teams
      .filter(t => t.status === 'confirmed' || t.status === 'pending')
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()),
    [teams]
  );

  const drawTeams = useMemo(
    () => (maxTeams > 0 ? registeredTeams.slice(0, maxTeams) : registeredTeams),
    [registeredTeams, maxTeams]
  );

  // Effect to restore draw when page loads
  useEffect(() => {
    const restoreDraw = async () => {
      if (tournament?.draw_generated && tournament.random_seed && drawTeams.length >= 2 && !localDraw) {
        const result = generateDraw(tournament as any, drawTeams, tournament.random_seed);
        
        if (tournament.draw_locked) {
          const { data: dbMatches } = await supabase
            .from('tournament_matches')
            .select('*')
            .eq('tournament_id', id)
            .order('round_order')
            .order('match_order');

          // --- Repair: some older tournaments were saved with only round_order=0 (first round).
          // Without placeholder matches for later rounds, KO progression (quarters -> semis -> final)
          // cannot advance and TV display misses the next rounds.
          try {
            if ((tournament.format === 'knockout' || tournament.format === 'direct_entry') && Array.isArray(dbMatches) && dbMatches.length > 0) {
              const ko = dbMatches.filter((m) => !m.group_id && !String(m.round_name || '').startsWith('Poule ') && !String(m.round_name || '').startsWith('Tableau final'));
              const firstRoundCount = ko.filter((m) => m.round_order === 0).length;
              const maxRound = ko.length ? Math.max(...ko.map((m) => m.round_order)) : 0;
              const expectedTotal = firstRoundCount > 0 ? (2 * firstRoundCount - 1) : 0;

              const nameForRemainingTeams = (remainingTeams: number, roundOrder: number) => {
                if (remainingTeams === 2) return 'Finale';
                if (remainingTeams === 4) return 'Demi-finales';
                if (remainingTeams === 8) return 'Quarts de finale';
                if (remainingTeams === 16) return '1/8e de finale';
                if (remainingTeams === 32) return '1/16e de finale';
                if (remainingTeams === 64) return '1/32e de finale';
                if (remainingTeams === 128) return '1/64e de finale';
                return `Tour ${roundOrder + 1}`;
              };

              if (maxRound === 0 && expectedTotal > 0 && ko.length < expectedTotal) {
                const missing: any[] = [];
                const drawSize = firstRoundCount * 2;
                let round = 1;
                let currentMatches = firstRoundCount;
                while (currentMatches >= 2) {
                  currentMatches = Math.floor(currentMatches / 2);
                  const remainingTeams = drawSize / Math.pow(2, round);
                  const roundName = nameForRemainingTeams(remainingTeams, round);
                  for (let mo = 0; mo < currentMatches; mo++) {
                    const exists = ko.some((m) => m.round_order === round && m.match_order === mo);
                    if (!exists) {
                      missing.push({
                        tournament_id: id,
                        round_name: roundName,
                        round_order: round,
                        match_order: mo,
                        team_a_id: null,
                        team_b_id: null,
                        is_bye: false,
                        score_a: null,
                        score_b: null,
                        winner_id: null,
                        completed_at: null,
                        group_id: null,
                      });
                    }
                  }
                  round += 1;
                }

                if (missing.length) {
                  const { data: inserted } = await supabase
                    .from('tournament_matches')
                    .insert(missing)
                    .select();
                  if (Array.isArray(inserted) && Array.isArray(dbMatches)) {
                    dbMatches.push(...(inserted as any));
                    dbMatches.sort((a: any, b: any) => (a.round_order - b.round_order) || (a.match_order - b.match_order));
                  }
                }
              }
            }
          } catch (e) {
            console.warn('KO repair (standard) skipped', e);
          }
          
          if (dbMatches && dbMatches.length > 0) {
            const matchMap = new Map<string, typeof dbMatches[0]>();
            dbMatches.forEach(m => {
              const scope = m.group_id ? `G:${m.group_id}` : (String(m.round_name || '').startsWith('Poule ') ? `P:${m.round_name}` : 'KO');
              matchMap.set(`${m.round_order}-${m.match_order}-${scope}`, m);
            });

            // Map group name -> group_id (from DB)
            const { data: dbGroups } = await supabase
              .from('tournament_groups')
              .select('*')
              .eq('tournament_id', id)
              .order('group_order');
            const groupNameToId = new Map<string, string>();
            (dbGroups || []).forEach(g => groupNameToId.set(g.name, g.id));

            const getGroupIdForMatch = (m: GeneratedMatch, groups: { name: string; team_ids: string[] }[]) => {
              if (!m.team_a_id || !m.team_b_id) return null;
              const g = groups.find(gr => gr.team_ids.includes(m.team_a_id!) && gr.team_ids.includes(m.team_b_id!));
              if (!g) return null;
              return groupNameToId.get(g.name) || null;
            };
            
            const updateMatchesWithDb = (matches: GeneratedMatch[], groups?: { name: string; team_ids: string[] }[]): GeneratedMatch[] => 
              matches.map(m => {
                const isPool = String(m.round_name || '').startsWith('Poule ');
                const groupId =
                  (isPool ? (groupNameToId.get(String(m.round_name)) || (groups ? getGroupIdForMatch(m, groups) : null)) : null);

                const scope = groupId ? `G:${groupId}` : (isPool ? `P:${m.round_name}` : 'KO');
                const dbMatch = matchMap.get(`${m.round_order}-${m.match_order}-${scope}`);

                if (dbMatch) {
                  return {
                    ...m,
                    id: dbMatch.id,
                    group_id: dbMatch.group_id || groupId || undefined,
                    score_a: dbMatch.score_a || undefined,
                    score_b: dbMatch.score_b || undefined,
                    winner_id: dbMatch.winner_id || undefined,
                  };
                }
                return m;
				});

				if (result.knockoutDraw) {
				  result.knockoutDraw.matches = updateMatchesWithDb(result.knockoutDraw.matches);
				}
            if (result.groupDraw) {
              result.groupDraw.matches = updateMatchesWithDb(result.groupDraw.matches, result.groupDraw.groups);
            }
            if (result.roundRobinMatches) {
              result.roundRobinMatches = updateMatchesWithDb(result.roundRobinMatches);
            }

            // If a final bracket already exists in DB (Tableau final%), we must restore it even if
            // the draw engine doesn't generate a knockoutDraw yet (e.g., page opened after pools).
            // Otherwise the organizer won't see / edit / score the final bracket.
            if (
              tournament.format === 'groups_knockout' &&
              !result.knockoutDraw &&
              Array.isArray(dbMatches) &&
              dbMatches.some((m) => String(m.round_name || '').startsWith('Tableau final'))
            ) {
              const finalDb = dbMatches
                .filter((m) => String(m.round_name || '').startsWith('Tableau final'))
                .sort((a, b) => (a.round_order - b.round_order) || (a.match_order - b.match_order));


// --- Repair: older DBs may only have round_order=0 (quarters) because later rounds were not saved.
// If so, create placeholder matches for the missing rounds so the tournament can continue.
try {
  const maxRound = Math.max(...finalDb.map((m) => m.round_order));
  const firstRoundCount = finalDb.filter((m) => m.round_order === 0).length;
  const expectedTotal = firstRoundCount > 0 ? (2 * firstRoundCount - 1) : 0;

  const nameFor = (count: number) => {
    if (count === 1) return 'Finale';
    if (count === 2) return 'Demi-finales';
    if (count === 4) return 'Quarts de finale';
    if (count === 8) return 'Huitièmes de finale';
    if (count === 16) return 'Seizièmes de finale';
    return `Tour ${count}`;
  };

  if ((maxRound === 0) && expectedTotal > 0 && finalDb.length < expectedTotal) {
    const missing: any[] = [];
    let current = firstRoundCount;
    let r = 1;
    while (current >= 2) {
      current = Math.floor(current / 2);
      const roundName = `Tableau final • ${nameFor(current)}`;
      for (let mo = 0; mo < current; mo++) {
        const exists = finalDb.some((m) => m.round_order === r && m.match_order === mo);
        if (!exists) {
          missing.push({
            tournament_id: id,
            round_name: roundName,
            round_order: r,
            match_order: mo,
            team_a_id: null,
            team_b_id: null,
            is_bye: false,
            score_a: null,
            score_b: null,
            winner_id: null,
            completed_at: null,
          });
        }
      }
      r += 1;
    }

    if (missing.length) {
      const { data: inserted } = await supabase
        .from('tournament_matches')
        .insert(missing)
        .select();
      (inserted || []).forEach((m: any) => finalDb.push(m));
      finalDb.sort((a, b) => (a.round_order - b.round_order) || (a.match_order - b.match_order));
    }
  }
} catch (e) {
  console.warn('KO repair skipped', e);
}

              const rounds = Array.from(
                new Map(
                  finalDb.map((m) => {
                    const raw = String(m.round_name || '').replace(/^Tableau final\s*•\s*/i, '');
                    const name = raw || `Tour ${m.round_order + 1}`;
                    return [m.round_order, { name, order: m.round_order }];
                  })
                ).values()
              ).sort((a, b) => a.order - b.order);

              result.knockoutDraw = {
                // slots are optional for rendering/scoring; we keep an empty array to satisfy types.
                slots: [],
                rounds,
                matches: finalDb.map((m) => ({
                  id: m.id,
                  round_name: String(m.round_name || ''),
                  round_order: m.round_order,
                  match_order: m.match_order,
                  team_a_id: m.team_a_id || undefined,
                  team_b_id: m.team_b_id || undefined,
                  score_a: m.score_a || undefined,
                  score_b: m.score_b || undefined,
                  winner_id: m.winner_id || undefined,
                  is_bye: !!m.is_bye,
                })) as any,
              } as any;
            }
          }
        }
        
        setLocalDraw(result);
      }
    };
    
    restoreDraw();
  }, [tournament?.draw_generated, tournament?.random_seed, tournament?.draw_locked, drawTeams.length, id]);

  // Handlers
  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value });
  };

  // If the organizer opens this page after all pool matches were already completed,
  // we still want to auto-generate the final bracket (KO) so it becomes visible.
  const autoFinalGenRanRef = useRef(false);
  useEffect(() => {
    if (autoFinalGenRanRef.current) return;
    if (!tournament) return;
    if (tournament.format !== 'groups_knockout') return;
    if (!localDraw?.groupDraw) return;
    if (localDraw.knockoutDraw) return;

    const groupMatches = localDraw.groupDraw.matches.filter((m) => !m.is_bye);
    const allCompleted = groupMatches.length > 0 && groupMatches.every((m) => !!m.winner_id);
    if (!allCompleted) return;

    autoFinalGenRanRef.current = true;
    // Fire and forget: errors are handled inside maybeGenerateFinalBracket.
    void maybeGenerateFinalBracket();
  }, [tournament, localDraw]);

  const handleGenerateDraw = () => {
    if (drawTeams.length < 2) {
      toast({
        title: 'Pas assez d\'équipes',
        description: 'Il faut au moins 2 équipes inscrites pour générer le tirage.',
        variant: 'destructive',
      });
      return;
    }

    const newSeed = Math.floor(Math.random() * 1000000);
    const result = generateDraw(tournament as any, drawTeams, newSeed);
    
    setLocalDraw(result);
    updateTournamentMutation.mutate({ 
      random_seed: newSeed,
      draw_generated: true,
    });

    toast({
      title: 'Tirage généré',
      description: 'Le tirage au sort a été effectué.',
    });
  };

  // Persist generated matches into DB and back-fill IDs into localDraw.
  // This is required so the Live tab can save scores (it needs match IDs).
  const persistDrawMatches = async (): Promise<boolean> => {
    if (!localDraw) return false;
    try {
      let matchesToSave: GeneratedMatch[] = [];

      const getGroupNameForMatch = (match: GeneratedMatch, groups: { name: string; team_ids: string[] }[]) => {
        if (!match.team_a_id || !match.team_b_id) return null;
        const g = groups.find(gr => gr.team_ids.includes(match.team_a_id!) && gr.team_ids.includes(match.team_b_id!));
        return g ? g.name : null;
      };

      if (localDraw.knockoutDraw) matchesToSave = [...localDraw.knockoutDraw.matches];
      if (localDraw.groupDraw) matchesToSave = [...matchesToSave, ...localDraw.groupDraw.matches];
      if (localDraw.roundRobinMatches) matchesToSave = [...matchesToSave, ...localDraw.roundRobinMatches];

      if (matchesToSave.length === 0) {
        toast({
          title: 'Erreur',
          description: 'Aucun match à sauvegarder. Régénérez le tirage.',
          variant: 'destructive'
        });
        return false;
      }

      // Delete existing matches first
      await supabase.from('tournament_matches').delete().eq('tournament_id', id);

      // Recreate groups and memberships so group_id is stable (needed for correct score sync across poules)
      let groupNameToId = new Map<string, string>();
      if (localDraw?.groupDraw) {
        const { data: existingGroups } = await supabase
          .from('tournament_groups')
          .select('id,name')
          .eq('tournament_id', id);

        const existingGroupIds = (existingGroups || []).map(g => g.id);
        if (existingGroupIds.length) {
          await supabase.from('group_teams').delete().in('group_id', existingGroupIds);
        }
        await supabase.from('tournament_groups').delete().eq('tournament_id', id);

        const groupsToInsert = localDraw.groupDraw.groups.map(g => ({
          tournament_id: id!,
          name: g.name,
          group_order: g.order,
        }));

        const { data: insertedGroups, error: groupsErr } = await supabase
          .from('tournament_groups')
          .insert(groupsToInsert)
          .select();
        if (groupsErr) throw groupsErr;

        (insertedGroups || []).forEach(g => groupNameToId.set(g.name, g.id));

        const groupTeamsToInsert = localDraw.groupDraw.groups.flatMap(g => {
          const gid = groupNameToId.get(g.name);
          if (!gid) return [];
          return g.team_ids.map(teamId => ({ group_id: gid, team_id: teamId }));
        });

        if (groupTeamsToInsert.length) {
          const { error: gtErr } = await supabase.from('group_teams').insert(groupTeamsToInsert);
          if (gtErr) throw gtErr;
        }
      }

      const groupIdForMatch = (match: GeneratedMatch) => {
        const isPool = String(match.round_name || '').startsWith('Poule ');
        if (!isPool) return null;
        const direct = groupNameToId.get(String(match.round_name));
        if (direct) return direct;
        const inferredName = localDraw?.groupDraw ? getGroupNameForMatch(match, localDraw.groupDraw.groups) : null;
        return inferredName ? (groupNameToId.get(inferredName) || null) : null;
      };

      const scopeKeyForMatch = (match: { round_name?: string | null; round_order: number; match_order: number; group_id?: string | null }) => {
        const isPool = String(match.round_name || '').startsWith('Poule ');
        const gid = match.group_id || (isPool ? groupNameToId.get(String(match.round_name)) : null);
        const scope = gid ? `G:${gid}` : (isPool ? `P:${match.round_name}` : 'KO');
        return `${match.round_order}-${match.match_order}-${scope}`;
      };

      const matchRecords = matchesToSave.map(match => {
        const gid = groupIdForMatch(match);
        return ({
          tournament_id: id!,
          round_name: match.round_name,
          round_order: match.round_order,
          match_order: match.match_order,
          group_id: gid,
          team_a_id: match.team_a_id || null,
          team_b_id: match.team_b_id || null,
          is_bye: match.is_bye,
          score_a: match.score_a || null,
          score_b: match.score_b || null,
          winner_id: match.winner_id || null,
        });
      });

      const { data: insertedMatches, error: insertError } = await supabase
        .from('tournament_matches')
        .insert(matchRecords)
        .select();

      if (insertError) throw insertError;

      if (!insertedMatches || insertedMatches.length === 0) {
        toast({ title: 'Erreur', description: 'Aucun match n\'a été sauvegardé.', variant: 'destructive' });
        return false;
      }

      const matchIdMap = new Map<string, string>();
      insertedMatches.forEach(dbMatch => {
        const scope = dbMatch.group_id ? `G:${dbMatch.group_id}` : (String(dbMatch.round_name || '').startsWith('Poule ') ? `P:${dbMatch.round_name}` : 'KO');
        matchIdMap.set(`${dbMatch.round_order}-${dbMatch.match_order}-${scope}`, dbMatch.id);
      });

      setLocalDraw(prev => {
        if (!prev) return prev;
        const assignIds = (matches: GeneratedMatch[]): GeneratedMatch[] =>
          matches.map(m => ({
            ...m,
            id: matchIdMap.get(scopeKeyForMatch({ round_name: m.round_name, round_order: m.round_order, match_order: m.match_order, group_id: (m as any).group_id })) || m.id
          }));

        return {
          ...prev,
          knockoutDraw: prev.knockoutDraw ? { ...prev.knockoutDraw, matches: assignIds(prev.knockoutDraw.matches) } : undefined,
          groupDraw: prev.groupDraw ? { ...prev.groupDraw, matches: assignIds(prev.groupDraw.matches) } : undefined,
          roundRobinMatches: prev.roundRobinMatches ? assignIds(prev.roundRobinMatches) : undefined
        };
      });

      return true;
    } catch (error) {
      console.error('Error saving matches:', error);
      toast({ title: 'Erreur', description: 'Impossible de sauvegarder les matchs.', variant: 'destructive' });
      return false;
    }
  };

  const handleToggleLock = async () => {
    if (!tournament) return;
    const isLocking = !tournament.draw_locked;
    
    // Prevent locking if no draw exists
    if (isLocking && !localDraw) {
      toast({ 
        title: 'Erreur', 
        description: 'Veuillez d\'abord générer le tirage avant de le valider.', 
        variant: 'destructive' 
      });
      return;
    }
    
    if (isLocking && localDraw) {
      const ok = await persistDrawMatches();
      if (!ok) return;
    }
    
    await updateTournamentMutation.mutateAsync({ draw_locked: isLocking });
    queryClient.invalidateQueries({ queryKey: ['tournament', id] });
    
    toast({
      title: isLocking ? 'Tirage verrouillé' : 'Tirage déverrouillé',
      description: isLocking ? 'Le mode tournoi live est maintenant disponible.' : 'Vous pouvez modifier le tirage.',
    });
  };

  // ===== Groups -> Final bracket (auto) =====
  // When the last pool match is completed, we generate the final bracket automatically
  // (taking into account exempt seeds).
  const maybeGenerateFinalBracket = async () => {
    if (!tournament || tournament.format !== 'groups_knockout') return;
    if (!localDraw?.groupDraw) return;

    // All pool matches must be completed
    const groupMatches = localDraw.groupDraw.matches.filter(m => !m.is_bye);
    const allCompleted = groupMatches.length > 0 && groupMatches.every(m => !!m.winner_id);
    if (!allCompleted) return;

    // If final bracket already exists in DB, don't recreate it (unless it's empty)
    const { data: existingFinal, error: existingErr } = await supabase
      .from('tournament_matches')
      .select('id, team_a_id, team_b_id, winner_id, score_a, score_b, completed_at')
      .eq('tournament_id', id)
      .like('round_name', 'Tableau final%');

    if (existingErr) {
      console.warn('final bracket check failed', existingErr);
    } else if ((existingFinal?.length ?? 0) > 0) {
      const knockoutStarted = existingFinal!.some(m => !!m.winner_id || !!m.score_a || !!m.score_b || !!m.completed_at);
      if (knockoutStarted) return;

      // KO exists but hasn't started yet: we can safely recreate it from the current pool standings
      await supabase
        .from('tournament_matches')
        .delete()
        .eq('tournament_id', id)
        .like('round_name', 'Tableau final%');
    }

    // Build standings per group (same tie-break as live standings)
    const parseScores = (scoreA: string, scoreB: string) => {
      const partsA = scoreA ? scoreA.split('/').map(s => parseInt(s) || 0) : [];
      const partsB = scoreB ? scoreB.split('/').map(s => parseInt(s) || 0) : [];
      let setsA = 0, setsB = 0, gamesA = 0, gamesB = 0;
      const maxLen = Math.max(partsA.length, partsB.length);
      for (let i = 0; i < maxLen; i++) {
        const a = partsA[i] || 0;
        const b = partsB[i] || 0;
        gamesA += a;
        gamesB += b;
        if (a > b) setsA++;
        else if (b > a) setsB++;
      }
      return { setsA, setsB, gamesA, gamesB };
    };

    const calcStandings = (teamIds: string[], matches: GeneratedMatch[]) => {
      const stats: Record<string, { wins: number; losses: number; setsDiff: number; gamesDiff: number; points: number }> = {};
      teamIds.forEach(tid => { stats[tid] = { wins: 0, losses: 0, setsDiff: 0, gamesDiff: 0, points: 0 }; });
      matches.forEach(m => {
        if (!m.winner_id || !m.team_a_id || !m.team_b_id) return;
        if (!teamIds.includes(m.team_a_id) || !teamIds.includes(m.team_b_id)) return;
        const { setsA, setsB, gamesA, gamesB } = parseScores(m.score_a || '', m.score_b || '');
        stats[m.team_a_id].setsDiff += (setsA - setsB);
        stats[m.team_b_id].setsDiff += (setsB - setsA);
        stats[m.team_a_id].gamesDiff += (gamesA - gamesB);
        stats[m.team_b_id].gamesDiff += (gamesB - gamesA);
        if (m.winner_id === m.team_a_id) {
          stats[m.team_a_id].wins++; stats[m.team_a_id].points += 2;
          stats[m.team_b_id].losses++; stats[m.team_b_id].points += 1;
        } else if (m.winner_id === m.team_b_id) {
          stats[m.team_b_id].wins++; stats[m.team_b_id].points += 2;
          stats[m.team_a_id].losses++; stats[m.team_a_id].points += 1;
        }
      });
      return teamIds
        .map(tid => ({
          team_id: tid,
          points: stats[tid].points,
          setsDiff: stats[tid].setsDiff,
          gamesDiff: stats[tid].gamesDiff,
        }))
        .sort((a, b) => b.points - a.points || b.setsDiff - a.setsDiff || b.gamesDiff - a.gamesDiff);
    };

    const qualifiersPerGroup = tournament.qualifiers_per_group || 2;
    const groups = localDraw.groupDraw.groups;

    type Qualifier = { team_id: string; groupIndex: number; rank: number };

    const winners: Qualifier[] = [];
    const runners: Qualifier[] = [];

    for (let gi = 0; gi < groups.length; gi++) {
      const g = groups[gi];
      const gMatches = localDraw.groupDraw.matches.filter(m =>
        g.team_ids.includes(m.team_a_id || '') && g.team_ids.includes(m.team_b_id || '')
      );
      const standings = calcStandings(g.team_ids, gMatches);

      for (let r = 0; r < qualifiersPerGroup; r++) {
        const tid = standings[r]?.team_id;
        if (!tid) continue;
        const q: Qualifier = { team_id: tid, groupIndex: gi, rank: r + 1 };
        if (r === 0) winners.push(q);
        else runners.push(q);
      }
    }

    // Generate final bracket structure with exempt seeds already placed
    const seed = (tournament.random_seed || 0) + 777;
    const base = generateFinalBracketForGroups(tournament as any, teams, groups.length, seed);

    // Fill empty non-bye slots with qualifiers.
    // Goals:
    // - Prefer "1er de poule" vs "2e de poule" in the first round.
    // - Avoid same-group matchups in round 1 when possible.
    // - If an exempt seed is present in a first-round match, assign a runner-up against it when possible.

    // Deterministic shuffle (based on tournament seed)
    const seedStr = String((tournament.random_seed || 0) + 777);
    let h = 2166136261;
    for (let i = 0; i < seedStr.length; i++) h = Math.imul(h ^ seedStr.charCodeAt(i), 16777619);
    const rand = () => {
      // mulberry32
      h += 0x6D2B79F5;
      let t = Math.imul(h ^ (h >>> 15), 1 | h);
      t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    const shuffle = <T,>(arr: T[]) => {
      const a = [...arr];
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    };

    const winnersPool = shuffle(winners);
    const runnersPool: Qualifier[] = shuffle(runners);

    const takeRunner = (avoidGroup?: number): Qualifier | undefined => {
      if (runnersPool.length === 0) return undefined;
      if (avoidGroup === undefined) return runnersPool.shift();
      const idx = runnersPool.findIndex(r => r.groupIndex !== avoidGroup);
      if (idx >= 0) return runnersPool.splice(idx, 1)[0];
      // No compatible runner left, fall back
      return runnersPool.shift();
    };

    const takeAnyQualifier = (): Qualifier | undefined => winnersPool.shift() || runnersPool.shift();

    const firstRound = base.matches.filter(m => m.round_order === 0);

    // Standard FFT-friendly mapping when we have 4 poules and 2 qualifiés per poule (8 équipes → quarts)
    // Quarts: 1A-2B, 1B-2A, 1C-2D, 1D-2C
    // This keeps the 1er et 2e de la même poule dans des moitiés opposées (pas de retrouvailles avant la finale).
    if (groups.length === 4 && qualifiersPerGroup === 2 && firstRound.length === 4 && winners.length === 4 && runners.length === 4) {
      const pairs: Array<[number, number]> = [
        [0, 1],
        [1, 0],
        [2, 3],
        [3, 2],
      ];
      // Ensure deterministic order of first round matches
      const orderedFirstRound = [...firstRound].sort((a, b) => a.match_order - b.match_order);
      for (let i = 0; i < orderedFirstRound.length; i++) {
        const m = orderedFirstRound[i];
        const [wG, rG] = pairs[i] || pairs[pairs.length - 1];
        const slotA = base.slots[m.slot_a];
        const slotB = base.slots[m.slot_b];
        if (slotA.is_bye || slotB.is_bye) continue;
        // winners/runners are collected in group order (gi loop), so index == groupIndex
        slotA.team_id = winners[wG]?.team_id;
        slotB.team_id = runners[rG]?.team_id;
      }
      // Clear pools so the generic logic below doesn't re-fill/override
      winnersPool.length = 0;
      runnersPool.length = 0;
    }

    // 1) If a seed is already placed in a first-round match, try to place a runner-up against it
    for (const m of firstRound) {
      const slotA = base.slots[m.slot_a];
      const slotB = base.slots[m.slot_b];
      if (slotA.is_bye || slotB.is_bye) continue;
      const aHas = !!slotA.team_id;
      const bHas = !!slotB.team_id;
      if (aHas === bHas) continue;
      const opp = takeRunner();
      const fallback = opp || takeAnyQualifier();
      if (!fallback) continue;
      if (!aHas) slotA.team_id = fallback.team_id;
      else slotB.team_id = fallback.team_id;
    }

    // 2) Remaining empty matches: "1er" vs "2e" (avoid same group when possible)
    for (const m of firstRound) {
      const slotA = base.slots[m.slot_a];
      const slotB = base.slots[m.slot_b];
      if (slotA.is_bye || slotB.is_bye) continue;
      if (slotA.team_id || slotB.team_id) continue;

      const w = winnersPool.shift();
      if (w) {
        const r = takeRunner(w.groupIndex) || takeAnyQualifier();
        slotA.team_id = w.team_id;
        if (r) slotB.team_id = r.team_id;
      } else {
        // No winners left, just fill with whatever remains
        const q1 = takeAnyQualifier();
        const q2 = takeAnyQualifier();
        if (q1) slotA.team_id = q1.team_id;
        if (q2) slotB.team_id = q2.team_id;
      }
    }

    // 3) Fill any remaining empty slots with remaining qualifiers
    const leftovers = [...winnersPool, ...runnersPool].map(q => q.team_id);
    for (const s of base.slots) {
      if (s.is_bye) continue;
      if (!s.team_id) {
        const next = leftovers.shift();
        if (!next) break;
        s.team_id = next;
      }
    }

    // Rebuild first-round match team ids
const finalMatches: GeneratedMatch[] = base.matches.map(m => {
  const roundLabel = `Tableau final • ${m.round_name}`;
  if (m.round_order !== 0) {
    return {
      ...m,
      round_name: roundLabel,
    };
  }

  const a = base.slots[m.slot_a];
  const b = base.slots[m.slot_b];
  const isBye = a.is_bye || b.is_bye;
  let winner: string | undefined;
  if (isBye) {
    if (a.is_bye && b.team_id) winner = b.team_id;
    if (b.is_bye && a.team_id) winner = a.team_id;
  }
  return {
    ...m,
    round_name: roundLabel,
    team_a_id: a.team_id,
    team_b_id: b.team_id,
    is_bye: isBye,
    winner_id: winner,
  };
});

    // Persist to DB (only final bracket rounds)
    try {
      await supabase
        .from('tournament_matches')
        .delete()
        .eq('tournament_id', id)
        .like('round_name', 'Tableau final%');

      const records = finalMatches.map(m => ({
        tournament_id: id,
        round_name: m.round_name,
        round_order: m.round_order,
        match_order: m.match_order,
        team_a_id: m.team_a_id || null,
        team_b_id: m.team_b_id || null,
        is_bye: m.is_bye,
        winner_id: m.winner_id || null,
      }));

      await supabase.from('tournament_matches').insert(records);

      // Update local state so the KO tab + TV can show it immediately
      setLocalDraw(prev => {
        if (!prev) return prev;
        return { ...prev, knockoutDraw: { slots: base.slots, matches: finalMatches, rounds: base.rounds } };
      });
      queryClient.invalidateQueries({ queryKey: ['tournament-matches', id] });
      queryClient.invalidateQueries({ queryKey: ['tournament-matches-public', id] });

      toast({
        title: 'Tableau final généré',
        description: 'Le tableau final a été généré automatiquement à la fin des poules.',
      });
    } catch (e) {
      console.error('final bracket generation failed', e);
      toast({
        title: 'Erreur',
        description: 'Impossible de générer le tableau final automatiquement.',
        variant: 'destructive',
      });
    }
  };

  const syncFinalBracketWithPools = async () => {
    if (!tournament || tournament.format !== 'groups_knockout') return;

    // If no group draw loaded, nothing to sync
    if (!localDraw?.groupDraw) return;

    const groupMatches = localDraw.groupDraw.matches.filter(m => !m.is_bye);
    const allCompleted = groupMatches.length > 0 && groupMatches.every(m => !!m.winner_id);

    // Check if KO already started
    const { data: existingFinal } = await supabase
      .from('tournament_matches')
      .select('id, score_a, score_b, winner_id')
      .eq('tournament_id', id)
      .like('round_name', 'Tableau final%');

    const koStarted = (existingFinal || []).some(m => !!m.winner_id || !!m.score_a || !!m.score_b);
    const koExists = (existingFinal || []).length > 0;

    // If pools are not complete anymore, and KO not started, delete KO bracket
    if (!allCompleted) {
      if (koExists && !koStarted) {
        await supabase
          .from('tournament_matches')
          .delete()
          .eq('tournament_id', id)
          .like('round_name', 'Tableau final%');

        setLocalDraw(prev => {
          if (!prev) return prev;
          return { ...prev, knockoutDraw: undefined } as any;
        });
      }
      return;
    }

    // If pools are complete and KO exists but not started, we allow regeneration (so corrections in pools update the bracket)
    if (allCompleted && koExists && !koStarted) {
      await supabase
        .from('tournament_matches')
        .delete()
        .eq('tournament_id', id)
        .like('round_name', 'Tableau final%');

      setLocalDraw(prev => {
        if (!prev) return prev;
        return { ...prev, knockoutDraw: undefined } as any;
      });
    }
  };

  const advanceKnockoutFromMatch = async (matchId: string, winnerTeamId: string | null) => {
    const draw = localDrawRef.current;
    if (!draw?.knockoutDraw) return;

    const current = draw.knockoutDraw.matches.find((m) => m.id === matchId);
    if (!current) return;

    const nextRound = current.round_order + 1;
    const nextMatchOrder = Math.floor(current.match_order / 2);
    const slot = current.match_order % 2 === 0 ? 'a' : 'b';

    const next = draw.knockoutDraw.matches.find(
      (m) => m.round_order === nextRound && m.match_order === nextMatchOrder,
    );
    if (!next) return;

    const field = slot === 'a' ? 'team_a_id' : 'team_b_id';
    const currentValue = (next as any)[field] as string | null;

    // If nothing changes, do nothing
    if ((currentValue || null) === (winnerTeamId || null)) return;

    // Update DB: place winner in the right slot, and clear the next match score (it becomes invalid)
    await supabase
      .from('tournament_matches')
      .update({
        [field]: winnerTeamId,
        score_a: null,
        score_b: null,
        winner_id: null,
        completed_at: null,
      })
      .eq('id', next.id);

    // Update local state
    setLocalDraw((prev) => {
      if (!prev?.knockoutDraw) return prev;
      return {
        ...prev,
        knockoutDraw: {
          ...prev.knockoutDraw,
          matches: prev.knockoutDraw.matches.map((m) => {
            if (m.id !== next.id) return m;
            return {
              ...m,
              [field]: winnerTeamId,
              score_a: null,
              score_b: null,
              winner_id: '',
              completed_at: null,
            } as any;
          }),
        },
      };
    });

    // Recursively clear/advance further rounds based on the (now cleared) next match
    await advanceKnockoutFromMatch(next.id, null);
  };


  const handleScoreUpdate = async (matchId: string, scoreA: string, scoreB: string, winnerId: string, resultType: 'normal' | 'wo' | 'dq' | 'not_played' = 'normal') => {
    if (!tournament) return;

    const isClearing = !winnerId || (!scoreA && !scoreB);
    const completedAt = isClearing ? null : new Date().toISOString();

    try {
      // 1) Update match in DB
      await supabase
        .from('tournament_matches')
        .update({
          score_a: scoreA || null,
          score_b: scoreB || null,
          winner_id: winnerId || null,
          completed_at: completedAt,
          result_type: resultType || 'normal',
        } as any)
        .eq('id', matchId);

      // 2) Update local state (immediate UI refresh)
      setLocalDraw(prev => {
        if (!prev) return prev;

        const updateMatches = (matches: any[]) =>
          matches.map(m =>
            m.id === matchId
              ? {
                  ...m,
                  score_a: scoreA,
                  score_b: scoreB,
                  winner_id: winnerId,
                  completed_at: completedAt,
                  result_type: resultType || 'normal',
                }
              : m
          );

        return {
          ...prev,
          groupDraw: prev.groupDraw ? { ...prev.groupDraw, matches: updateMatches(prev.groupDraw.matches) } : prev.groupDraw,
          knockoutDraw: prev.knockoutDraw ? { ...prev.knockoutDraw, matches: updateMatches(prev.knockoutDraw.matches) } : prev.knockoutDraw,
        };
      });

      // 3) KO progression (winner goes to next round, and undo clears downstream)
      const drawNow = localDrawRef.current;
      const isKo = !!drawNow?.knockoutDraw?.matches.some(m => m.id === matchId);
      if (isKo) {
        await advanceKnockoutFromMatch(matchId, isClearing ? null : winnerId);
      }

      toast({
        title: isClearing ? 'Score effacé' : 'Score enregistré',
        description: 'Classement / tableau mis à jour.',
      });

      // 4) If pool scores change, keep the final bracket synced (only if KO not started)
      await syncFinalBracketWithPools();

      // 5) Generate (or regenerate) final bracket automatically once pools are done
      await maybeGenerateFinalBracket();
    } catch (error) {
      console.error(error);
      toast({ title: 'Erreur', description: "Impossible d'enregistrer le score.", variant: 'destructive' });
    }
  };

  const handleUpdateMatchTeams = async (matchId: string, teamAId: string | null, teamBId: string | null) => {
    if (!tournament) return;
    if (teamAId && teamBId && teamAId === teamBId) {
      toast({
        title: 'Impossible',
        description: "Une équipe ne peut pas être des deux côtés du match.",
        variant: 'destructive',
      });
      return;
    }

    try {
      // Organizer override use-case:
      // You may want to swap/interchange quarter-finals etc.
      // If a selected team is already present in another match of the SAME round,
      // we automatically clear it from that other match to keep the bracket consistent.
      const drawNow = localDrawRef.current;
      const koMatches = drawNow?.knockoutDraw?.matches ?? [];
      const currentMatch = koMatches.find((m) => m.id === matchId);
      const currentRound = currentMatch?.round_order;

      const selectedIds = new Set<string>([teamAId, teamBId].filter(Boolean) as string[]);
      const conflictingMatches = (currentRound === undefined)
        ? []
        : koMatches.filter((m) =>
            m.id !== matchId &&
            m.round_order === currentRound &&
            ( (m.team_a_id && selectedIds.has(m.team_a_id)) || (m.team_b_id && selectedIds.has(m.team_b_id)) )
          );

      // 0) Clear conflicts first (DB + local state + downstream)
      for (const m of conflictingMatches) {
        const newA = (m.team_a_id && selectedIds.has(m.team_a_id)) ? null : (m.team_a_id ?? null);
        const newB = (m.team_b_id && selectedIds.has(m.team_b_id)) ? null : (m.team_b_id ?? null);

        await supabase
          .from('tournament_matches')
          .update({
            team_a_id: newA,
            team_b_id: newB,
            score_a: null,
            score_b: null,
            winner_id: null,
            completed_at: null,
          })
          .eq('id', m.id);

        // Clear downstream from that match
        await advanceKnockoutFromMatch(m.id!, null);
      }

      // 1) Update match participants and clear score/winner to avoid inconsistencies
      await supabase
        .from('tournament_matches')
        .update({
          team_a_id: teamAId,
          team_b_id: teamBId,
          score_a: null,
          score_b: null,
          winner_id: null,
          completed_at: null,
        })
        .eq('id', matchId);

      // 2) Update local state
      setLocalDraw((prev) => {
        if (!prev?.knockoutDraw) return prev;
        return {
          ...prev,
          knockoutDraw: {
            ...prev.knockoutDraw,
            matches: prev.knockoutDraw.matches.map((m) =>
              // apply conflict clears
              (conflictingMatches.some((x) => x.id === m.id))
                ? {
                    ...m,
                    team_a_id: (m.team_a_id && selectedIds.has(m.team_a_id)) ? null : (m.team_a_id ?? null),
                    team_b_id: (m.team_b_id && selectedIds.has(m.team_b_id)) ? null : (m.team_b_id ?? null),
                    score_a: '',
                    score_b: '',
                    winner_id: '',
                    completed_at: null,
                  }
                : (m.id === matchId
                    ? {
                        ...m,
                        team_a_id: teamAId,
                        team_b_id: teamBId,
                        score_a: '',
                        score_b: '',
                        winner_id: '',
                        completed_at: null,
                      }
                    : m)
            ),
          },
        };
      });

      // 3) Clear downstream bracket slots (winner removed)
      await advanceKnockoutFromMatch(matchId, null);

      toast({
        title: 'Match corrigé',
        description: conflictingMatches.length > 0
          ? `Participants mis à jour. ${conflictingMatches.length} conflit(s) du même tour ont été automatiquement nettoyés. Les scores/tours suivants ont été réinitialisés.`
          : 'Participants mis à jour. Score et tours suivants ont été réinitialisés.',
      });

      queryClient.invalidateQueries({ queryKey: ['tournament-matches', id] });
      queryClient.invalidateQueries({ queryKey: ['tournament-matches-public', id] });
    } catch (e) {
      console.error(e);
      toast({ title: 'Erreur', description: 'Impossible de modifier ce match.', variant: 'destructive' });
    }
  };


const handleUpdateTeamSeedRank = async (teamId: string, seedRank: number | null) => {
  try {
    await supabase
      .from('tournament_teams')
      .update({ seed_rank: seedRank })
      .eq('id', teamId);

    // Refresh teams so the UI shows updated ordering/labels
    queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
  } catch (e) {
    console.error('seed_rank update failed', e);
    toast({ title: 'Erreur', description: 'Impossible de mettre à jour la tête de série.', variant: 'destructive' });
  }
};

  const handleExportCSV = () => {
    if (!localDraw || !tournament) return;
    
    let matches: GeneratedMatch[] = [];
    if (localDraw.knockoutDraw) matches = localDraw.knockoutDraw.matches;
    else if (localDraw.groupDraw) matches = localDraw.groupDraw.matches;
    else if (localDraw.roundRobinMatches) matches = localDraw.roundRobinMatches;

    const csv = exportMatchesToCSV(matches, teams);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tirage-${tournament.title.replace(/\s+/g, '-').toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({ title: 'Export réussi', description: 'Le tirage a été exporté.' });
  };

  const handlePrintGroupsPDF = () => {
    const groupDraw = localDraw?.groupDraw;
    if (!groupDraw) {
      toast({ variant: 'destructive', title: 'Impossible', description: 'Aucune phase de poules à imprimer.' });
      return;
    }

    const escapeHtml = (s: string) =>
      s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');

    const teamName = (id?: string) => {
      if (!id) return 'TBD';
      return teams.find(t => t.id === id)?.name ?? 'TBD';
    };

    const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(tournament.title)} — Poules</title>
  <style>
    @page { size: A4; margin: 14mm; }
    body { font-family: Arial, Helvetica, sans-serif; color: #111; }
    .page { page-break-after: always; }
    .header { display:flex; justify-content:space-between; align-items:flex-end; border-bottom:2px solid #111; padding-bottom:8px; margin-bottom:10px; }
    .title { font-size: 20px; font-weight: 800; }
    .meta { font-size: 12px; text-align:right; color:#333; }
    .poule { font-size: 18px; font-weight: 800; margin: 8px 0 10px; }
    table { width:100%; border-collapse: collapse; }
    th, td { border: 1px solid #111; padding: 8px; font-size: 13px; }
    th { background:#f2f2f2; text-transform: uppercase; font-size: 12px; letter-spacing: .04em; }
    .blank { height: 20px; }
    .section-title { margin-top: 14px; margin-bottom: 8px; font-weight: 800; text-transform: uppercase; font-size: 12px; letter-spacing: .06em; }
    .match { border: 1px solid #111; border-radius: 8px; padding: 8px 10px; margin-bottom: 8px; }
    .match-top { font-size: 12px; color:#333; font-weight:700; margin-bottom:4px; }
    .match-main { font-size: 14px; font-weight: 800; }
  </style>
</head>
<body>
  ${groupDraw.groups.map((g) => {
      const teamIds = g.team_ids;
      const matches = groupDraw.matches
        .filter(m => teamIds.includes(m.team_a_id || '') && teamIds.includes(m.team_b_id || ''))
        .slice()
        .sort((a, b) => (a.match_order ?? 0) - (b.match_order ?? 0));

      const rows = teamIds.map((id, i) => `
        <tr>
          <td style="width:40px; text-align:center; font-weight:700;">${i+1}</td>
          <td>${escapeHtml(teamName(id))}</td>
          <td style="width:70px;" class="blank"></td>
          <td style="width:90px;" class="blank"></td>
          <td style="width:70px;" class="blank"></td>
        </tr>
      `).join('');

      const matchesHtml = matches.map((m, idx) => `
        <div class="match">
          <div class="match-top">Match ${idx+1} — ${escapeHtml(g.name)}</div>
          <div class="match-main">${escapeHtml(teamName(m.team_a_id))}  vs  ${escapeHtml(teamName(m.team_b_id))}</div>
        </div>
      `).join('');

      return `
      <div class="page">
        <div class="header">
          <div>
            <div class="title">${escapeHtml(tournament.title)}</div>
          </div>
          <div class="meta">
            <div>${escapeHtml(tournament.start_date)}</div>
            <div>${escapeHtml(tournament.city || '')}</div>
            <div>${escapeHtml(tournament.referee_name || '')}</div>
          </div>
        </div>

        <div class="poule">${escapeHtml(g.name)}</div>

        <div class="section-title">Tableau de poule (à compléter au stylo)</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Équipe</th>
              <th style="width:70px;">Cl.</th>
              <th style="width:90px;">Diff sets</th>
              <th style="width:70px;">Pts</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>

        <div class="section-title">Ordre des matchs</div>
        ${matchesHtml || '<div style="color:#666; font-size:12px;">Aucun match généré.</div>'}
      </div>`;
    }).join('')}
</body>
</html>`;

    const win = window.open('', '_blank');
    if (!win) {
      toast({ variant: 'destructive', title: 'Pop-up bloquée', description: 'Autorisez les pop-ups pour imprimer.' });
      return;
    }
    win.document.open();
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 300);
  };


  if (!isAuthenticated) {
    return <Navigate to="/club/login" replace />;
  }

  if (tournamentLoading || teamsLoading) {
    return (
      <Layout hideFooter>
        <div className="min-h-screen bg-muted/30 flex items-center justify-center">
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </Layout>
    );
  }

  if (!tournament || tournament.club_id !== club?.id) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/club/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const getFormatLabel = (format: string) => {
    switch (format) {
      case 'knockout': return 'Élimination directe';
      case 'groups_knockout': return 'Poules + Élimination';
      case 'round_robin': return 'Championnat';
      case 'direct_entry': return 'Entrée directe';
      default: return format;
    }
  };

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        {/* Header */}
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to="/club/dashboard"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold">{tournament.title}</h1>
                <div className="flex items-center gap-3 mt-1">
                  <Badge variant="outline">{getFormatLabel(tournament.format)}</Badge>
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {maxTeams > 0 ? `${Math.min(drawTeams.length, maxTeams)}/${maxTeams}` : drawTeams.length} équipes
                    {waitingTeams.length > 0 ? ` (+${waitingTeams.length} attente)` : ''}
                  </span>
                  {tournament.draw_locked && (
                    <Badge variant="secondary" className="gap-1">
                      <Lock className="h-3 w-3" />
                      Tirage validé
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                {tournament.draw_locked && (
                  <Button variant="outline" asChild>
                    <a href={`/live/${id}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Affichage TV
                    </a>
                  </Button>
                )}
                {tournament.draw_locked && isTournamentFinished && (
                  <Button onClick={() => handleTabChange('final')}>
                    <Medal className="mr-2 h-4 w-4" />
                    Tournoi fini • Classement
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="container py-6">
          <Tabs value={currentTab} onValueChange={handleTabChange} className="space-y-6">
            <TabsList className="grid w-full max-w-2xl grid-cols-4">
              <TabsTrigger value="payments" className="gap-2">
                <CreditCard className="h-4 w-4" />
                <span className="hidden sm:inline">Paiements</span>
              </TabsTrigger>
              <TabsTrigger value="draw" className="gap-2">
                <Shuffle className="h-4 w-4" />
                <span className="hidden sm:inline">Tirage</span>
              </TabsTrigger>
              <TabsTrigger value="live" className="gap-2" disabled={!tournament.draw_locked}>
                <Trophy className="h-4 w-4" />
                <span className="hidden sm:inline">Tournoi Live</span>
              </TabsTrigger>
              <TabsTrigger value="final" className="gap-2" disabled={!tournament.draw_locked}>
                <Medal className="h-4 w-4" />
                <span className="hidden sm:inline">Classement</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="payments">
              <PaymentLicenseTab 
                tournament={tournament}
                teams={teams}
                players={players}
                onTeamUpdate={() => queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] })}
              />
            </TabsContent>

            <TabsContent value="draw">
              <DrawTab
                tournament={tournament}
                teams={teams}
                confirmedTeams={drawTeams}
                localDraw={localDraw}
                onGenerateDraw={handleGenerateDraw}
                onRegenerateDraw={handleGenerateDraw}
                onToggleLock={handleToggleLock}
                onExportCSV={handleExportCSV}
                onPrintGroupsPDF={handlePrintGroupsPDF}
                onUpdateTournament={(updates) => updateTournamentMutation.mutate(updates)}
                onUpdateTeamSeedRank={handleUpdateTeamSeedRank}
                onUpdateLocalDraw={(next) => setLocalDraw(next as any)}
              />
            </TabsContent>

            <TabsContent value="live">
              {tournament.draw_locked && localDraw ? (
                <LiveTournamentTab
                  tournament={tournament}
                  teams={teams}
                  localDraw={localDraw}
                  onScoreUpdate={handleScoreUpdate}
                  onUpdateMatchTeams={handleUpdateMatchTeams}
                  onPersistDrawMatches={persistDrawMatches}
                />
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Lock className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Mode tournoi non disponible</h3>
                    <p className="text-muted-foreground mb-4">
                      Vous devez d'abord générer et valider le tirage au sort.
                    </p>
                    <Button onClick={() => handleTabChange('draw')}>
                      <Shuffle className="mr-2 h-4 w-4" />
                      Aller au tirage
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="final">
              {tournament.draw_locked && localDraw ? (
                <FinalResultsTab tournament={tournament} teams={teams} localDraw={localDraw} />
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Lock className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Classement non disponible</h3>
                    <p className="text-muted-foreground mb-4">
                      Vous devez d'abord générer et valider le tirage au sort.
                    </p>
                    <Button onClick={() => handleTabChange('draw')}>
                      <Shuffle className="mr-2 h-4 w-4" />
                      Aller au tirage
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default TournamentManagement;
