import { useState, useRef } from 'react';
import { Link, useParams, Navigate } from 'react-router-dom';
import { parseISO } from 'date-fns';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { TournamentTeam, ClubTournament } from '@/types/tournament';
import { parseTeamsCSV, exportTeamsToCSV } from '@/lib/drawEngine';
import { checkTeamCutEligibility } from '@/lib/fftCompliance';
import { ArrowLeft, Download, Upload, Plus, Users, Trash2, Edit, CreditCard, AlertTriangle, CheckCircle, XCircle, IdCard } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

// Extended team type with player license info from players table
interface TeamWithLicenses extends TournamentTeam {
  player1_license?: string | null;
  player2_license?: string | null;
  player1_ranking?: string | null;
  player2_ranking?: string | null;
  fft_eligible?: boolean;
  fft_problems?: string[];
}

// Payment status badge component
const PaymentStatusBadge = ({ 
  player1Status, 
  player2Status,
  player1Name,
  player2Name,
}: { 
  player1Status: string; 
  player2Status: string;
  player1Name: string;
  player2Name?: string;
}) => {
  const p1Paid = player1Status === 'paid';
  const p2Paid = player2Status === 'paid';
  
  if (p1Paid && p2Paid) {
    return (
      <Tooltip>
        <TooltipTrigger>
          <Badge variant="default" className="bg-success hover:bg-success/90">
            <CheckCircle className="h-3 w-3 mr-1" />
            Complet
          </Badge>
        </TooltipTrigger>
        <TooltipContent>Les deux joueurs ont payé</TooltipContent>
      </Tooltip>
    );
  }
  
  if (p1Paid || p2Paid) {
    const paidPlayer = p1Paid ? player1Name : player2Name;
    const unpaidPlayer = p1Paid ? player2Name : player1Name;
    return (
      <Tooltip>
        <TooltipTrigger>
          <Badge variant="secondary" className="bg-warning/20 text-warning border-warning">
            <CreditCard className="h-3 w-3 mr-1" />
            1/2
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-left">
            <p className="text-success">✓ {paidPlayer?.split(' ')[0]} a payé</p>
            <p className="text-destructive">✗ {unpaidPlayer?.split(' ')[0]} n'a pas payé</p>
          </div>
        </TooltipContent>
      </Tooltip>
    );
  }
  
  return (
    <Tooltip>
      <TooltipTrigger>
        <Badge variant="destructive">
          <XCircle className="h-3 w-3 mr-1" />
          0/2
        </Badge>
      </TooltipTrigger>
      <TooltipContent>Aucun paiement reçu</TooltipContent>
    </Tooltip>
  );
};

// License status badge component
const LicenseStatusBadge = ({ 
  player1HasLicense, 
  player2HasLicense 
}: { 
  player1HasLicense: boolean; 
  player2HasLicense: boolean; 
}) => {
  if (player1HasLicense && player2HasLicense) {
    return (
      <Tooltip>
        <TooltipTrigger>
          <Badge variant="outline" className="text-success border-success">
            <CheckCircle className="h-3 w-3 mr-1" />
            OK
          </Badge>
        </TooltipTrigger>
        <TooltipContent>Tous les joueurs ont une licence</TooltipContent>
      </Tooltip>
    );
  }
  
  const missing = [];
  if (!player1HasLicense) missing.push('Joueur 1');
  if (!player2HasLicense) missing.push('Joueur 2');
  
  return (
    <Tooltip>
      <TooltipTrigger>
        <Badge variant="destructive" className="bg-destructive/20 text-destructive border-destructive">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Manquante
        </Badge>
      </TooltipTrigger>
      <TooltipContent>Sans licence: {missing.join(', ')}</TooltipContent>
    </Tooltip>
  );
};

const TournamentTeams = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, club } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingTeam, setEditingTeam] = useState<TournamentTeam | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    player1_name: '',
    player1_email: '',
    player2_name: '',
    player2_email: '',
    seed_rank: '',
    status: 'confirmed' as 'confirmed' | 'pending' | 'waiting',
  });

  // Fetch tournament
  const { data: tournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ['tournament', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data as ClubTournament | null;
    },
    enabled: !!id && isAuthenticated,
  });

  // Fetch teams with player license info
  const { data: teams = [], isLoading: teamsLoading } = useQuery({
    queryKey: ['tournament-teams', id],
    queryFn: async () => {
      // First get teams
      const { data: teamsData, error: teamsError } = await supabase
        .from('tournament_teams')
        .select('*')
        .eq('tournament_id', id)
        .order('seed_rank', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });
      
      if (teamsError) throw teamsError;
      
      // Get all player emails to fetch licenses
      const emails = teamsData.flatMap(t => [t.player1_email, t.player2_email].filter(Boolean));
      
      if (emails.length === 0) {
        return teamsData as TeamWithLicenses[];
      }
      
      // Fetch player licenses / ranking.
      // Note: `players` can be protected by RLS (especially after payment/registration hardening).
      // In organizer view we still want to display BOTH players' licenses when available.
      // So we try the direct query first, then fall back to the SECURITY DEFINER RPC for missing licenses.
      const { data: playersData, error: playersErr } = await supabase
        .from('players')
        .select('email, license_number, ranking')
        .in('email', emails);

      const licenseMap = new Map<string, string | null>((playersData || []).map(p => [p.email, p.license_number]));
      const rankingMap = new Map<string, any>((playersData || []).map(p => [p.email, (p as any).ranking]));

      // If RLS blocked the query or we didn't get all rows, hydrate missing license numbers via RPC.
      // This is intentionally limited to license display (ranking may remain null if not readable).
      const uniqueEmails = Array.from(new Set(emails.map(e => String(e).trim()).filter(Boolean)));
      const missingLicenseEmails = uniqueEmails.filter(e => !licenseMap.has(e) || licenseMap.get(e) == null);
      if (playersErr || missingLicenseEmails.length > 0) {
        const rpcResults = await Promise.all(
          missingLicenseEmails.map(async (email) => {
            const { data } = await supabase.rpc('find_player_by_email', { p_email: email });
            const row = Array.isArray(data) ? data[0] : data;
            return { email: row?.email ?? email, license_number: row?.license_number ?? null };
          })
        );

        for (const r of rpcResults) {
          if (r?.email) licenseMap.set(r.email, r.license_number);
        }
      }
      
      // Merge license info
      return teamsData.map(team => {
        const player1_ranking = team.player1_email ? (rankingMap.get(team.player1_email) as any) : null;
        const player2_ranking = team.player2_email ? (rankingMap.get(team.player2_email) as any) : null;
        const eligibility = checkTeamCutEligibility({
          category: (tournament?.category_code as any) || null,
          gender: (tournament?.gender as any) || null,
          player1Ranking: player1_ranking,
          player2Ranking: player2_ranking,
        });
        return {
          ...team,
          player1_license: team.player1_email ? licenseMap.get(team.player1_email) : null,
          player2_license: team.player2_email ? licenseMap.get(team.player2_email) : null,
          player1_ranking,
          player2_ranking,
          fft_eligible: eligibility.eligible,
          fft_problems: eligibility.problems,
        };
      }) as TeamWithLicenses[];
    },
    enabled: !!id && isAuthenticated,
  });

  // Add team mutation
  
  const promoteWaitlistIfNeeded = async () => {
    if (!id || !tournament?.max_teams) return;
    // Count confirmed teams
    const { data: confirmedTeams, error: confirmedErr } = await supabase
      .from('tournament_teams')
      .select('id')
      .eq('tournament_id', id)
      .eq('status', 'confirmed');
    if (confirmedErr) return;

    const confirmedCount = confirmedTeams?.length || 0;
    const maxTeams = tournament.max_teams;
    if (confirmedCount >= maxTeams) return;

    // Promote oldest eligible waiting team
    const { data: waitingTeams, error: waitingErr } = await supabase
      .from('tournament_teams')
      .select('id')
      .eq('tournament_id', id)
      .eq('status', 'waiting')
      .order('created_at', { ascending: true })
      .limit(1);
    if (waitingErr) return;

    const next = waitingTeams?.[0];
    if (!next) return;

    // Validate FFT cut based on player rankings (if known)
    const { data: teamRow } = await supabase
      .from('tournament_teams')
      .select('id, player1_email, player2_email')
      .eq('id', next.id)
      .maybeSingle();

    if (teamRow) {
      const emails = [teamRow.player1_email, teamRow.player2_email].filter(Boolean) as string[];
      const { data: playersData } = await supabase
        .from('players')
        .select('email, ranking')
        .in('email', emails);
      const rankingMap = new Map(playersData?.map(p => [p.email, p.ranking]) || []);
      const eligibility = checkTeamCutEligibility({
        category: (tournament?.category_code as any) || null,
        gender: (tournament?.gender as any) || null,
        player1Ranking: teamRow.player1_email ? (rankingMap.get(teamRow.player1_email) as any) : null,
        player2Ranking: teamRow.player2_email ? (rankingMap.get(teamRow.player2_email) as any) : null,
      });
      if (!eligibility.eligible) {
        // Keep on waitlist and let organizer handle the case
        return;
      }
    }

    await supabase
      .from('tournament_teams')
      .update({ status: 'confirmed' })
      .eq('id', next.id);
  };

  const assertFftEligibleIfConfirming = async (teamData: { player1_email?: string | null; player2_email?: string | null; status?: string }) => {
    if (teamData.status !== 'confirmed') return { ok: true as const };
    const emails = [teamData.player1_email, teamData.player2_email].filter(Boolean) as string[];
    if (emails.length === 0) return { ok: true as const };
    const { data: playersData } = await supabase
      .from('players')
      .select('email, ranking')
      .in('email', emails);
    const rankingMap = new Map(playersData?.map(p => [p.email, p.ranking]) || []);
    const eligibility = checkTeamCutEligibility({
      category: (tournament?.category_code as any) || null,
      gender: (tournament?.gender as any) || null,
      player1Ranking: teamData.player1_email ? (rankingMap.get(teamData.player1_email) as any) : null,
      player2Ranking: teamData.player2_email ? (rankingMap.get(teamData.player2_email) as any) : null,
    });
    if (!eligibility.eligible) {
      return { ok: false as const, reason: eligibility.problems[0] || 'Non conforme FFT' };
    }
    return { ok: true as const };
  };
const addTeamMutation = useMutation({
    mutationFn: async (teamData: Omit<TournamentTeam, 'id' | 'created_at' | 'updated_at'>) => {
      const ok = await assertFftEligibleIfConfirming({
        player1_email: (teamData as any).player1_email,
        player2_email: (teamData as any).player2_email,
        status: (teamData as any).status,
      });
      if (!ok.ok) {
        throw new Error(ok.reason);
      }
      const { data, error } = await supabase
        .from('tournament_teams')
        .insert(teamData)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
      toast({ title: 'Équipe ajoutée', description: 'L\'équipe a été ajoutée au tournoi.' });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      const msg = error instanceof Error ? error.message : "Impossible d'ajouter l'équipe.";
      toast({ title: 'Erreur', description: msg, variant: 'destructive' });
      console.error(error);
    },
  });

  // Update team mutation
  const updateTeamMutation = useMutation({
    mutationFn: async ({ teamId, updates }: { teamId: string; updates: Partial<TournamentTeam> }) => {
      const ok = await assertFftEligibleIfConfirming({
        player1_email: (updates as any).player1_email,
        player2_email: (updates as any).player2_email,
        status: (updates as any).status,
      });
      if (!ok.ok) {
        throw new Error(ok.reason);
      }
      const { data, error } = await supabase
        .from('tournament_teams')
        .update(updates)
        .eq('id', teamId)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
      toast({ title: 'Équipe modifiée', description: 'Les modifications ont été enregistrées.' });
      resetForm();
      setEditingTeam(null);
    },
    onError: (error) => {
      const msg = error instanceof Error ? error.message : "Impossible de modifier l'équipe.";
      toast({ title: 'Erreur', description: msg, variant: 'destructive' });
      console.error(error);
    },
  });

  // Quick seed update (inline)
  const updateSeedMutation = useMutation({
    mutationFn: async ({ teamId, seedRank }: { teamId: string; seedRank: number | null }) => {
      const { error } = await supabase
        .from('tournament_teams')
        .update({ seed_rank: seedRank })
        .eq('id', teamId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
    },
  });

  // Delete team mutation
  const deleteTeamMutation = useMutation({
    mutationFn: async (teamId: string) => {
      const { error } = await supabase
        .from('tournament_teams')
        .delete()
        .eq('id', teamId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
      toast({ title: 'Équipe supprimée', description: 'L\'équipe a été retirée du tournoi.' });
    },
    onError: (error) => {
      toast({ title: 'Erreur', description: 'Impossible de supprimer l\'équipe.', variant: 'destructive' });
      console.error(error);
    },
  });

  // Bulk import mutation
  const bulkImportMutation = useMutation({
    mutationFn: async (teamsData: Array<Omit<TournamentTeam, 'id' | 'created_at' | 'updated_at'>>) => {
      const { data, error } = await supabase
        .from('tournament_teams')
        .insert(teamsData)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
      toast({ title: 'Import réussi', description: `${data.length} équipes importées.` });
    },
    onError: (error) => {
      toast({ title: 'Erreur d\'import', description: 'Impossible d\'importer les équipes.', variant: 'destructive' });
      console.error(error);
    },
  });

  if (!isAuthenticated) {
    return <Navigate to="/club/login" replace />;
  }

  if (tournamentLoading || teamsLoading) {
    return (
      <Layout hideFooter>
        <div className="min-h-screen bg-muted/30 flex items-center justify-center">
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </Layout>
    );
  }

  if (!tournament || tournament.club_id !== club?.id) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/club/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const resetForm = () => {
    setFormData({
      name: '',
      player1_name: '',
      player1_email: '',
      player2_name: '',
      player2_email: '',
      seed_rank: '',
      status: 'confirmed',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const teamData = {
      tournament_id: id!,
      name: formData.name,
      player1_name: formData.player1_name,
      player1_email: formData.player1_email || null,
      player2_name: formData.player2_name || null,
      player2_email: formData.player2_email || null,
      seed_rank: formData.seed_rank ? parseInt(formData.seed_rank) : null,
      status: formData.status,
    };

    if (editingTeam) {
      updateTeamMutation.mutate({ teamId: editingTeam.id, updates: teamData });
    } else {
      addTeamMutation.mutate(teamData as any);
    }
  };

  const handleEdit = (team: TournamentTeam) => {
    setEditingTeam(team);
    setFormData({
      name: team.name,
      player1_name: team.player1_name,
      player1_email: team.player1_email || '',
      player2_name: team.player2_name || '',
      player2_email: team.player2_email || '',
      seed_rank: team.seed_rank?.toString() || '',
      status: team.status,
    });
    setIsAddDialogOpen(true);
  };

  const handleDelete = (teamId: string) => {
    if (confirm('Supprimer cette équipe ?')) {
      deleteTeamMutation.mutate(teamId);
    }
  };

  const handleCSVImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvContent = event.target?.result as string;
      const parsedTeams = parseTeamsCSV(csvContent);
      
      if (parsedTeams.length === 0) {
        toast({ title: 'Fichier vide', description: 'Aucune équipe trouvée dans le CSV.', variant: 'destructive' });
        return;
      }

      const teamsData = parsedTeams.map((t) => ({
        tournament_id: id!,
        name: t.name,
        player1_name: t.player1_name,
        player1_email: t.player1_email || null,
        player2_name: t.player2_name || null,
        player2_email: t.player2_email || null,
        seed_rank: t.seed_rank || null,
        status: (t as any).status || 'confirmed',
      }));

      bulkImportMutation.mutate(teamsData as any);
    };
    reader.readAsText(file);
    
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleExportCSV = () => {
    const csv = exportTeamsToCSV(teams);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `equipes-${tournament.title.replace(/\s+/g, '-').toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({ title: 'Export réussi', description: 'Le fichier CSV a été téléchargé.' });
  };

  const confirmedTeams = teams.filter((t) => t.status === 'confirmed');
  const pendingTeams = teams.filter((t) => t.status === 'pending');
  const waitingTeams = teams.filter((t) => t.status === 'waiting');

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to="/club/dashboard"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold">{tournament.title}</h1>
                <p className="text-muted-foreground">
                  {confirmedTeams.length} équipes confirmées
                  {pendingTeams.length > 0 && ` • ${pendingTeams.length} en attente de paiement`}
                  {waitingTeams.length > 0 && ` • ${waitingTeams.length} en liste d'attente`}
                </p>
              </div>
              <div className="flex gap-2 flex-wrap">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleCSVImport}
                />
                <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="mr-2 h-4 w-4" />
                  Import CSV
                </Button>
                <Button variant="outline" onClick={handleExportCSV} disabled={teams.length === 0}>
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
                <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
                  setIsAddDialogOpen(open);
                  if (!open) {
                    setEditingTeam(null);
                    resetForm();
                  }
                }}>
                  <DialogTrigger asChild>
                    <Button variant="accent">
                      <Plus className="mr-2 h-4 w-4" />
                      Ajouter une équipe
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>{editingTeam ? 'Modifier l\'équipe' : 'Ajouter une équipe'}</DialogTitle>
                      <DialogDescription>
                        {editingTeam ? 'Modifiez les informations de l\'équipe.' : 'Ajoutez manuellement une équipe au tournoi.'}
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nom de l'équipe *</Label>
                        <Input
                          id="name"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="player1_name">Joueur 1 *</Label>
                          <Input
                            id="player1_name"
                            required
                            value={formData.player1_name}
                            onChange={(e) => setFormData({ ...formData, player1_name: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="player1_email">Email Joueur 1</Label>
                          <Input
                            id="player1_email"
                            type="email"
                            value={formData.player1_email}
                            onChange={(e) => setFormData({ ...formData, player1_email: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="player2_name">Joueur 2</Label>
                          <Input
                            id="player2_name"
                            value={formData.player2_name}
                            onChange={(e) => setFormData({ ...formData, player2_name: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="player2_email">Email Joueur 2</Label>
                          <Input
                            id="player2_email"
                            type="email"
                            value={formData.player2_email}
                            onChange={(e) => setFormData({ ...formData, player2_email: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="seed_rank">Tête de série</Label>
                          <Input
                            id="seed_rank"
                            type="number"
                            min="1"
                            placeholder="Ex: 1, 2, 3..."
                            value={formData.seed_rank}
                            onChange={(e) => setFormData({ ...formData, seed_rank: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="status">Statut</Label>
                          <Select
                            value={formData.status}
                            onValueChange={(value: 'confirmed' | 'pending' | 'waiting') => setFormData({ ...formData, status: value })}
                          >
                            <SelectTrigger id="status">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="confirmed">Confirmé</SelectItem>
                              <SelectItem value="pending">En attente de paiement</SelectItem>
                              <SelectItem value="waiting">Liste d'attente</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button type="submit" disabled={addTeamMutation.isPending || updateTeamMutation.isPending}>
                          {editingTeam ? 'Enregistrer' : 'Ajouter'}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8 space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Équipes ({teams.length})
              </CardTitle>
              <CardDescription>
                Gérez les équipes inscrites et attribuez les têtes de série
              </CardDescription>
            </CardHeader>
            <CardContent>
              {teams.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Aucune équipe</h3>
                  <p className="text-muted-foreground mb-4">
                    Ajoutez des équipes manuellement ou importez un fichier CSV
                  </p>
                  <Button variant="accent" onClick={() => setIsAddDialogOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Ajouter une équipe
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-16">TdS</TableHead>
                        <TableHead>Équipe</TableHead>
                        <TableHead>Joueur 1</TableHead>
                        <TableHead>Joueur 2</TableHead>
                        <TableHead>Paiement</TableHead>
                        <TableHead>Licence</TableHead>
                        <TableHead>FFT</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="w-24">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {teams.map((team) => (
                        <TableRow key={team.id}>
                          <TableCell>
                            <Input
                              type="number"
                              inputMode="numeric"
                              min={1}
                              className="h-8 w-14 px-2 text-center"
                              defaultValue={team.seed_rank ?? ''}
                              placeholder="-"
                              onBlur={(e) => {
                                const raw = e.currentTarget.value;
                                const next = raw === '' ? null : Number(raw);
                                if (raw !== '' && (!Number.isFinite(next) || next <= 0)) {
                                  toast({
                                    title: 'Valeur invalide',
                                    description: 'La tête de série doit être un nombre positif.',
                                    variant: 'destructive',
                                  });
                                  e.currentTarget.value = team.seed_rank?.toString() ?? '';
                                  return;
                                }
                                if ((team.seed_rank ?? null) !== (next ?? null)) {
                                  updateSeedMutation.mutate({ teamId: team.id, seedRank: next });
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{team.name}</TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{team.player1_name}</p>
                              {team.player1_license && (
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                  <IdCard className="h-3 w-3" />
                                  {team.player1_license}
                                </p>
                              )}
                              {team.player1_email && (
                                <p className="text-xs text-muted-foreground">{team.player1_email}</p>
                              )}
                              <div className="flex items-center gap-2 mt-1">
                                {team.player1_payment_status === 'paid' ? (
                                  <span className="text-xs text-success flex items-center gap-1">
                                    <CheckCircle className="h-3 w-3" /> Payé
                                  </span>
                                ) : (
                                  <span className="text-xs text-destructive flex items-center gap-1">
                                    <XCircle className="h-3 w-3" /> Non payé
                                  </span>
                                )}
                                {team.player1_has_license === false && (
                                  <span className="text-xs text-warning flex items-center gap-1">
                                    <AlertTriangle className="h-3 w-3" /> Sans licence
                                  </span>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {team.player2_name ? (
                              <div>
                                <p className="font-medium">{team.player2_name}</p>
                                {team.player2_license && (
                                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                                    <IdCard className="h-3 w-3" />
                                    {team.player2_license}
                                  </p>
                                )}
                                {team.player2_email && (
                                  <p className="text-xs text-muted-foreground">{team.player2_email}</p>
                                )}
                                <div className="flex items-center gap-2 mt-1">
                                  {team.player2_payment_status === 'paid' ? (
                                    <span className="text-xs text-success flex items-center gap-1">
                                      <CheckCircle className="h-3 w-3" /> Payé
                                    </span>
                                  ) : (
                                    <span className="text-xs text-destructive flex items-center gap-1">
                                      <XCircle className="h-3 w-3" /> Non payé
                                    </span>
                                  )}
                                  {team.player2_has_license === false && (
                                    <span className="text-xs text-warning flex items-center gap-1">
                                      <AlertTriangle className="h-3 w-3" /> Sans licence
                                    </span>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <PaymentStatusBadge 
                              player1Status={team.player1_payment_status || 'pending'} 
                              player2Status={team.player2_payment_status || 'pending'}
                              player1Name={team.player1_name}
                              player2Name={team.player2_name || undefined}
                            />
                          </TableCell>
                          <TableCell>
                            <LicenseStatusBadge 
                              player1HasLicense={team.player1_has_license !== false} 
                              player2HasLicense={team.player2_has_license !== false} 
                            />
                          </TableCell>
                          <TableCell>
                            {team.fft_eligible !== false ? (
                              <Badge variant="outline" className="text-success border-success">OK</Badge>
                            ) : (
                              <Tooltip>
                                <TooltipTrigger>
                                  <Badge variant="destructive" className="bg-destructive/20 text-destructive border-destructive">
                                    Non
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <div className="text-left space-y-1">
                                    {(team.fft_problems || []).map((p) => (
                                      <p key={p}>{p}</p>
                                    ))}
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                team.status === 'confirmed'
                                  ? 'default'
                                  : team.status === 'pending'
                                  ? 'secondary'
                                  : 'outline'
                              }
                            >
                              {
                                team.status === 'confirmed'
                                  ? 'Confirmé'
                                  : team.status === 'pending'
                                  ? 'En attente de paiement'
                                  : "Liste d'attente"
                              }
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEdit(team)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(team.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Navigation vers le tirage */}
          <div className="flex justify-end flex-col items-end gap-2">
            {canGenerateDraw ? (
              <Button asChild variant="accent" size="lg">
                <Link to={`/club/tournaments/${id}/draw`}>
                  Générer le tirage →
                </Link>
              </Button>
            ) : (
              <>
                <Button variant="accent" size="lg" disabled>
                  Générer le tirage →
                </Button>
                <p className="text-sm text-amber-600">
                  Le tirage est disponible uniquement à partir de 24h avant le début du tournoi.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TournamentTeams;
