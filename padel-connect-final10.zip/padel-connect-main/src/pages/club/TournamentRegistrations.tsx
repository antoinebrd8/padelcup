import { useMemo, useState } from 'react';
import { Link, useParams, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { mockTournaments, mockRegistrations } from '@/data/mockData';
import { Match, Registration } from '@/types';
import { ArrowLeft, Download, Users, Shuffle } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const TournamentRegistrations = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, club } = useAuth();
  const { toast } = useToast();
  const [bracket, setBracket] = useState<Match[] | null>(null);

  const tournament = mockTournaments.find((t) => t.id === id);
  const registrations = useMemo(
    () => mockRegistrations.filter((r) => r.tournament_id === id),
    [id]
  );

  if (!isAuthenticated) {
    return <Navigate to="/club/login" replace />;
  }

  if (!tournament || tournament.club_id !== club?.id) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/club/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const exportCSV = () => {
    const headers = ['Équipe', 'Joueur 1', 'Email 1', 'Joueur 2', 'Email 2', 'Date inscription'];
    const rows = registrations.map((r) => [
      r.team_name || '-',
      r.player1_name,
      r.player1_email,
      r.player2_name,
      r.player2_email,
      format(new Date(r.created_at), 'dd/MM/yyyy HH:mm', { locale: fr }),
    ]);

    const csv = [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `inscriptions-${tournament.title.replace(/\s+/g, '-').toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: 'Export réussi',
      description: 'Le fichier CSV a été téléchargé.',
    });
  };

  const generateBracket = () => {
    if (registrations.length < 2) {
      toast({
        title: 'Pas assez d\'équipes',
        description: 'Il faut au moins 2 équipes pour générer un tableau.',
        variant: 'destructive',
      });
      return;
    }

    // Shuffle teams
    const shuffled = [...registrations].sort(() => Math.random() - 0.5);
    
    // Generate matches
    const matches: Match[] = [];
    for (let i = 0; i < shuffled.length; i += 2) {
      const teamA = shuffled[i].team_name || `${shuffled[i].player1_name} / ${shuffled[i].player2_name}`;
      const teamB = shuffled[i + 1]
        ? shuffled[i + 1].team_name || `${shuffled[i + 1].player1_name} / ${shuffled[i + 1].player2_name}`
        : 'BYE';
      
      matches.push({
        match: Math.floor(i / 2) + 1,
        teamA,
        teamB,
      });
    }

    setBracket(matches);
    toast({
      title: 'Tableau généré',
      description: `${matches.length} matchs créés pour le premier tour.`,
    });
  };

  const exportBracketCSV = () => {
    if (!bracket) return;

    const headers = ['Match', 'Équipe A', 'Équipe B'];
    const rows = bracket.map((m) => [m.match.toString(), m.teamA, m.teamB]);

    const csv = [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tableau-${tournament.title.replace(/\s+/g, '-').toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: 'Export réussi',
      description: 'Le tableau a été téléchargé.',
    });
  };

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to="/club/dashboard"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold">{tournament.title}</h1>
                <p className="text-muted-foreground">
                  {registrations.length} / {tournament.max_teams} équipes inscrites
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={exportCSV}>
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
                <Button variant="accent" onClick={generateBracket}>
                  <Shuffle className="mr-2 h-4 w-4" />
                  Générer tableau
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8 space-y-8">
          {/* Registrations List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Équipes inscrites
              </CardTitle>
              <CardDescription>
                Liste de toutes les équipes inscrites à ce tournoi
              </CardDescription>
            </CardHeader>
            <CardContent>
              {registrations.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Aucune inscription</h3>
                  <p className="text-muted-foreground">
                    Les équipes inscrites apparaîtront ici
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>Équipe</TableHead>
                        <TableHead>Joueur 1</TableHead>
                        <TableHead>Joueur 2</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {registrations.map((reg, index) => (
                        <TableRow key={reg.id}>
                          <TableCell className="font-medium">{index + 1}</TableCell>
                          <TableCell>
                            {reg.team_name || <span className="text-muted-foreground">-</span>}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{reg.player1_name}</p>
                              <p className="text-xs text-muted-foreground">{reg.player1_email}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{reg.player2_name}</p>
                              <p className="text-xs text-muted-foreground">{reg.player2_email}</p>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {format(new Date(reg.created_at), 'd MMM yyyy', { locale: fr })}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Bracket */}
          {bracket && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Tableau Premier Tour</CardTitle>
                    <CardDescription>
                      {bracket.length} matchs générés
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={exportBracketCSV}>
                    <Download className="mr-2 h-4 w-4" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {bracket.map((match) => (
                    <div
                      key={match.match}
                      className="border rounded-lg p-4 bg-muted/30"
                    >
                      <div className="text-xs text-muted-foreground mb-2">
                        Match {match.match}
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 bg-background rounded">
                          <span className="font-medium truncate">{match.teamA}</span>
                        </div>
                        <div className="text-center text-xs text-muted-foreground">VS</div>
                        <div className="flex items-center justify-between p-2 bg-background rounded">
                          <span className="font-medium truncate">{match.teamB}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default TournamentRegistrations;
