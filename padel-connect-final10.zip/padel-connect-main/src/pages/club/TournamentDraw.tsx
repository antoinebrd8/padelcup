import { useState, useMemo, useEffect } from 'react';
import { Link, useParams, Navigate } from 'react-router-dom';
import { parseISO } from 'date-fns';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ClubTournament, TournamentTeam, DrawResult, GroupResult, GeneratedMatch, DrawSlot } from '@/types/tournament';
import { generateDraw, exportMatchesToCSV } from '@/lib/drawEngine';
import { calculateFftGroupStandings } from '@/lib/fftStandings';
import { selectBestPlacementsAcrossGroups } from '@/lib/bestQualifiers';
import { ArrowLeft, Download, RefreshCw, Lock, Unlock, Users, Settings, Play, Printer } from 'lucide-react';
import { TournamentMode } from '@/components/tournaments/TournamentMode';
import { GAME_FORMAT_CONFIG } from '@/lib/gameFormatConfig';

// Bracket visualization component
const BracketMatch = ({ 
  match, 
  teams,
  isCompact = false 
}: { 
  match: GeneratedMatch; 
  teams: TournamentTeam[];
  isCompact?: boolean;
}) => {
  const teamA = match.team_a_id ? teams.find(t => t.id === match.team_a_id) : null;
  const teamB = match.team_b_id ? teams.find(t => t.id === match.team_b_id) : null;
  
  const isWinnerA = match.winner_id === match.team_a_id;
  const isWinnerB = match.winner_id === match.team_b_id;
  
  return (
    <div className={`border rounded-lg bg-card ${isCompact ? 'p-2' : 'p-3'} min-w-[180px]`}>
      <div className="text-xs text-muted-foreground mb-2">
        Match {match.match_order + 1}
      </div>
      <div className="space-y-1">
        <div className={`flex items-center gap-2 p-2 rounded ${isWinnerA ? 'bg-primary/10 border border-primary' : 'bg-muted/50'}`}>
          {teamA?.seed_rank && (
            <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">
              {teamA.seed_rank}
            </Badge>
          )}
          <span className={`text-sm truncate flex-1 ${isWinnerA ? 'font-semibold' : ''}`}>
            {match.is_bye && !teamA ? 'BYE' : teamA?.name || 'TBD'}
          </span>
        </div>
        <div className={`flex items-center gap-2 p-2 rounded ${isWinnerB ? 'bg-primary/10 border border-primary' : 'bg-muted/50'}`}>
          {teamB?.seed_rank && (
            <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">
              {teamB.seed_rank}
            </Badge>
          )}
          <span className={`text-sm truncate flex-1 ${isWinnerB ? 'font-semibold' : ''}`}>
            {match.is_bye && !teamB ? 'BYE' : teamB?.name || 'TBD'}
          </span>
        </div>
      </div>
    </div>
  );
};

// Knockout bracket visualization
const KnockoutBracket = ({ 
  drawResult, 
  teams 
}: { 
  drawResult: DrawResult; 
  teams: TournamentTeam[] 
}) => {
  const roundsWithMatches = useMemo(() => {
    const grouped: Record<number, GeneratedMatch[]> = {};
    drawResult.matches.forEach(match => {
      if (!grouped[match.round_order]) {
        grouped[match.round_order] = [];
      }
      grouped[match.round_order].push(match);
    });
    return Object.entries(grouped)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([, matches]) => matches);
  }, [drawResult.matches]);

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-8 min-w-max">
        {roundsWithMatches.map((matches, roundIndex) => (
          <div key={roundIndex} className="flex flex-col">
            <div className="text-sm font-semibold text-center mb-4 text-muted-foreground">
              {matches[0]?.round_name || `Tour ${roundIndex + 1}`}
            </div>
            <div 
              className="flex flex-col justify-around flex-1 gap-4"
              style={{ 
                paddingTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 20}px` : 0,
                gap: `${Math.pow(2, roundIndex + 1) * 10}px`
              }}
            >
              {matches.map((match) => (
                <BracketMatch 
                  key={`${match.round_order}-${match.match_order}`} 
                  match={match} 
                  teams={teams}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Group stage visualization
const GroupStage = ({ 
  groupResult, 
  teams,
  tournament
}: { 
  groupResult: GroupResult; 
  teams: TournamentTeam[];
  tournament: ClubTournament;
}) => {
  const exemptSeeds = groupResult.exemptSeeds || [];
  const exemptTeams = teams.filter(t => exemptSeeds.includes(t.id))
    .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  
  return (
    <div className="space-y-8">
      {/* Exempt seeds for final bracket */}
      {exemptTeams.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Badge variant="default">Tableau Final</Badge>
            TdS exemptées de poules
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {exemptTeams.map((team) => (
              <Card key={team.id} className="border-primary/50 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono">
                      TdS {team.seed_rank}
                    </Badge>
                    <span className="font-medium truncate">{team.name}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Qualifié directement au tableau final
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Groups */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Badge variant="secondary">Phase de Poules</Badge>
          {groupResult.groups.length} poules • {tournament.qualifiers_per_group || 2} qualifiés par poule
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groupResult.groups.map((group) => (
            <Card key={group.order}>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{group.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {group.team_ids.map((teamId, index) => {
                    const team = teams.find(t => t.id === teamId);
                    const isQualifyingPosition = index < (tournament.qualifiers_per_group || 2);
                    return (
                      <div 
                        key={teamId}
                        className={`flex items-center gap-3 p-2 rounded ${
                          isQualifyingPosition ? 'bg-primary/10 border border-primary/20' : 'bg-muted/50'
                        }`}
                      >
                        <span className="text-sm font-mono text-muted-foreground w-4">
                          {index + 1}
                        </span>
                        {team?.seed_rank && (
                          <Badge variant="secondary" className="text-xs">
                            TdS {team.seed_rank}
                          </Badge>
                        )}
                        <span className="text-sm font-medium truncate flex-1">
                          {team?.name || 'TBD'}
                        </span>
                        {isQualifyingPosition && (
                          <Badge variant="outline" className="text-xs bg-primary/5 text-muted-foreground">
                            Place qualif.
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Final bracket preview */}
      {groupResult.finalBracket && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Badge variant="default">Tableau Final</Badge>
            Structure du bracket
          </h3>
          <Card>
            <CardContent className="pt-6">
              <FinalBracketPreview 
                drawResult={groupResult.finalBracket} 
                teams={teams}
                exemptSeeds={exemptSeeds}
                numGroups={groupResult.groups.length}
                qualifiersPerGroup={tournament.qualifiers_per_group || 2}
                extraQualifiersCount={Number((tournament as any).extra_qualifiers_count || 0)}
                extraQualifiersPosition={Number((tournament as any).extra_qualifiers_position || 0)}
              />
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

// Final bracket preview for groups_knockout format
const FinalBracketPreview = ({
  drawResult,
  teams,
  exemptSeeds,
  numGroups,
  qualifiersPerGroup,
  extraQualifiersCount = 0,
  extraQualifiersPosition = 0,
}: {
  drawResult: DrawResult;
  teams: TournamentTeam[];
  exemptSeeds: string[];
  numGroups: number;
  qualifiersPerGroup: number;
  extraQualifiersCount?: number;
  extraQualifiersPosition?: number;
}) => {
  const roundsWithMatches = useMemo(() => {
    const grouped: Record<number, GeneratedMatch[]> = {};
    drawResult.matches.forEach(match => {
      if (!grouped[match.round_order]) {
        grouped[match.round_order] = [];
      }
      grouped[match.round_order].push(match);
    });
    return Object.entries(grouped)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([, matches]) => matches);
  }, [drawResult.matches]);

  // Track which qualifier slots we've assigned
  let qualifierCounter = 0;

  const getSlotLabel = (slot: DrawSlot, teamId?: string): { label: string; isExempt: boolean; isBye: boolean; isQualifier: boolean } => {
    if (slot.is_bye) {
      return { label: 'BYE', isExempt: false, isBye: true, isQualifier: false };
    }
    if (teamId && exemptSeeds.includes(teamId)) {
      const team = teams.find(t => t.id === teamId);
      return { label: team?.name || 'TdS', isExempt: true, isBye: false, isQualifier: false };
    }
    if (!teamId) {
      // This is a qualifier slot
      const totalGroupQualifiers = numGroups * qualifiersPerGroup;
      const idx = qualifierCounter;
      qualifierCounter++;

      if (idx < totalGroupQualifiers) {
        const groupIndex = Math.floor(idx / qualifiersPerGroup);
        const posInGroup = (idx % qualifiersPerGroup) + 1;
        const groupLetter = String.fromCharCode(65 + (groupIndex % numGroups));
        return { label: `${posInGroup}e Poule ${groupLetter}`, isExempt: false, isBye: false, isQualifier: true };
      }

      const extraIdx = idx - totalGroupQualifiers;
      if (extraIdx < extraQualifiersCount && extraQualifiersPosition) {
        const placeLabel = extraQualifiersPosition === 3 ? '3e' : '2e';
        return { label: `Meilleur ${placeLabel} #${extraIdx + 1}`, isExempt: false, isBye: false, isQualifier: true };
      }

      return { label: 'Qualifié (TBD)', isExempt: false, isBye: false, isQualifier: true };
    }
    return { label: 'TBD', isExempt: false, isBye: false, isQualifier: false };
  };

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-8 min-w-max">
        {roundsWithMatches.map((matches, roundIndex) => (
          <div key={roundIndex} className="flex flex-col">
            <div className="text-sm font-semibold text-center mb-4 text-muted-foreground">
              {matches[0]?.round_name || `Tour ${roundIndex + 1}`}
            </div>
            <div 
              className="flex flex-col justify-around flex-1 gap-4"
              style={{ 
                paddingTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 20}px` : 0,
                gap: `${Math.pow(2, roundIndex + 1) * 10}px`
              }}
            >
              {matches.map((match) => {
                const slotA = drawResult.slots[match.slot_a];
                const slotB = drawResult.slots[match.slot_b];
                const labelA = slotA ? getSlotLabel(slotA, match.team_a_id) : { label: 'TBD', isExempt: false, isBye: false, isQualifier: false };
                const labelB = slotB ? getSlotLabel(slotB, match.team_b_id) : { label: 'TBD', isExempt: false, isBye: false, isQualifier: false };
                
                return (
                  <div 
                    key={`${match.round_order}-${match.match_order}`} 
                    className="border rounded-lg bg-card p-3 min-w-[200px]"
                  >
                    <div className="text-xs text-muted-foreground mb-2">
                      Match {match.match_order + 1}
                    </div>
                    <div className="space-y-1">
                      <div className={`flex items-center gap-2 p-2 rounded ${
                        labelA.isExempt ? 'bg-primary/10 border border-primary' : 
                        labelA.isBye ? 'bg-muted/30' :
                        labelA.isQualifier ? 'bg-secondary/50 border border-dashed' :
                        'bg-muted/50'
                      }`}>
                        {slotA?.seed_rank && (
                          <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">
                            {slotA.seed_rank}
                          </Badge>
                        )}
                        <span className={`text-sm truncate flex-1 ${labelA.isQualifier ? 'italic text-muted-foreground' : ''}`}>
                          {labelA.label}
                        </span>
                      </div>
                      <div className="text-center text-xs text-muted-foreground">VS</div>
                      <div className={`flex items-center gap-2 p-2 rounded ${
                        labelB.isExempt ? 'bg-primary/10 border border-primary' : 
                        labelB.isBye ? 'bg-muted/30' :
                        labelB.isQualifier ? 'bg-secondary/50 border border-dashed' :
                        'bg-muted/50'
                      }`}>
                        {slotB?.seed_rank && (
                          <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">
                            {slotB.seed_rank}
                          </Badge>
                        )}
                        <span className={`text-sm truncate flex-1 ${labelB.isQualifier ? 'italic text-muted-foreground' : ''}`}>
                          {labelB.label}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
// Round-robin match list
const RoundRobinMatches = ({ 
  matches, 
  teams 
}: { 
  matches: GeneratedMatch[]; 
  teams: TournamentTeam[] 
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {matches.map((match, index) => (
        <BracketMatch 
          key={index} 
          match={match} 
          teams={teams}
          isCompact
        />
      ))}
    </div>
  );
};

const TournamentDraw = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, club } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [tournamentModeActive, setTournamentModeActive] = useState(false);
  const [localDraw, setLocalDraw] = useState<{
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  } | null>(null);

  const maybeCreateFinalBracketFromPools = useCallback(async () => {
    if (!tournament || tournament.format !== 'groups_knockout') return;

    // Fetch all matches fresh from DB
    const { data: allMatches, error } = await supabase
      .from('tournament_matches')
      .select('*')
      .eq('tournament_id', id);

    if (error) throw error;
    if (!allMatches) return;

    const poolMatches = allMatches.filter((m: any) => String(m.round_name || '').startsWith('Poule '));
    const finalMatches = allMatches.filter((m: any) => (m.round_order ?? 0) >= 100 || String(m.round_name || '').startsWith('Tableau final'));

    // Already created
    if (finalMatches.length > 0) return;

    // Not finished yet
    const allPoolsCompleted = poolMatches.length > 0 && poolMatches.every((m: any) => !!m.winner_id);
    if (!allPoolsCompleted) return;

    // Build per-group standings (FFT)
    const groupNames = Array.from(new Set(poolMatches.map((m: any) => String(m.round_name)))).sort((a, b) => a.localeCompare(b));
    const qualifiersPerGroup = tournament.qualifiers_per_group || 2;

    const qualifiers: TournamentTeam[] = [];
    const groupsForBest = groupNames.map((groupName) => {
      const gm = poolMatches.filter((m: any) => m.round_name === groupName) as GeneratedMatch[];
      const teamIds = Array.from(new Set(gm.flatMap((m: any) => [m.team_a_id, m.team_b_id]).filter(Boolean))) as string[];
      const standings = calculateFftGroupStandings(teamIds, teams, gm);
      const orderedTeamIds = standings.map(s => s.team.id);

      // Standard qualifiers
      const ordered = standings.slice(0, qualifiersPerGroup).map(s => s.team);
      qualifiers.push(...ordered);

      return { name: groupName, teamIds, orderedTeamIds };
    });

    // Optional: extra qualifiers across groups (best 2nd / best 3rd)
    const extraPos = Number((tournament as any).extra_qualifiers_position || 0);
    const extraCount = Number((tournament as any).extra_qualifiers_count || 0);
    if (extraPos && extraCount > 0) {
      const { selected } = selectBestPlacementsAcrossGroups({
        position: extraPos,
        count: extraCount,
        groups: groupsForBest,
        teams,
        matches: poolMatches as any,
      });
      for (const c of selected) {
        if (!qualifiers.find(t => t.id === c.team.id)) qualifiers.push(c.team);
      }
    }

    // Direct seeds (TdS exemptées)
    const directSeedsCount = tournament.seeds_direct_count || 0;
    const directSeeds = teams
      .filter(t => t.status === 'confirmed' && t.seed_rank !== null && t.seed_rank !== undefined && (t.seed_rank as number) <= directSeedsCount)
      .sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));

    const finalists = [...directSeeds, ...qualifiers];
    if (finalists.length < 2) return;

    // Use a manual draw size if configured for the final bracket, otherwise auto
    const finalDrawSize = tournament.final_draw_size || undefined;
    const tForFinal = {
      ...tournament,
      draw_size_mode: finalDrawSize ? 'manual' : 'auto',
      draw_size_manual: finalDrawSize,
    } as any;

    const knockout = generateKnockoutDraw(tForFinal, finalists, tournament.random_seed || undefined);

    const matchRecords = knockout.matches.map(m => ({
      tournament_id: id,
      round_name: `Tableau final • ${m.round_name}`,
      round_order: 100 + (m.round_order ?? 0),
      match_order: m.match_order ?? 0,
      team_a_id: m.team_a_id || null,
      team_b_id: m.team_b_id || null,
      is_bye: m.is_bye,
      score_a: null,
      score_b: null,
      winner_id: null,
    }));

    await supabase.from('tournament_matches').insert(matchRecords);

    toast({
      title: 'Tableau final généré',
      description: 'Les poules sont terminées : le tableau final a été créé automatiquement.'
    });

    queryClient.invalidateQueries({ queryKey: ['tournament-matches', id] });
  }, [tournament, id, teams, queryClient, toast]);


  // Fetch tournament
  const { data: tournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ['tournament', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data as ClubTournament | null;
    },
    enabled: !!id && isAuthenticated,
  });

  // Fetch teams
  const { data: teams = [], isLoading: teamsLoading } = useQuery({
    queryKey: ['tournament-teams', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tournament_teams')
        .select('*')
        .eq('tournament_id', id)
        .order('seed_rank', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data as TournamentTeam[];
    },
    enabled: !!id && isAuthenticated,
  });

  // Update tournament mutation
  const updateTournamentMutation = useMutation({
    mutationFn: async (updates: Partial<ClubTournament>) => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tournament', id] });
    },
  });

  // Auto-regenerate draw when returning to page if draw was already generated
  const confirmedTeams = useMemo(() => teams.filter(t => t.status === 'confirmed'), [teams]);

  const updateTeamSeedRank = useCallback(async (teamId: string, seedRank: number | null) => {
    try {
      const { error } = await supabase
        .from('tournament_teams')
        .update({ seed_rank: seedRank })
        .eq('id', teamId);
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['tournament-teams', id] });
    } catch (e) {
      toast({
        title: 'Erreur',
        description: "Impossible d'enregistrer la tête de série.",
        variant: 'destructive'
      });
    }
  }, [id, queryClient, toast]);

  
  // Effect to restore draw when page loads and draw was previously generated
  useEffect(() => {
    const restoreDraw = async () => {
      if (tournament?.draw_generated && tournament.random_seed && confirmedTeams.length >= 2 && !localDraw) {
        // First generate the draw structure
        const result = generateDraw(tournament as any, confirmedTeams, tournament.random_seed);
        
        // Fetch matches from DB to get real IDs and scores.
        // We persist matches even when the draw is not locked so the organizer can enter results.
        if (tournament.draw_generated) {
          const { data: dbMatches } = await supabase
            .from('tournament_matches')
            .select('*')
            .eq('tournament_id', id)
            .order('round_order')
            .order('match_order');
          
          if (dbMatches && dbMatches.length > 0) {
            // Create a map using round_name + round_order + match_order.
            // Important for group stage: match_order restarts within each group,
            // so round_order/match_order alone can collide across pools.
            const matchMap = new Map<string, typeof dbMatches[0]>();
            dbMatches.forEach(m => {
              matchMap.set(`${m.round_name}-${m.round_order}-${m.match_order}`, m);
            });
            
            // Update matches with DB data
            const updateMatchesWithDb = (matches: GeneratedMatch[]): GeneratedMatch[] => 
              matches.map(m => {
                const dbMatch = matchMap.get(`${m.round_name}-${m.round_order}-${m.match_order}`);
                if (dbMatch) {
                  return {
                    ...m,
                    id: dbMatch.id,
                    score_a: dbMatch.score_a || undefined,
                    score_b: dbMatch.score_b || undefined,
                    winner_id: dbMatch.winner_id || undefined,
                  };
                }
                return m;
              });
            
            if (result.knockoutDraw) {
              result.knockoutDraw.matches = updateMatchesWithDb(result.knockoutDraw.matches);
            }
            if (result.groupDraw) {
              result.groupDraw.matches = updateMatchesWithDb(result.groupDraw.matches);
            }
            if (result.roundRobinMatches) {
              result.roundRobinMatches = updateMatchesWithDb(result.roundRobinMatches);
            }
          }
        }
        
        setLocalDraw(result);
      }
    };
    
    restoreDraw();
  }, [tournament?.draw_generated, tournament?.random_seed, tournament?.draw_locked, confirmedTeams.length, id]);

  if (!isAuthenticated) {
    return <Navigate to="/club/login" replace />;
  }

  if (tournamentLoading || teamsLoading) {
    return (
      <Layout hideFooter>
        <div className="min-h-screen bg-muted/30 flex items-center justify-center">
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </Layout>
    );
  }

  if (!tournament || tournament.club_id !== club?.id) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/club/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const getTournamentStartDateTime = () => {
    // start_date is a YYYY-MM-DD string; start_date is optional HH:MM.
    // If start_date is missing, we assume 09:00.
    const time = (tournament as any).start_date || '09:00';
    const dt = new Date(`${tournament.start_date}T${time}:00`);
    return isNaN(dt.getTime()) ? parseISO(tournament.start_date) : dt;
  };

  const handleGenerateDraw = async () => {
    const startDateTime = getTournamentStartDateTime();
    const msUntilStart = startDateTime.getTime() - Date.now();
    if (!(msUntilStart > 0 && msUntilStart <= 24 * 60 * 60 * 1000)) {
      toast({
        title: 'Tirage indisponible',
        description: "Le tirage ne peut être généré qu'à partir de 24h avant le début du tournoi.",
        variant: 'destructive',
      });
      return;
    }

    if (confirmedTeams.length < 2) {
      toast({
        title: 'Pas assez d\'équipes',
        description: 'Il faut au moins 2 équipes confirmées pour générer un tirage.',
        variant: 'destructive',
      });
      return;
    }

    const newSeed = Math.floor(Math.random() * 1000000);
    const result = generateDraw(tournament as any, confirmedTeams, newSeed);
    
    setLocalDraw(result);

    const persistMatches = async (draw: typeof result) => {
      // Keep DB as source of truth for the Live/Results tabs.
      // When the draw changes, we replace all matches so the organizer can enter results immediately.
      let matchesToSave: GeneratedMatch[] = [];
      if (draw.knockoutDraw) matchesToSave = [...draw.knockoutDraw.matches];
      if (draw.groupDraw) matchesToSave = [...matchesToSave, ...draw.groupDraw.matches];
      if (draw.roundRobinMatches) matchesToSave = [...matchesToSave, ...draw.roundRobinMatches];

      // Delete then insert (simple + reliable).
      await supabase.from('tournament_matches').delete().eq('tournament_id', id);

      const matchRecords = matchesToSave.map(match => ({
        tournament_id: id,
        round_name: match.round_name,
        round_order: match.round_order,
        match_order: match.match_order,
        team_a_id: match.team_a_id || null,
        team_b_id: match.team_b_id || null,
        is_bye: match.is_bye,
        score_a: match.score_a || null,
        score_b: match.score_b || null,
        winner_id: match.winner_id || null,
      }));

      const { data: insertedMatches, error: insertError } = await supabase
        .from('tournament_matches')
        .insert(matchRecords)
        .select();
      if (insertError) throw insertError;

      if (!insertedMatches) return draw;
      const idMap = new Map<string, string>();
      insertedMatches.forEach((m: any) => {
        // Key by round+order+match_order which is stable for a generated draw.
        const key = `${m.round_name}__${m.round_order}__${m.match_order}`;
        idMap.set(key, m.id);
      });
      const withIds = (matches: GeneratedMatch[]) =>
        matches.map(m => {
          const key = `${m.round_name}__${m.round_order}__${m.match_order}`;
          return { ...m, id: idMap.get(key) || m.id };
        });

      const next = { ...draw } as any;
      if (next.knockoutDraw) next.knockoutDraw = { ...next.knockoutDraw, matches: withIds(next.knockoutDraw.matches) };
      if (next.groupDraw) next.groupDraw = { ...next.groupDraw, matches: withIds(next.groupDraw.matches) };
      if (next.roundRobinMatches) next.roundRobinMatches = withIds(next.roundRobinMatches);
      return next;
    };

    // If a draw was previously locked, its matches exist in DB and are tied to the old seed.
    // Regenerating without clearing them causes the Live/Results tabs to lose match IDs (and scoring).
    // We always replace DB matches when generating a draw.
    try {
      const persisted = await persistMatches(result);
      setLocalDraw(persisted);
    } catch (e) {
      console.warn('Unable to persist matches after generating draw', e);
    }
    
    // Update tournament with new seed
    updateTournamentMutation.mutate({ 
      random_seed: newSeed,
      draw_generated: true,
      draw_locked: false,
    });

    toast({
      title: 'Tirage généré',
      description: 'Le tirage au sort a été effectué avec succès.',
    });
  };

  const handleRegenerateDraw = async () => {
    const startDateTime = getTournamentStartDateTime();
    const msUntilStart = startDateTime.getTime() - Date.now();
    if (!(msUntilStart > 0 && msUntilStart <= 24 * 60 * 60 * 1000)) {
      toast({
        title: 'Regénération indisponible',
        description: "Le tirage ne peut être regénéré qu'à partir de 24h avant le début du tournoi.",
        variant: 'destructive',
      });
      return;
    }

    if (tournament.draw_locked) {
      toast({
        title: 'Tirage verrouillé',
        description: 'Déverrouillez le tirage avant de le régénérer.',
        variant: 'destructive',
      });
      return;
    }
    await handleGenerateDraw();
  };

  const handleToggleLock = async () => {
    const isLocking = !tournament.draw_locked;
    
    // If locking the draw, save all matches to database first
    if (isLocking && localDraw) {
      try {
        // Collect all matches to save
        let matchesToSave: GeneratedMatch[] = [];
        
        if (localDraw.knockoutDraw) {
          matchesToSave = [...localDraw.knockoutDraw.matches];
        }
        if (localDraw.groupDraw) {
          matchesToSave = [...matchesToSave, ...localDraw.groupDraw.matches];
        }
        if (localDraw.roundRobinMatches) {
          matchesToSave = [...matchesToSave, ...localDraw.roundRobinMatches];
        }

        // Delete any existing matches for this tournament
        await supabase
          .from('tournament_matches')
          .delete()
          .eq('tournament_id', id);

        // Insert all matches
        const matchRecords = matchesToSave.map(match => ({
          tournament_id: id,
          round_name: match.round_name,
          round_order: match.round_order,
          match_order: match.match_order,
          team_a_id: match.team_a_id || null,
          team_b_id: match.team_b_id || null,
          is_bye: match.is_bye,
          score_a: match.score_a || null,
          score_b: match.score_b || null,
          winner_id: match.winner_id || null,
        }));

        const { data: insertedMatches, error: insertError } = await supabase
          .from('tournament_matches')
          .insert(matchRecords)
          .select();

        if (insertError) throw insertError;

        // Update local draw with real IDs from database
        if (insertedMatches) {
          const matchIdMap = new Map<string, string>();
          insertedMatches.forEach((dbMatch) => {
            // IMPORTANT: in group stage, match_order restarts per group.
            // Use round_name + round_order + match_order to avoid collisions.
            const key = `${dbMatch.round_name}-${dbMatch.round_order}-${dbMatch.match_order}`;
            matchIdMap.set(key, dbMatch.id);
          });

          // Update localDraw with real IDs
          setLocalDraw(prev => {
            if (!prev) return prev;
            
            const assignIds = (matches: GeneratedMatch[]): GeneratedMatch[] => 
              matches.map(m => {
                const key = `${m.round_name}-${m.round_order}-${m.match_order}`;
                return { ...m, id: matchIdMap.get(key) || m.id };
              });
            
            return {
              ...prev,
              knockoutDraw: prev.knockoutDraw 
                ? { ...prev.knockoutDraw, matches: assignIds(prev.knockoutDraw.matches) }
                : undefined,
              groupDraw: prev.groupDraw 
                ? { ...prev.groupDraw, matches: assignIds(prev.groupDraw.matches) }
                : undefined,
              roundRobinMatches: prev.roundRobinMatches 
                ? assignIds(prev.roundRobinMatches)
                : undefined
            };
          });
        }

        toast({
          title: 'Matchs sauvegardés',
          description: `${matchRecords.length} matchs ont été enregistrés.`,
        });
      } catch (error) {
        console.error('Error saving matches:', error);
        toast({
          title: 'Erreur',
          description: 'Impossible de sauvegarder les matchs.',
          variant: 'destructive',
        });
        return;
      }
    }
    
    updateTournamentMutation.mutate({ 
      draw_locked: isLocking 
    });
    
    toast({
      title: isLocking ? 'Tirage verrouillé' : 'Tirage déverrouillé',
      description: isLocking 
        ? 'Le tirage est verrouillé et les matchs sont sauvegardés.'
        : 'Vous pouvez maintenant régénérer le tirage.',
    });
  };

  const handleExportCSV = () => {
    if (!localDraw) return;

    let matches: GeneratedMatch[] = [];
    if (localDraw.knockoutDraw) {
      matches = localDraw.knockoutDraw.matches;
    } else if (localDraw.groupDraw) {
      matches = localDraw.groupDraw.matches;
    } else if (localDraw.roundRobinMatches) {
      matches = localDraw.roundRobinMatches;
    }

    const csv = exportMatchesToCSV(matches, teams);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tirage-${tournament.title.replace(/\s+/g, '-').toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({ title: 'Export réussi', description: 'Le tirage a été exporté en CSV.' });
  };


  const handlePrintGroupsPDF = () => {
    const groupDraw = localDraw?.groupDraw;
    if (!groupDraw) {
      toast({ variant: 'destructive', title: 'Impossible', description: 'Aucune phase de poules à imprimer.' });
      return;
    }

    const escapeHtml = (s: string) =>
      s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');

    const teamName = (id?: string) => {
      if (!id) return 'TBD';
      return teams.find(t => t.id === id)?.name ?? 'TBD';
    };

    const formatLabel = (() => {
      const gf = tournament.game_format;
      if (!gf) return '';
      const map: Record<string, string> = {
        d2: 'D2 (2 sets + super tie-break)',
        d1: 'D1 (2 sets)',
        one_set_9: '1 set (9 jeux)',
        one_set_9_pd: '1 set (9 jeux) + point décisif',
      };
      return map[gf] ? `Format de jeu : ${map[gf]}` : `Format de jeu : ${gf}`;
    })();

    const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(tournament.title)} — Poules</title>
  <style>
    @page { size: A4; margin: 14mm; }
    body { font-family: Arial, Helvetica, sans-serif; color: #111; }
    .page { page-break-after: always; }
    .header { display:flex; justify-content:space-between; align-items:flex-end; border-bottom:2px solid #111; padding-bottom:8px; margin-bottom:10px; }
    .title { font-size: 20px; font-weight: 800; }
    .meta { font-size: 12px; text-align:right; color:#333; }
    .poule { font-size: 18px; font-weight: 800; margin: 8px 0 10px; }
    table { width:100%; border-collapse: collapse; }
    th, td { border: 1px solid #111; padding: 8px; font-size: 13px; }
    th { background:#f2f2f2; text-transform: uppercase; font-size: 12px; letter-spacing: .04em; }
    .blank { height: 20px; }
    .section-title { margin-top: 14px; margin-bottom: 8px; font-weight: 800; text-transform: uppercase; font-size: 12px; letter-spacing: .06em; }
    .match { border: 1px solid #111; border-radius: 8px; padding: 8px 10px; margin-bottom: 8px; }
    .match-top { font-size: 12px; color:#333; font-weight:700; margin-bottom:4px; }
    .match-main { font-size: 14px; font-weight: 800; }
  </style>
</head>
<body>
  ${groupDraw.groups.map((g) => {
      const teamIds = g.team_ids;
      const matches = groupDraw.matches
        .filter(m => teamIds.includes(m.team_a_id || '') && teamIds.includes(m.team_b_id || ''))
        .slice()
        .sort((a, b) => (a.match_order ?? 0) - (b.match_order ?? 0));

      const rows = teamIds.map((id, i) => `
        <tr>
          <td style="width:40px; text-align:center; font-weight:700;">${i+1}</td>
          <td>${escapeHtml(teamName(id))}</td>
          <td style="width:70px;" class="blank"></td>
          <td style="width:90px;" class="blank"></td>
          <td style="width:70px;" class="blank"></td>
        </tr>
      `).join('');

      const matchesHtml = matches.map((m, idx) => `
        <div class="match">
          <div class="match-top">Match ${idx+1} — ${escapeHtml(g.name)}</div>
          <div class="match-main">${escapeHtml(teamName(m.team_a_id))}  vs  ${escapeHtml(teamName(m.team_b_id))}</div>
        </div>
      `).join('');

      return `
      <div class="page">
        <div class="header">
          <div>
            <div class="title">${escapeHtml(tournament.title)}</div>
            <div style="margin-top:4px; font-size:12px; color:#333;">${escapeHtml(formatLabel)}</div>
          </div>
          <div class="meta">
            <div>${escapeHtml(tournament.start_date)}</div>
            <div>${escapeHtml(tournament.city || '')}</div>
            <div>${escapeHtml(tournament.referee_name || '')}</div>
          </div>
        </div>

        <div class="poule">${escapeHtml(g.name)}</div>

        <div class="section-title">Tableau de poule (à compléter au stylo)</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Équipe</th>
              <th style="width:70px;">Cl.</th>
              <th style="width:90px;">Diff sets</th>
              <th style="width:70px;">Pts</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>

        <div class="section-title">Ordre des matchs</div>
        ${matchesHtml || '<div style="color:#666; font-size:12px;">Aucun match généré.</div>'}
      </div>`;
    }).join('')}
</body>
</html>`;

    const win = window.open('', '_blank');
    if (!win) {
      toast({ variant: 'destructive', title: 'Pop-up bloquée', description: 'Autorisez les pop-ups pour imprimer.' });
      return;
    }
    win.document.open();
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 300);
  };


  const getFormatLabel = (format: string) => {
    switch (format) {
      case 'knockout': return 'Élimination directe';
      case 'groups_knockout': return 'Poules + Élimination';
      case 'round_robin': return 'Championnat (Round-robin)';
      case 'direct_entry': return 'Entrée directe';
      default: return format;
    }
  };

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to={`/club/tournaments/${id}/teams`}
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour aux équipes
            </Link>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold">{tournament.title}</h1>
                <div className="flex items-center gap-3 mt-1">
                  <Badge variant="outline">{getFormatLabel(tournament.format)}</Badge>
                  <span className="text-muted-foreground">
                    {confirmedTeams.length} équipes confirmées
                  </span>
                  {tournament.draw_locked && (
                    <Badge variant="secondary" className="gap-1">
                      <Lock className="h-3 w-3" />
                      Verrouillé
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex gap-2 flex-wrap">
                {/* Quick access to change tournament mode/settings */}
                <Button variant="outline" asChild className="gap-2">
                  <Link to={`/club/tournaments/${id}/edit`}>
                    <Settings className="h-4 w-4" />
                    Modifier le mode
                  </Link>
                </Button>
                {localDraw && (
                  <>
                    {/* Tournament Mode Button - only when draw is locked */}
                    {tournament.draw_locked && (
                      <Button 
                        variant="default" 
                        onClick={() => setTournamentModeActive(true)}
                        className="gap-2"
                      >
                        <Play className="h-4 w-4" />
                        Mode Tournoi
                      </Button>
                    )}
                    {/* Public Display Link - only when draw is locked */}
                    {tournament.draw_locked && (
                      <Button 
                        variant="outline" 
                        asChild
                        className="gap-2"
                      >
                        <a href={`/live/${id}`} target="_blank" rel="noopener noreferrer">
                          <Users className="h-4 w-4" />
                          Affichage TV
                        </a>
                      </Button>
                    )}
                    <Button variant="outline" onClick={handlePrintGroupsPDF}>
                      <Printer className="mr-2 h-4 w-4" />
                      Imprimer poules (PDF)
                    </Button>
                    <Button variant="outline" onClick={handleExportCSV}>
                      <Download className="mr-2 h-4 w-4" />
                      Export CSV
                    </Button>
                    {/* Validate/Unlock buttons */}
                    {tournament.draw_locked ? (
                      <Button 
                        variant="outline" 
                        onClick={handleToggleLock}
                        className="gap-2"
                      >
                        <Unlock className="h-4 w-4" />
                        Modifier le tirage
                      </Button>
                    ) : (
                      <Button 
                        variant="success" 
                        onClick={handleToggleLock}
                        className="gap-2"
                      >
                        <Lock className="h-4 w-4" />
                        Valider le tirage
                      </Button>
                    )}
                  </>
                )}
                {localDraw && !tournament.draw_locked ? (
                  <Button 
                    variant="outline" 
                    onClick={handleRegenerateDraw}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Régénérer
                  </Button>
                ) : !localDraw ? (
                  <Button variant="accent" onClick={handleGenerateDraw}>
                    Générer le tirage
                  </Button>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8">
          {!localDraw ? (
            <div className="space-y-6">
              {/* Configuration panel */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Configuration du tirage
                  </CardTitle>
                  <CardDescription>
                    Définissez les paramètres du tirage avant de le générer
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Participants & seeding (before draw generation) */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <h3 className="font-medium">Participants confirmés</h3>
                        <p className="text-xs text-muted-foreground">Choisissez les têtes de série (TdS). Laissez vide si non tête de série.</p>
                      </div>
                      <Badge variant="outline">{confirmedTeams.length} paires</Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {confirmedTeams.map((team) => (
                        <Card key={team.id} className="border-muted">
                          <CardContent className="p-3 flex items-center justify-between gap-3">
                            <div className="min-w-0">
                              <div className="font-medium truncate">{team.name}</div>
                              <div className="text-xs text-muted-foreground truncate">#{team.id.slice(0, 6)}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Label className="text-xs text-muted-foreground">TdS</Label>
                              <Input
                                className="w-20"
                                type="number"
                                min={1}
                                placeholder="-"
                                value={team.seed_rank ?? ''}
                                onChange={(e) => {
                                  const v = e.target.value;
                                  const n = v === '' ? null : Math.max(1, parseInt(v) || 1);
                                  updateTeamSeedRank(team.id, n);
                                }}
                              />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Format selection */}
                    <div className="space-y-2">
                      <Label htmlFor="format">Format du tournoi</Label>
                      <Select
                        value={tournament.format}
                        onValueChange={(value) => updateTournamentMutation.mutate({ format: value as any })}
                      >
                        <SelectTrigger id="format">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="knockout">Élimination directe</SelectItem>
                          <SelectItem value="direct_entry">Entrée directe (TdS au tableau final)</SelectItem>
                          <SelectItem value="groups_knockout">Poules + Élimination</SelectItem>
                          <SelectItem value="round_robin">Championnat (Round-robin)</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        {tournament.format === 'direct_entry' && 'Les têtes de série entrent directement au tableau final'}
                        {tournament.format === 'knockout' && 'Toutes les équipes commencent au premier tour'}
                        {tournament.format === 'groups_knockout' && 'Phase de poules puis élimination directe'}
                        {tournament.format === 'round_robin' && 'Chaque équipe affronte toutes les autres'}
                      </p>
                    </div>

                    {/* Direct entry seeds count */}
                    {tournament.format === 'direct_entry' && (
                      <div className="space-y-2">
                        <Label htmlFor="seeds_direct">Têtes de série en entrée directe</Label>
                        <Input
                          id="seeds_direct"
                          type="number"
                          min={1}
                          max={confirmedTeams.length}
                          value={tournament.seeds_direct_count || 0}
                          onChange={(e) => updateTournamentMutation.mutate({ seeds_direct_count: parseInt(e.target.value) || 0 })}
                          className="w-full"
                        />
                        <p className="text-xs text-muted-foreground">
                          Les {tournament.seeds_direct_count || 0} premières TdS iront directement au tableau final
                        </p>
                      </div>
                    )}

                    {/* BYE priority removed (kept internal if needed) */}

                    {/* Groups config */}
                    {tournament.format === 'groups_knockout' && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="seeds_exempt">TdS exemptées de poules</Label>
                          <Input
                            id="seeds_exempt"
                            type="number"
                            min={0}
                            max={confirmedTeams.filter(t => t.seed_rank).length}
                            value={tournament.seeds_direct_count || 0}
                            onChange={(e) => updateTournamentMutation.mutate({ seeds_direct_count: parseInt(e.target.value) || 0 })}
                          />
                          <p className="text-xs text-muted-foreground">
                            Ces TdS iront directement au tableau final sans passer par les poules
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="group_size">Taille des poules</Label>
                          <Input
                            id="group_size"
                            type="number"
                            min={3}
                            max={8}
                            value={tournament.group_size || 4}
                            onChange={(e) => updateTournamentMutation.mutate({ group_size: parseInt(e.target.value) || 4 })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="qualifiers">Qualifiés par poule</Label>
                          <Input
                            id="qualifiers"
                            type="number"
                            min={1}
                            max={(tournament.group_size || 4) - 1}
                            value={tournament.qualifiers_per_group || 2}
                            onChange={(e) => updateTournamentMutation.mutate({ qualifiers_per_group: parseInt(e.target.value) || 2 })}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Qualifiés supplémentaires (optionnel)</Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <Select
                              value={(tournament as any).extra_qualifiers_position ? String((tournament as any).extra_qualifiers_position) : undefined}
                              onValueChange={(v) => updateTournamentMutation.mutate({ extra_qualifiers_position: v === "none" ? null : parseInt(v) } as any)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Aucun" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">Aucun</SelectItem>
                                <SelectItem value="2">Meilleur 2e</SelectItem>
                                <SelectItem value="3">Meilleur 3e</SelectItem>
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              min={0}
                              value={(tournament as any).extra_qualifiers_count ?? 0}
                              onChange={(e) => updateTournamentMutation.mutate({ extra_qualifiers_count: parseInt(e.target.value) || 0 } as any)}
                              disabled={!((tournament as any).extra_qualifiers_position)}
                            />
                          </div>
                          <p className="text-xs text-muted-foreground">
                            En cas de poules de tailles différentes, la comparaison des meilleurs 2e/3e est normalisée (match vs dernier ignoré).
                          </p>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Seeds summary for direct_entry */}
                  {tournament.format === 'direct_entry' && (tournament.seeds_direct_count || 0) > 0 && (
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-medium mb-2">Répartition des équipes</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Tableau final :</span>
                          <span className="ml-2 font-medium">{tournament.seeds_direct_count} TdS</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Qualifications :</span>
                          <span className="ml-2 font-medium">{Math.max(0, confirmedTeams.length - (tournament.seeds_direct_count || 0))} équipes</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Seeds summary for groups_knockout */}
                  {tournament.format === 'groups_knockout' && (
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-medium mb-3">Répartition des équipes</h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        {(tournament.seeds_direct_count || 0) > 0 && (
                          <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                            <div className="text-xs text-primary font-medium uppercase mb-1">Tableau final direct</div>
                            <div className="font-semibold text-lg">{tournament.seeds_direct_count} TdS</div>
                            <div className="text-xs text-muted-foreground mt-1">Exemptées de poules</div>
                          </div>
                        )}
                        <div className="p-3 bg-secondary/50 rounded-lg">
                          <div className="text-xs text-muted-foreground font-medium uppercase mb-1">Phase de poules</div>
                          <div className="font-semibold text-lg">{Math.max(0, confirmedTeams.length - (tournament.seeds_direct_count || 0))} équipes</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            ~{Math.ceil((confirmedTeams.length - (tournament.seeds_direct_count || 0)) / (tournament.group_size || 4))} poules de {tournament.group_size || 4}
                          </div>
                        </div>
                        <div className="p-3 bg-secondary/50 rounded-lg">
                          <div className="text-xs text-muted-foreground font-medium uppercase mb-1">Qualifiés pour le TF</div>
                          <div className="font-semibold text-lg">
                            {(tournament.seeds_direct_count || 0) + Math.ceil((confirmedTeams.length - (tournament.seeds_direct_count || 0)) / (tournament.group_size || 4)) * (tournament.qualifiers_per_group || 2) + ((tournament as any).extra_qualifiers_count || 0)}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {tournament.seeds_direct_count || 0} TdS + {tournament.qualifiers_per_group || 2}/poule{((tournament as any).extra_qualifiers_count || 0) ? ` + ${(tournament as any).extra_qualifiers_count} meilleur(s) ${(tournament as any).extra_qualifiers_position === 3 ? '3e' : '2e'}` : ''}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Generate button card */}
              <Card>
                <CardContent className="py-12">
                  <div className="text-center">
                    <Users className="h-16 w-16 text-muted-foreground/50 mx-auto mb-6" />
                    <h2 className="text-xl font-semibold mb-2">Prêt pour le tirage</h2>
                    <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                      {confirmedTeams.length < 2 
                        ? `Il vous faut au moins 2 équipes confirmées. Actuellement: ${confirmedTeams.length}`
                        : `${confirmedTeams.length} équipes sont prêtes pour le tirage au sort en format "${getFormatLabel(tournament.format)}".`
                      }
                    </p>
                    <Button 
                      variant="accent" 
                      size="lg" 
                      onClick={handleGenerateDraw}
                      disabled={confirmedTeams.length < 2}
                    >
                      Générer le tirage
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Tableau du tournoi</CardTitle>
                <CardDescription>
                  {tournament.format === 'knockout' && localDraw.knockoutDraw && (
                    `${localDraw.knockoutDraw.rounds.length} tours • Taille: ${localDraw.knockoutDraw.slots.length}`
                  )}
                  {tournament.format === 'groups_knockout' && localDraw.groupDraw && (
                    `${localDraw.groupDraw.groups.length} poules • ${localDraw.groupDraw.matches.length} matchs de poule`
                  )}
                  {tournament.format === 'round_robin' && localDraw.roundRobinMatches && (
                    `${localDraw.roundRobinMatches.length} matchs au total`
                  )}
                  {tournament.format === 'direct_entry' && localDraw.knockoutDraw && (
                    `Entrée directe • ${localDraw.knockoutDraw.rounds.length} tours`
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Knockout bracket */}
                {(tournament.format === 'knockout' || tournament.format === 'direct_entry') && 
                  localDraw.knockoutDraw && (
                  <KnockoutBracket drawResult={localDraw.knockoutDraw} teams={teams} />
                )}

                {/* Groups + knockout */}
                {tournament.format === 'groups_knockout' && localDraw.groupDraw && (
                  <GroupStage groupResult={localDraw.groupDraw} teams={teams} tournament={tournament as any} />
                )}

                {/* Round-robin */}
                {tournament.format === 'round_robin' && localDraw.roundRobinMatches && (
                  <RoundRobinMatches matches={localDraw.roundRobinMatches} teams={teams} />
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Tournament Mode Overlay */}
      {tournamentModeActive && localDraw && (
        <TournamentMode
          tournament={{
            id: tournament.id,
            title: tournament.title,
            format: tournament.format,
            game_format: tournament.game_format,
            qualifiers_per_group: tournament.qualifiers_per_group
          }}
          teams={teams}
          knockoutDraw={localDraw.knockoutDraw}
          groupDraw={localDraw.groupDraw}
          roundRobinMatches={localDraw.roundRobinMatches}
          onScoreUpdate={async (matchId, scoreA, scoreB, winnerId) => {
            // Update local draw immediately for live UI update
            setLocalDraw(prev => {
              if (!prev) return prev;
              
              const updateMatches = (matches: GeneratedMatch[]): GeneratedMatch[] => 
                matches.map(m => 
                  m.id === matchId 
                    ? { ...m, score_a: scoreA, score_b: scoreB, winner_id: winnerId }
                    : m
                );
              
              return {
                ...prev,
                knockoutDraw: prev.knockoutDraw 
                  ? { ...prev.knockoutDraw, matches: updateMatches(prev.knockoutDraw.matches) }
                  : undefined,
                groupDraw: prev.groupDraw 
                  ? { ...prev.groupDraw, matches: updateMatches(prev.groupDraw.matches) }
                  : undefined,
                roundRobinMatches: prev.roundRobinMatches 
                  ? updateMatches(prev.roundRobinMatches)
                  : undefined
              };
            });
            
            // Update match in database
            try {
              await supabase
                .from('tournament_matches')
                .update({
                  score_a: scoreA,
                  score_b: scoreB,
                  winner_id: winnerId,
                  completed_at: new Date().toISOString()
                })
                .eq('id', matchId);
              
              toast({
                title: 'Score enregistré',
                description: 'Le classement a été mis à jour automatiquement.'
              });
            } catch (error) {
              toast({
                title: 'Erreur',
                description: 'Impossible d\'enregistrer le score.',
                variant: 'destructive'
              });

              // If this was the last pool match, auto-generate the final bracket
              await maybeCreateFinalBracketFromPools();

            }
          }}
          onClose={() => setTournamentModeActive(false)}
        />
      )}
    </Layout>
  );
};

export default TournamentDraw;
