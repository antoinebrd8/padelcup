import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useParams, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { frenchRegions, categoryOptions, genderOptions } from '@/data/mockData';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Save, Trash2, Loader2, X, Image as ImageIcon } from 'lucide-react';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { GameFormatSelect } from '@/components/tournaments/GameFormatSelect';
import type { GameFormat } from '@/lib/gameFormatConfig';
import type { TournamentFormat, DrawSizeMode, ClubTournament } from '@/types/tournament';
import { validateTournamentFftCompliance, type RefereeLevel } from '@/lib/fftCompliance';
import { Switch } from '@/components/ui/switch';

const formatOptions = [
  { value: 'knockout', label: 'Tableau direct (knockout)' },
  { value: 'groups_knockout', label: 'Poules + tableau' },
  { value: 'round_robin', label: 'Championnat (round-robin)' },
  { value: 'direct_entry', label: 'Entrée directe des têtes de série' },
];

const TournamentEdit = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, club, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [tournament, setTournament] = useState<ClubTournament | null>(null);
  const [addressSearch, setAddressSearch] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: club?.address || '',
    city: club?.city || '',
    region: club?.region || '',
    latitude: null as number | null,
    longitude: null as number | null,
    category_code: '',
    gender: '',
    start_date: '',
    start_time: '09:00',
    end_date: '',
    registration_deadline: '',
    max_teams: '16',
    price: '',
    format: 'knockout' as TournamentFormat,
    draw_size_mode: 'auto' as DrawSizeMode,
    draw_size_manual: '',
    group_size: '4',
    qualifiers_per_group: '2',
    byes_priority_for_seeds: true,
    allow_on_site_license: false,
    final_draw_size: '',
    seeds_direct_count: '0',
    referee_name: '',
    referee_level: '' as RefereeLevel | '',
    image_url: '',
    game_format: 'B1' as GameFormat,
  });

  const fftCheck = validateTournamentFftCompliance({
    category: (formData.category_code as any) || null,
    gender: (formData.gender as any) || null,
    start_date: formData.start_date || null,
    registration_deadline: formData.registration_deadline || null,
    max_teams: formData.max_teams ? parseInt(formData.max_teams) : null,
    game_format: formData.game_format,
    referee_level: (formData.referee_level || null) as any,
  });

  // Fetch tournament data
  useEffect(() => {
    const fetchTournament = async () => {
      if (!id || !club) return;

      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*')
        .eq('id', id)
        .eq('club_id', club.id)
        .single();

      if (error || !data) {
        console.error('Error fetching tournament:', error);
        setIsFetching(false);
        return;
      }

      const t = data as unknown as ClubTournament;
      setTournament(t);
      setFormData({
        title: t.title || '',
        description: t.description || '',
        // fallback to club defaults if tournament fields are empty
        location: t.location || club.address || '',
        city: t.city || club.city || '',
        region: t.region || club.region || '',
        latitude: t.latitude || null,
        longitude: t.longitude || null,
        category_code: t.category_code || '',
        gender: t.gender || '',
        start_date: t.start_date || '',
        start_time: (t as any).start_time || '09:00',
        end_date: t.end_date || '',
        registration_deadline: t.registration_deadline || '',
        max_teams: t.max_teams?.toString() || '16',
        price: t.price?.toString() || '',
        format: t.format || 'knockout',
        draw_size_mode: t.draw_size_mode || 'auto',
        draw_size_manual: t.draw_size_manual?.toString() || '',
        group_size: t.group_size?.toString() || '4',
        qualifiers_per_group: t.qualifiers_per_group?.toString() || '2',
        byes_priority_for_seeds: t.byes_priority_for_seeds ?? true,
        allow_on_site_license: (t as any).allow_on_site_license ?? false,
        final_draw_size: t.final_draw_size?.toString() || '',
        seeds_direct_count: t.seeds_direct_count?.toString() || '0',
        referee_name: t.referee_name || '',
        referee_level: (t as any).referee_level || '',
        image_url: t.image_url || '',
        game_format: (t as any).game_format || 'B1',
      });
      if (t.image_url) {
        setImagePreview(t.image_url);
      }
      setIsFetching(false);
    };

    if (club) {
      fetchTournament();
    }
  }, [id, club]);

  // Handle address selection from autocomplete
  const handleAddressSelect = (data: {
    address: string;
    city: string;
    region: string;
    postalCode: string;
    lat: number;
    lng: number;
  }) => {
    setFormData(prev => ({
      ...prev,
      location: data.address,
      city: data.city,
      region: frenchRegions.includes(data.region) ? data.region : prev.region,
      latitude: data.lat,
      longitude: data.lng,
    }));
    toast({
      title: "Adresse sélectionnée",
      description: `${data.address}, ${data.city} - coordonnées enregistrées`,
    });
  };

  // Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Fichier trop volumineux",
          description: "L'image ne doit pas dépasser 5 Mo",
          variant: "destructive",
        });
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Remove selected image
  const handleRemoveImage = () => {
    setImageFile(null);
    setImagePreview(null);
    setFormData(prev => ({ ...prev, image_url: '' }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (authLoading || isFetching) {
    return (
      <Layout>
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated || !club) {
    return <Navigate to="/club/login" replace />;
  }

  if (!tournament) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/club/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation des champs obligatoires
    if (!formData.title.trim()) {
      toast({ title: "Erreur", description: "Le nom du tournoi est obligatoire", variant: "destructive" });
      return;
    }
    if (!formData.category_code) {
      toast({ title: "Erreur", description: "La catégorie est obligatoire", variant: "destructive" });
      return;
    }
    if (!formData.gender) {
      toast({ title: "Erreur", description: "Le genre est obligatoire", variant: "destructive" });
      return;
    }
    if (!formData.start_date) {
      toast({ title: "Erreur", description: "La date de début est obligatoire", variant: "destructive" });
      return;
    }
    if (!formData.end_date) {
      toast({ title: "Erreur", description: "La date de fin est obligatoire", variant: "destructive" });
      return;
    }
    if (!formData.city.trim()) {
      toast({ title: "Erreur", description: "La ville est obligatoire", variant: "destructive" });
      return;
    }

    if (fftCheck.errors.length > 0) {
      toast({ title: 'Non conforme FFT', description: fftCheck.errors[0], variant: 'destructive' });
      return;
    }
    if (!formData.region) {
      toast({ title: "Erreur", description: "La région est obligatoire", variant: "destructive" });
      return;
    }

    setIsLoading(true);

    try {
      let imageUrl = formData.image_url;

      // Upload new image if selected
      if (imageFile) {
        setIsUploadingImage(true);
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${club.id}/${Date.now()}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('tournament-images')
          .upload(fileName, imageFile);

        if (uploadError) {
          console.error('Upload error:', uploadError);
          toast({
            title: "Erreur d'upload",
            description: "Impossible de télécharger l'image",
            variant: "destructive",
          });
        } else {
          const { data: { publicUrl } } = supabase.storage
            .from('tournament-images')
            .getPublicUrl(fileName);
          imageUrl = publicUrl;
        }
        setIsUploadingImage(false);
      }

      const { error } = await supabase
        .from('club_tournaments')
        .update({
          title: formData.title,
          description: formData.description || null,
          location: formData.location || null,
          city: formData.city,
          region: formData.region,
          latitude: formData.latitude,
          longitude: formData.longitude,
          image_url: imageUrl || null,
          referee_name: formData.referee_name || null,
          referee_level: formData.referee_level ? (formData.referee_level as any) : null,
          category_code: formData.category_code,
          gender: formData.gender,
          start_date: formData.start_date,
          start_time: formData.start_time || '09:00',
          end_date: formData.end_date,
          registration_deadline: formData.registration_deadline || null,
          max_teams: formData.max_teams ? parseInt(formData.max_teams) : null,
          price: formData.price ? parseFloat(formData.price) : null,
          format: formData.format,
          draw_size_mode: formData.draw_size_mode,
          draw_size_manual: formData.draw_size_manual ? parseInt(formData.draw_size_manual) : null,
          group_size: parseInt(formData.group_size),
          qualifiers_per_group: parseInt(formData.qualifiers_per_group),
          byes_priority_for_seeds: formData.byes_priority_for_seeds,
          allow_on_site_license: formData.allow_on_site_license,
          final_draw_size: formData.final_draw_size ? parseInt(formData.final_draw_size) : null,
          seeds_direct_count: parseInt(formData.seeds_direct_count),
          game_format: formData.game_format,
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Tournoi mis à jour !",
        description: `Les modifications ont été enregistrées.`,
      });

      navigate('/club/dashboard');
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);

    try {
      // Delete associated matches first
      await supabase
        .from('tournament_matches')
        .delete()
        .eq('tournament_id', id);

      // Delete associated teams
      await supabase
        .from('tournament_teams')
        .delete()
        .eq('tournament_id', id);

      // Delete associated groups
      await supabase
        .from('tournament_groups')
        .delete()
        .eq('tournament_id', id);

      // Delete the tournament
      const { error } = await supabase
        .from('club_tournaments')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Tournoi supprimé",
        description: "Le tournoi a été supprimé avec succès.",
      });

      navigate('/club/dashboard');
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de supprimer le tournoi",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to="/club/dashboard"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <h1 className="font-display text-2xl font-bold">Modifier le tournoi</h1>
          </div>
        </div>

        <div className="container py-8">
          <form onSubmit={handleSubmit}>
            <div className="grid gap-6 max-w-3xl">
              {/* General info */}
              <Card>
                <CardHeader>
                  <CardTitle>Informations générales</CardTitle>
                  <CardDescription>
                    Les champs marqués d'un * sont obligatoires
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Nom du tournoi *</Label>
                    <Input
                      id="title"
                      required
                      placeholder="Open de Printemps P250"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description (optionnel)</Label>
                    <Textarea
                      id="description"
                      placeholder="Décrivez votre tournoi..."
                      rows={3}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category_code">Catégorie *</Label>
                      <Select
                        value={formData.category_code}
                        onValueChange={(value) => setFormData({ ...formData, category_code: value })}
                      >
                        <SelectTrigger id="category_code">
                          <SelectValue placeholder="Sélectionner" />
                        </SelectTrigger>
                        <SelectContent>
                          {categoryOptions.map((cat) => (
                            <SelectItem key={cat.value} value={cat.value}>
                              {cat.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="gender">Genre *</Label>
                      <Select
                        value={formData.gender}
                        onValueChange={(value) => setFormData({ ...formData, gender: value })}
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Sélectionner" />
                        </SelectTrigger>
                        <SelectContent>
                          {genderOptions.map((g) => (
                            <SelectItem key={g.value} value={g.value}>
                              {g.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="max_teams">Équipes max</Label>
                      <Input
                        id="max_teams"
                        type="number"
                        min="2"
                        max="256"
                        value={formData.max_teams}
                        onChange={(e) => setFormData({ ...formData, max_teams: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-4 bg-background">
                    <div className="space-y-0.5">
                      <Label className="text-base">Achat de licence sur place possible</Label>
                      <p className="text-sm text-muted-foreground">
                        Si activé, les joueurs sans licence FFT pourront s'inscrire (achat sur place). Sinon, une licence FFT valide sera obligatoire pour s'inscrire.
                      </p>
                    </div>
                    <Switch
                      checked={formData.allow_on_site_license}
                      onCheckedChange={(checked) => setFormData({ ...formData, allow_on_site_license: checked })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="start_date">Date de début *</Label>
                      <Input
                        id="start_date"
                        type="date"
                        required
                        value={formData.start_date}
                        onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="start_time">Heure de début *</Label>
                      <Input
                        id="start_time"
                        type="time"
                        required
                        value={formData.start_time}
                        onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end_date">Date de fin *</Label>
                      <Input
                        id="end_date"
                        type="date"
                        required
                        value={formData.end_date}
                        onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="registration_deadline">Limite inscriptions</Label>
                      <Input
                        id="registration_deadline"
                        type="date"
                        value={formData.registration_deadline}
                        onChange={(e) => setFormData({ ...formData, registration_deadline: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Prix (€)</Label>
                      <Input
                        id="price"
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="30"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="referee_name">Juge-arbitre</Label>
                      <Input
                        id="referee_name"
                        placeholder="Nom du juge-arbitre"
                        value={formData.referee_name}
                        onChange={(e) => setFormData({ ...formData, referee_name: e.target.value })}
                      />

                      <div className="pt-2 space-y-2">
                        <Label>Niveau du Juge-Arbitre (FFT)</Label>
                        <Select
                          value={formData.referee_level}
                          onValueChange={(value) => setFormData({ ...formData, referee_level: value as RefereeLevel })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionner" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="JAP1">JAP1</SelectItem>
                            <SelectItem value="JAP2">JAP2</SelectItem>
                            <SelectItem value="JAT3">JAT3 PADEL</SelectItem>
                            <SelectItem value="INTERNATIONAL">JAP International</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tournament Image */}
              <Card>
                <CardHeader>
                  <CardTitle>Image du tournoi</CardTitle>
                  <CardDescription>
                    Ajoutez une photo pour illustrer votre tournoi (max 5 Mo)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Aperçu"
                          className="w-full h-48 object-cover rounded-lg"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={handleRemoveImage}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 hover:border-primary hover:bg-muted/50 transition-colors"
                      >
                        <ImageIcon className="h-8 w-8 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Cliquer pour ajouter une image</span>
                      </button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Location with Autocomplete */}
              <Card>
                <CardHeader>
                  <CardTitle>Lieu *</CardTitle>
                  <CardDescription>
                    Recherchez une adresse pour la géolocaliser automatiquement
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Rechercher une adresse</Label>
                    <AddressAutocomplete
                      value={addressSearch}
                      onChange={setAddressSearch}
                      onSelect={handleAddressSelect}
                      placeholder="Tapez une adresse pour la rechercher..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="location">Adresse / Lieu</Label>
                      <Input
                        id="location"
                        placeholder="123 Rue du Sport"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Ville *</Label>
                      <Input
                        id="city"
                        required
                        placeholder="Paris"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="region">Région *</Label>
                    <Select
                      value={formData.region}
                      onValueChange={(value) => setFormData({ ...formData, region: value })}
                    >
                      <SelectTrigger id="region">
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        {frenchRegions.map((region) => (
                          <SelectItem key={region} value={region}>
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.latitude && formData.longitude && (
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-green-500"></span>
                      Coordonnées enregistrées: {formData.latitude.toFixed(5)}, {formData.longitude.toFixed(5)}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Format & Game Format */}
              <Card>
                <CardHeader>
                  <CardTitle>Format du tournoi</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="format">Type de format</Label>
                    <Select
                      value={formData.format}
                      onValueChange={(value) => setFormData({ ...formData, format: value as TournamentFormat })}
                    >
                      <SelectTrigger id="format">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {formatOptions.map((f) => (
                          <SelectItem key={f.value} value={f.value}>
                            {f.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <GameFormatSelect
                    value={formData.game_format}
                    onChange={(value) => setFormData({ ...formData, game_format: value })}
                  />

                  <div className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium">Conformité FFT (contrôles automatiques)</p>
                        <p className="text-xs text-muted-foreground">
                          On bloque l’enregistrement si une règle FFT essentielle n’est pas respectée.
                        </p>
                      </div>
                      {fftCheck.errors.length === 0 ? (
                        <Badge className="bg-success hover:bg-success/90">OK</Badge>
                      ) : (
                        <Badge variant="destructive">À corriger</Badge>
                      )}
                    </div>

                    {fftCheck.errors.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {fftCheck.errors.map((e) => (
                          <p key={e} className="text-sm text-destructive">• {e}</p>
                        ))}
                      </div>
                    )}

                    {fftCheck.warnings.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {fftCheck.warnings.map((w) => (
                          <p key={w} className="text-sm text-muted-foreground">• {w}</p>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex flex-col-reverse sm:flex-row justify-between gap-4">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button type="button" variant="destructive" disabled={isDeleting}>
                      {isDeleting ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="mr-2 h-4 w-4" />
                      )}
                      Supprimer
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Êtes-vous sûr ?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Cette action est irréversible. Le tournoi sera définitivement supprimé
                        avec toutes les équipes et matchs associés.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Annuler</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Supprimer
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>

                <div className="flex gap-4">
                  <Button type="button" variant="outline" asChild>
                    <Link to="/club/dashboard">Annuler</Link>
                  </Button>
                  <Button type="submit" variant="accent" disabled={isLoading || isUploadingImage || fftCheck.errors.length > 0}>
                    {isLoading || isUploadingImage ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    Enregistrer
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default TournamentEdit;