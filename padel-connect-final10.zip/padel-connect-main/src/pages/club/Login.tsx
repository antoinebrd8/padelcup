import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Trophy, LogIn } from 'lucide-react';

const ClubLogin = () => {
  const navigate = useNavigate();
  const { isAuthenticated, isLoading: authLoading, club } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  useEffect(() => {
    if (isAuthenticated && club && !authLoading) {
      navigate('/club/dashboard');
    }
  }, [isAuthenticated, authLoading, club, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // First, sign in with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (authError) {
        let errorMessage = "Email ou mot de passe incorrect";
        if (authError.message.includes('Invalid login')) {
          errorMessage = "Email ou mot de passe incorrect";
        } else if (authError.message.includes('Email not confirmed')) {
          errorMessage = "Veuillez confirmer votre email";
        }
        toast({
          title: "Erreur de connexion",
          description: errorMessage,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Check if this user has a club profile
      const { data: clubData, error: clubError } = await supabase
        .from('clubs')
        .select('id')
        .eq('user_id', authData.user.id)
        .maybeSingle();

      if (clubError || !clubData) {
        // No club profile - this is a player account, sign them out
        await supabase.auth.signOut();
        toast({
          title: "Accès refusé",
          description: "Ce compte n'est pas un compte organisateur. Veuillez utiliser l'espace joueur.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Success - club account verified
      toast({
        title: "Connexion réussie",
        description: "Bienvenue sur votre espace club !",
      });
      navigate('/club/dashboard');
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la connexion.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <Layout>
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-[80vh] flex items-center justify-center py-12">
        <div className="container max-w-md">
          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-12 h-12 rounded-lg bg-primary flex items-center justify-center">
                <Trophy className="h-6 w-6 text-primary-foreground" />
              </div>
              <CardTitle className="text-2xl">Espace Organisateur</CardTitle>
              <CardDescription>
                Connectez-vous pour gérer vos tournois
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="contact@monclub.fr"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex-col gap-4">
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Connexion...' : 'Se connecter'}
                  <LogIn className="ml-2 h-4 w-4" />
                </Button>
                <p className="text-sm text-muted-foreground">
                  Pas encore de compte ?{' '}
                  <Link to="/club/register" className="text-primary hover:underline">
                    Créer un compte club
                  </Link>
                </p>
                <Link to="/player/login" className="text-sm text-muted-foreground hover:text-foreground">
                  Accéder à l'espace joueur →
                </Link>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default ClubLogin;