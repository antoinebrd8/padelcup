import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import {
  Trophy,
  Building2,
  Users,
  FileText,
  User,
  ArrowRight,
  Calendar,
  BarChart3,
  Download,
  Shield,
  Zap,
} from 'lucide-react';

/**
 * IMPORTANT: Clubs cannot self-create an organizer account.
 * This page is a request form only. Access is validated manually by the platform admin.
 */
const ClubRegister = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const [formData, setFormData] = useState({
    structureType: 'association',
    legalName: '',
    commercialName: '',
    address: '',
    city: '',
    postalCode: '',
    country: 'France',
    sirenSiret: '',
    rnaNumber: '',
    representativeFirstName: '',
    representativeLastName: '',
    representativeRole: '',
    representativeEmail: '',
    representativePhone: '',
    website: '',
    courtsCount: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate official ID based on structure type
    if (formData.structureType === 'company' && !formData.sirenSiret) {
      toast({
        title: 'Erreur',
        description: 'Le numéro SIREN/SIRET est obligatoire pour une société',
        variant: 'destructive',
      });
      return;
    }

    if (formData.structureType === 'association' && !formData.rnaNumber) {
      toast({
        title: 'Erreur',
        description: "Le numéro RNA est obligatoire pour une association",
        variant: 'destructive',
      });
      return;
    }

    if (formData.structureType === 'association' && formData.rnaNumber) {
      const rnaRegex = /^W[0-9]{9}$/;
      if (!rnaRegex.test(formData.rnaNumber.toUpperCase())) {
        toast({
          title: 'Erreur',
          description: 'Le numéro RNA doit être au format WXXXXXXXXX (W suivi de 9 chiffres)',
          variant: 'destructive',
        });
        return;
      }
    }

    if (!formData.representativeEmail) {
      toast({
        title: 'Erreur',
        description: "L'email du représentant est obligatoire",
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      const clubName = formData.commercialName || formData.legalName;
      const { data: reqRow, error: reqError } = await supabase
        .from('club_requests')
        .insert({
          structure_type: formData.structureType,
          legal_name: formData.legalName,
          commercial_name: formData.commercialName || null,
          address: formData.address,
          city: formData.city,
          postal_code: formData.postalCode,
          country: formData.country,
          siren_siret: formData.structureType === 'company' ? formData.sirenSiret : null,
          rna_number: formData.structureType === 'association' ? formData.rnaNumber.toUpperCase() : null,
          representative_first_name: formData.representativeFirstName,
          representative_last_name: formData.representativeLastName,
          representative_role: formData.representativeRole,
          representative_email: formData.representativeEmail,
          representative_phone: formData.representativePhone,
          contact_email: formData.representativeEmail,
          contact_phone: formData.representativePhone || null,
          website: formData.website || null,
          courts_count: formData.courtsCount ? Number(formData.courtsCount) : null,
          message: formData.message || null,
          status: 'pending',
        })
        .select('id')
        .single();

      if (reqError) throw new Error(reqError.message);

      // Non-blocking: admin email notification (Edge Function)
      try {
        const dashboardUrl = `${window.location.origin}/admin/club-requests/${reqRow.id}`;
        await supabase.functions.invoke('send-club-request-email', {
          body: {
            requestId: reqRow.id,
            clubName,
            city: formData.city,
            contactEmail: formData.representativeEmail,
            contactPhone: formData.representativePhone,
            dashboardUrl,
          },
        });
      } catch (err) {
        console.warn('Admin email notification skipped/failed:', err);
      }

      toast({
        title: 'Demande envoyée ✅',
        description: "Votre demande a été transmise. Nous vous contacterons rapidement pour activer votre accès organisateur.",
      });
      navigate('/club/login');
    } catch (error: any) {
      toast({
        title: 'Erreur',
        description: error?.message || "Une erreur est survenue lors de l'envoi de la demande",
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const features = [
    { icon: Calendar, title: 'Gestion des tournois', description: 'Créez et gérez vos tournois en quelques clics' },
    { icon: Users, title: 'Inscriptions en ligne', description: "Les joueurs s'inscrivent directement sur la plateforme" },
    { icon: BarChart3, title: 'Tirages automatiques', description: 'Générez des tableaux de tournoi professionnels' },
    { icon: Download, title: 'Export des données', description: 'Exportez la liste des participants en CSV' },
  ];

  return (
    <Layout>
      <div className="py-12">
        <div className="container max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Left side */}
            <div className="space-y-6">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm font-medium mb-4">
                  <Zap className="h-4 w-4" />
                  Accès sur validation
                </div>
                <h1 className="text-3xl font-bold mb-4">Demandez l'accès organisateur</h1>
                <p className="text-lg text-muted-foreground">
                  Les clubs et organisateurs déposent une demande. Les accès sont validés manuellement pour garantir la qualité et la conformité.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <Card key={index} className="border-none shadow-sm bg-muted/30">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <feature.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium">{feature.title}</h3>
                          <p className="text-sm text-muted-foreground">{feature.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Shield className="h-8 w-8 text-primary" />
                    <div className="flex-1">
                      <h3 className="font-medium">Process simple</h3>
                      <p className="text-sm text-muted-foreground">Vous envoyez la demande → on vous contacte → on active l'espace organisateur.</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/club/login">
                        Déjà un compte ?
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right side - request form */}
            <div>
              <Card>
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 w-12 h-12 rounded-lg bg-primary flex items-center justify-center">
                    <Trophy className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">Demande d'inscription club</CardTitle>
                  <CardDescription>Les accès organisateur sont validés manuellement.</CardDescription>
                </CardHeader>

                <form onSubmit={handleSubmit}>
                  <CardContent className="space-y-6">
                    <Card className="border-primary/20 bg-primary/5">
                      <CardContent className="p-4 text-sm">
                        <p className="font-medium">Important</p>
                        <p className="text-muted-foreground">Aucun compte n'est créé automatiquement. Vous serez contacté après vérification.</p>
                      </CardContent>
                    </Card>

                    {/* Structure type */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-primary">
                        <Building2 className="h-4 w-4" />
                        Type de structure
                      </div>
                      <RadioGroup
                        value={formData.structureType}
                        onValueChange={(value) => setFormData({ ...formData, structureType: value })}
                        className="grid grid-cols-2 gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="association" id="association" />
                          <Label htmlFor="association" className="cursor-pointer">Association loi 1901</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="company" id="company" />
                          <Label htmlFor="company" className="cursor-pointer">Société (SAS, SARL...)</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <Separator />

                    {/* Legal identity */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-primary">
                        <FileText className="h-4 w-4" />
                        Identité légale
                      </div>
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="legalName">Nom légal du club *</Label>
                          <Input id="legalName" required value={formData.legalName} onChange={(e) => setFormData({ ...formData, legalName: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="commercialName">Nom commercial (si différent)</Label>
                          <Input id="commercialName" value={formData.commercialName} onChange={(e) => setFormData({ ...formData, commercialName: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="address">Adresse du siège *</Label>
                          <Input id="address" required value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="city">Ville *</Label>
                            <Input id="city" required value={formData.city} onChange={(e) => setFormData({ ...formData, city: e.target.value })} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="postalCode">Code postal *</Label>
                            <Input id="postalCode" required value={formData.postalCode} onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })} />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="country">Pays *</Label>
                          <Input id="country" required value={formData.country} onChange={(e) => setFormData({ ...formData, country: e.target.value })} />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    {/* Official ID */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-primary">
                        <Shield className="h-4 w-4" />
                        Identifiant officiel
                      </div>
                      {formData.structureType === 'company' ? (
                        <div className="space-y-2">
                          <Label htmlFor="sirenSiret">Numéro SIREN ou SIRET *</Label>
                          <Input id="sirenSiret" required value={formData.sirenSiret} onChange={(e) => setFormData({ ...formData, sirenSiret: e.target.value })} />
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Label htmlFor="rnaNumber">Numéro RNA *</Label>
                          <Input id="rnaNumber" required value={formData.rnaNumber} onChange={(e) => setFormData({ ...formData, rnaNumber: e.target.value.toUpperCase() })} />
                          <p className="text-xs text-muted-foreground">Format : WXXXXXXXXX (W suivi de 9 chiffres)</p>
                        </div>
                      )}
                    </div>

                    <Separator />

                    {/* Representative */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-primary">
                        <User className="h-4 w-4" />
                        Représentant du club
                      </div>
                      <div className="grid gap-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="repFirst">Prénom *</Label>
                            <Input id="repFirst" required value={formData.representativeFirstName} onChange={(e) => setFormData({ ...formData, representativeFirstName: e.target.value })} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="repLast">Nom *</Label>
                            <Input id="repLast" required value={formData.representativeLastName} onChange={(e) => setFormData({ ...formData, representativeLastName: e.target.value })} />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="repRole">Fonction *</Label>
                          <Input id="repRole" required value={formData.representativeRole} onChange={(e) => setFormData({ ...formData, representativeRole: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="repEmail">Email *</Label>
                          <Input id="repEmail" type="email" required value={formData.representativeEmail} onChange={(e) => setFormData({ ...formData, representativeEmail: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="repPhone">Téléphone (optionnel)</Label>
                          <Input id="repPhone" value={formData.representativePhone} onChange={(e) => setFormData({ ...formData, representativePhone: e.target.value })} />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    {/* Extra */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-primary">
                        <Users className="h-4 w-4" />
                        Informations complémentaires
                      </div>
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="website">Site / Instagram (optionnel)</Label>
                          <Input id="website" placeholder="https://..." value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="courts">Nombre de terrains (optionnel)</Label>
                          <Input id="courts" inputMode="numeric" placeholder="4" value={formData.courtsCount} onChange={(e) => setFormData({ ...formData, courtsCount: e.target.value })} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="message">Message (optionnel)</Label>
                          <Input id="message" placeholder="Dites-nous en 1 phrase votre besoin" value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} />
                        </div>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="flex flex-col gap-4">
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (
                        <>
                          <span className="animate-spin mr-2">⏳</span>
                          Envoi de la demande...
                        </>
                      ) : (
                        <>Envoyer ma demande</>
                      )}
                    </Button>
                    <p className="text-center text-sm text-muted-foreground">
                      Déjà inscrit ?{' '}
                      <Link to="/club/login" className="text-primary hover:underline">
                        Se connecter
                      </Link>
                    </p>
                  </CardFooter>
                </form>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ClubRegister;
