import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { frenchRegions, categoryOptions, genderOptions } from '@/data/mockData';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Save, MapPin, Loader2, CheckCircle2, Upload, X, Image as ImageIcon, User } from 'lucide-react';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { GameFormatSelect } from '@/components/tournaments/GameFormatSelect';
import type { GameFormat } from '@/lib/gameFormatConfig';
import type { TournamentFormat, DrawSizeMode } from '@/types/tournament';
import { validateTournamentFftCompliance, type RefereeLevel } from '@/lib/fftCompliance';

const formatOptions = [
  { value: 'knockout', label: 'Tableau direct (knockout)' },
  { value: 'groups_knockout', label: 'Poules + tableau' },
  { value: 'round_robin', label: 'Championnat (round-robin)' },
  { value: 'direct_entry', label: 'Entrée directe des têtes de série' },
];

const TournamentCreate = () => {
  const navigate = useNavigate();
  const { isAuthenticated, club, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [geocodeStatus, setGeocodeStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [addressSearch, setAddressSearch] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    // prefill with club profile data
    location: club?.address || '',
    city: club?.city || '',
    region: club?.region || '',
    latitude: null as number | null,
    longitude: null as number | null,
    category_code: '',
    gender: '',
    start_date: '',
    start_time: '09:00',
    end_date: '',
    registration_deadline: '',
    max_teams: '16',
    price: '',
    refund_deadline_hours: '24',
    refund_policy_text: '',
    format: 'knockout' as TournamentFormat,
    draw_size_mode: 'auto' as DrawSizeMode,
    draw_size_manual: '',
    group_size: '4',
    qualifiers_per_group: '2',
    byes_priority_for_seeds: true,
    allow_on_site_license: false,
    final_draw_size: '',
    seeds_direct_count: '0',
    referee_name: '',
    referee_level: '' as RefereeLevel | '',
    game_format: 'B1' as GameFormat,
  });

  // If club data arrives after first render, prefill address/city/region only when fields are still empty
  useEffect(() => {
    if (!club) return;
    setFormData((prev) => {
      const next = { ...prev };
      if (!prev.location && club.address) next.location = club.address;
      if (!prev.city && club.city) next.city = club.city;
      if (!prev.region && club.region) next.region = club.region;
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [club?.id]);

  const fftCheck = validateTournamentFftCompliance({
    category: (formData.category_code as any) || null,
    gender: (formData.gender as any) || null,
    start_date: formData.start_date || null,
    registration_deadline: formData.registration_deadline || null,
    max_teams: formData.max_teams ? parseInt(formData.max_teams) : null,
    game_format: formData.game_format,
    referee_level: (formData.referee_level || null) as any,
  });

  // Handle address selection from autocomplete
  const handleAddressSelect = (data: {
    address: string;
    city: string;
    region: string;
    postalCode: string;
    lat: number;
    lng: number;
  }) => {
    setFormData(prev => ({
      ...prev,
      location: data.address,
      city: data.city,
      region: frenchRegions.includes(data.region) ? data.region : prev.region,
      latitude: data.lat,
      longitude: data.lng,
    }));
    setGeocodeStatus('success');
    toast({
      title: "Adresse sélectionnée",
      description: `${data.address}, ${data.city} - coordonnées enregistrées`,
    });
  };

  // Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Fichier trop volumineux",
          description: "L'image ne doit pas dépasser 5 Mo",
          variant: "destructive",
        });
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Remove selected image
  const handleRemoveImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (authLoading) {
    return (
      <Layout>
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated || !club) {
    return <Navigate to="/club/login" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (fftCheck.errors.length > 0) {
      toast({
        title: "Non conforme FFT",
        description: fftCheck.errors[0],
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);

    try {
      let imageUrl: string | null = null;

      // Upload image if selected
      if (imageFile) {
        setIsUploadingImage(true);
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${club.id}/${Date.now()}.${fileExt}`;
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('tournament-images')
          .upload(fileName, imageFile);

        if (uploadError) {
          console.error('Upload error:', uploadError);
          toast({
            title: "Erreur d'upload",
            description: "Impossible de télécharger l'image",
            variant: "destructive",
          });
        } else {
          const { data: { publicUrl } } = supabase.storage
            .from('tournament-images')
            .getPublicUrl(fileName);
          imageUrl = publicUrl;
        }
        setIsUploadingImage(false);
      }

      const { data: created, error } = await supabase.from('club_tournaments').insert({
        club_id: club.id,
        title: formData.title,
        description: formData.description || null,
        location: formData.location || null,
        city: formData.city || null,
        region: formData.region || null,
        latitude: formData.latitude,
        longitude: formData.longitude,
        image_url: imageUrl,
        referee_name: formData.referee_name || null,
        referee_level: formData.referee_level ? (formData.referee_level as any) : null,
        category_code: formData.category_code || null,
        gender: formData.gender || null,
        start_date: formData.start_date,
        end_date: formData.end_date,
        registration_deadline: formData.registration_deadline || null,
        max_teams: formData.max_teams ? parseInt(formData.max_teams) : null,
        price: formData.price ? parseFloat(formData.price) : null,
        refund_deadline_hours: formData.refund_deadline_hours ? parseInt(formData.refund_deadline_hours) : null,
        refund_policy_text: formData.refund_policy_text || null,
        format: formData.format,
        draw_size_mode: formData.draw_size_mode,
        draw_size_manual: formData.draw_size_manual ? parseInt(formData.draw_size_manual) : null,
        group_size: parseInt(formData.group_size),
        qualifiers_per_group: parseInt(formData.qualifiers_per_group),
        byes_priority_for_seeds: formData.byes_priority_for_seeds,
        allow_on_site_license: formData.allow_on_site_license,
        final_draw_size: formData.final_draw_size ? parseInt(formData.final_draw_size) : null,
        seeds_direct_count: parseInt(formData.seeds_direct_count),
        game_format: formData.game_format,
      }).select('id').single();

      if (error) throw error;

      const tournamentId = created?.id;
      const publicLink = tournamentId ? `${window.location.origin}/tournaments/${tournamentId}` : null;

      if (publicLink) {
        try { await navigator.clipboard.writeText(publicLink); } catch {}
      }

      toast({
        title: "Tournoi créé !",
        
        description: publicLink
          ? `Lien public copié : ${publicLink}`
          : `Le tournoi "${formData.title}" a été créé avec succès.`,
      });

      navigate(tournamentId ? `/club/tournaments/${tournamentId}/manage` : '/club/dashboard');
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Layout hideFooter>
      <div className="min-h-screen bg-muted/30">
        <div className="bg-background border-b">
          <div className="container py-6">
            <Link
              to="/club/dashboard"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour au dashboard
            </Link>
            <h1 className="font-display text-2xl font-bold">Créer un tournoi</h1>
          </div>
        </div>

        <div className="container py-8">
          <form onSubmit={handleSubmit}>
            <div className="grid gap-6 max-w-3xl">
              {/* General info */}
              <Card>
                <CardHeader>
                  <CardTitle>Informations générales</CardTitle>
                  <CardDescription>
                    Les informations principales de votre tournoi
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Nom du tournoi *</Label>
                    <Input
                      id="title"
                      required
                      placeholder="Open de Printemps P250"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Décrivez votre tournoi..."
                      rows={3}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category_code">Catégorie</Label>
                      <Select
                        value={formData.category_code}
                        onValueChange={(value) => setFormData({ ...formData, category_code: value })}
                      >
                        <SelectTrigger id="category_code">
                          <SelectValue placeholder="Sélectionner" />
                        </SelectTrigger>
                        <SelectContent>
                          {categoryOptions.map((cat) => (
                            <SelectItem key={cat.value} value={cat.value}>
                              {cat.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="gender">Genre</Label>
                      <Select
                        value={formData.gender}
                        onValueChange={(value) => setFormData({ ...formData, gender: value })}
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Sélectionner" />
                        </SelectTrigger>
                        <SelectContent>
                          {genderOptions.map((g) => (
                            <SelectItem key={g.value} value={g.value}>
                              {g.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="max_teams">Équipes max</Label>
                      <Input
                        id="max_teams"
                        type="number"
                        min="2"
                        max="256"
                        value={formData.max_teams}
                        onChange={(e) => setFormData({ ...formData, max_teams: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-4 bg-background">
                    <div className="space-y-0.5">
                      <Label className="text-base">Achat de licence sur place possible</Label>
                      <p className="text-sm text-muted-foreground">
                        Si activé, les joueurs sans licence FFT pourront s'inscrire (achat sur place). Sinon, une licence FFT valide sera obligatoire pour s'inscrire.
                      </p>
                    </div>
                    <Switch
                      checked={formData.allow_on_site_license}
                      onCheckedChange={(checked) => setFormData({ ...formData, allow_on_site_license: checked })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="start_date">Date de début *</Label>
                      <Input
                        id="start_date"
                        type="date"
                        required
                        value={formData.start_date}
                        onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="start_time">Heure de début *</Label>
                      <Input
                        id="start_time"
                        type="time"
                        required
                        value={formData.start_time}
                        onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end_date">Date de fin *</Label>
                      <Input
                        id="end_date"
                        type="date"
                        required
                        value={formData.end_date}
                        onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="registration_deadline">Limite inscriptions</Label>
                      <Input
                        id="registration_deadline"
                        type="date"
                        value={formData.registration_deadline}
                        onChange={(e) => setFormData({ ...formData, registration_deadline: e.target.value })}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tournament Image */}
              <Card>
                <CardHeader>
                  <CardTitle>Image du tournoi</CardTitle>
                  <CardDescription>
                    Ajoutez une photo pour illustrer votre tournoi (max 5 Mo)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Aperçu"
                          className="w-full h-48 object-cover rounded-lg"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={handleRemoveImage}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 hover:border-primary hover:bg-muted/50 transition-colors"
                      >
                        <ImageIcon className="h-8 w-8 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Cliquer pour ajouter une image</span>
                      </button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Location with Autocomplete */}
              <Card>
                <CardHeader>
                  <CardTitle>Lieu</CardTitle>
                  <CardDescription>
                    Recherchez une adresse pour la géolocaliser automatiquement
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Rechercher une adresse</Label>
                    <AddressAutocomplete
                      value={addressSearch}
                      onChange={setAddressSearch}
                      onSelect={handleAddressSelect}
                      placeholder="Tapez une adresse pour la rechercher..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="location">Adresse / Lieu</Label>
                      <Input
                        id="location"
                        placeholder="123 Rue du Sport"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Ville</Label>
                      <Input
                        id="city"
                        placeholder="Paris"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="region">Région</Label>
                    <Select
                      value={formData.region}
                      onValueChange={(value) => setFormData({ ...formData, region: value })}
                    >
                      <SelectTrigger id="region">
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        {frenchRegions.map((region) => (
                          <SelectItem key={region} value={region}>
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Geocode status */}
                  {geocodeStatus === 'success' && formData.latitude && formData.longitude && (
                    <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-700">
                        Adresse géolocalisée ({formData.latitude.toFixed(4)}, {formData.longitude.toFixed(4)})
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Referee & Game Format */}
              <Card>
                <CardHeader>
                  <CardTitle>Arbitrage & Format de jeu</CardTitle>
                  <CardDescription>
                    Définissez le juge-arbitre et le format de match
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="referee_name">Nom du Juge Arbitre</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="referee_name"
                        placeholder="Jean Dupont"
                        value={formData.referee_name}
                        onChange={(e) => setFormData({ ...formData, referee_name: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Niveau du Juge-Arbitre (FFT)</Label>
                    <Select
                      value={formData.referee_level}
                      onValueChange={(value) => setFormData({ ...formData, referee_level: value as RefereeLevel })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="JAP1">JAP1</SelectItem>
                        <SelectItem value="JAP2">JAP2</SelectItem>
                        <SelectItem value="JAT3">JAT3 PADEL</SelectItem>
                        <SelectItem value="INTERNATIONAL">JAP International</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Ex : JAP1 = compétent P25/P50/P100 ; JAP2 = compétent P250 ; JAT3 = national.
                    </p>
                  </div>

                  <GameFormatSelect
                    value={formData.game_format}
                    onChange={(value) => setFormData({ ...formData, game_format: value })}
                  />

                  <div className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium">Conformité FFT (contrôles automatiques)</p>
                        <p className="text-xs text-muted-foreground">
                          On bloque l’enregistrement si une règle FFT essentielle n’est pas respectée.
                        </p>
                      </div>
                      {fftCheck.errors.length === 0 ? (
                        <Badge className="bg-success hover:bg-success/90">OK</Badge>
                      ) : (
                        <Badge variant="destructive">À corriger</Badge>
                      )}
                    </div>

                    {fftCheck.errors.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {fftCheck.errors.map((e) => (
                          <p key={e} className="text-sm text-destructive">• {e}</p>
                        ))}
                      </div>
                    )}

                    {fftCheck.warnings.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {fftCheck.warnings.map((w) => (
                          <p key={w} className="text-sm text-muted-foreground">• {w}</p>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Tournament Format */}
              <Card>
                <CardHeader>
                  <CardTitle>Format du tournoi</CardTitle>
                  <CardDescription>
                    Configurez les règles du tirage au sort
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="format">Format</Label>
                    <Select
                      value={formData.format}
                      onValueChange={(value) => setFormData({ ...formData, format: value as TournamentFormat })}
                    >
                      <SelectTrigger id="format">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {formatOptions.map((f) => (
                          <SelectItem key={f.value} value={f.value}>
                            {f.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Knockout options */}
                  {(formData.format === 'knockout' || formData.format === 'direct_entry') && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="draw_size_mode">Taille du tableau</Label>
                          <Select
                            value={formData.draw_size_mode}
                            onValueChange={(value) => setFormData({ ...formData, draw_size_mode: value as DrawSizeMode })}
                          >
                            <SelectTrigger id="draw_size_mode">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="auto">Auto (puissance de 2)</SelectItem>
                              <SelectItem value="manual">Manuel</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {formData.draw_size_mode === 'manual' && (
                          <div className="space-y-2">
                            <Label htmlFor="draw_size_manual">Taille manuelle</Label>
                            <Input
                              id="draw_size_manual"
                              type="number"
                              min="4"
                              step="1"
                              placeholder="32"
                              value={formData.draw_size_manual}
                              onChange={(e) => setFormData({ ...formData, draw_size_manual: e.target.value })}
                            />
                          </div>
                        )}
                      </div>

                      {/* BYE priority removed */}
                    </>
                  )}

                  {/* Direct entry options */}
                  {formData.format === 'direct_entry' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                      <div className="space-y-2">
                        <Label htmlFor="final_draw_size">Taille du tableau final</Label>
                        <Input
                          id="final_draw_size"
                          type="number"
                          min="4"
                          placeholder="16"
                          value={formData.final_draw_size}
                          onChange={(e) => setFormData({ ...formData, final_draw_size: e.target.value })}
                        />
                        <p className="text-xs text-muted-foreground">Ex: 16 pour un tableau en 1/8e</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="seeds_direct_count">Nb de têtes de série en entrée directe</Label>
                        <Input
                          id="seeds_direct_count"
                          type="number"
                          min="0"
                          placeholder="4"
                          value={formData.seeds_direct_count}
                          onChange={(e) => setFormData({ ...formData, seeds_direct_count: e.target.value })}
                        />
                      </div>
                    </div>
                  )}

                  {/* Groups options */}
                  {formData.format === 'groups_knockout' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                      <div className="space-y-2">
                        <Label htmlFor="group_size">Taille des poules</Label>
                        <Select
                          value={formData.group_size}
                          onValueChange={(value) => setFormData({ ...formData, group_size: value })}
                        >
                          <SelectTrigger id="group_size">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="3">3 équipes</SelectItem>
                            <SelectItem value="4">4 équipes</SelectItem>
                            <SelectItem value="5">5 équipes</SelectItem>
                            <SelectItem value="6">6 équipes</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="qualifiers_per_group">Qualifiés par poule</Label>
                        <Select
                          value={formData.qualifiers_per_group}
                          onValueChange={(value) => setFormData({ ...formData, qualifiers_per_group: value })}
                        >
                          <SelectTrigger id="qualifiers_per_group">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 qualifié</SelectItem>
                            <SelectItem value="2">2 qualifiés</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Price */}
              <Card>
                <CardHeader>
                  <CardTitle>Tarification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label htmlFor="price">Prix d'inscription (€)</Label>
                    <Input
                      id="price"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="25.00"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Les frais Padel Cup sont ajoutés et affichés uniquement côté joueur au moment du paiement.
                    </p>

                  <div className="mt-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Politique de remboursement</Label>
                        <Select
                          value={formData.refund_deadline_hours}
                          onValueChange={(v) => setFormData({ ...formData, refund_deadline_hours: v })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Choisir un délai" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="0">Aucun remboursement automatique</SelectItem>
                            <SelectItem value="12">12h</SelectItem>
                            <SelectItem value="24">24h</SelectItem>
                            <SelectItem value="48">48h</SelectItem>
                            <SelectItem value="72">72h</SelectItem>
                            <SelectItem value="168">7 jours</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          Jusqu’à quand un joueur peut être remboursé automatiquement (avant le début du tournoi).
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label>Date limite calculée</Label>
                        <Input
                          value={(() => {
                            try {
                              const hours = parseInt(formData.refund_deadline_hours || '0', 10);
                              if (!formData.start_date || !formData.start_time || !Number.isFinite(hours) || hours <= 0) return '';
                              // Build local datetime (YYYY-MM-DD + HH:mm)
                              const start = new Date(`${formData.start_date}T${formData.start_time}:00`);
                              const limit = new Date(start.getTime() - hours * 60 * 60 * 1000);
                              return limit.toLocaleString('fr-FR', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
                            } catch {
                              return '';
                            }
                          })()}
                          readOnly
                          placeholder="Définir la date/heure du tournoi"
                        />
                        <p className="text-xs text-muted-foreground">
                          Basé sur la date/heure de début du tournoi.
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label>Note (optionnel)</Label>
                        <Textarea
                          placeholder="Ex : hors frais Stripe / remboursements au club / exceptions..."
                          value={formData.refund_policy_text}
                          onChange={(e) => setFormData({ ...formData, refund_policy_text: e.target.value })}
                        />
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground">
                      Astuce : affiche ce délai sur la page tournoi + email de confirmation pour éviter les litiges.
                    </p>
                  </div>

                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-end gap-4">
                <Button type="button" variant="outline" asChild>
                  <Link to="/club/dashboard">Annuler</Link>
                </Button>
                <Button type="submit" variant="accent" disabled={isLoading || fftCheck.errors.length > 0}>
                  {isLoading ? 'Création...' : 'Créer le tournoi'}
                  <Save className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default TournamentCreate;