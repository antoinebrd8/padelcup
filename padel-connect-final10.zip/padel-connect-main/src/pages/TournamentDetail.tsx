import { useParams, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MultiStepRegistrationForm } from '@/components/tournaments/MultiStepRegistrationForm';
import { PlayerTeamCard } from '@/components/player/PlayerTeamCard';
import { supabase } from '@/integrations/supabase/client';
import { Tournament } from '@/types';
import { Calendar, MapPin, Users, Trophy, ArrowLeft, ExternalLink, Clock, Tag, Mail, Phone } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import tournament1 from '@/assets/tournament-1.jpg';
import tournament2 from '@/assets/tournament-2.jpg';
import tournament3 from '@/assets/tournament-3.jpg';
import tournament4 from '@/assets/tournament-4.jpg';
import { GAME_FORMAT_CONFIG } from '@/lib/gameFormatConfig';

const TournamentDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [loading, setLoading] = useState(true);
  const [playerHasTeam, setPlayerHasTeam] = useState(false);
  const [descExpanded, setDescExpanded] = useState(false);

  useEffect(() => {
    const fetchTournament = async () => {
      if (!id) return;
      
      setLoading(true);
      
      // Fetch tournament data
      const { data, error } = await supabase
        .from('club_tournaments')
        .select(`
          *,
          clubs (
            id,
            name,
            email,
            phone,
            address,
            city,
            region,
            show_email,
            show_phone
          )
        `)
        .eq('id', id)
        .maybeSingle();

      if (error || !data) {
        console.error('Error fetching tournament:', error);
        setLoading(false);
        return;
      }

      // Fetch registrations count
      const { count: registrationsCount } = await supabase
        .from('tournament_teams')
        .select('*', { count: 'exact', head: true })
        .eq('tournament_id', id);

      // Transform to Tournament type
      const transformed: Tournament = {
        id: data.id,
        club_id: data.club_id,
        club: data.clubs ? {
          id: data.clubs.id,
          name: data.clubs.name,
          email: data.clubs.email,
          phone: (data.clubs as any).phone || '',
          address: data.clubs.address || '',
          city: data.clubs.city || '',
          postal_code: '',
          region: data.clubs.region || '',
          created_at: '',
          updated_at: '',
          // visibility flags (optional columns)
          show_email: (data.clubs as any).show_email ?? true,
          show_phone: (data.clubs as any).show_phone ?? true,
        } : undefined,
        title: data.title,
        description: data.description || '',
        address: data.location || '',
        city: data.city || '',
        postal_code: '',
        region: data.region || '',
        category_code: (data.category_code || 'P100') as Tournament['category_code'],
        gender: (data.gender || 'Mixte') as Tournament['gender'],
        start_date: data.start_date,
        end_date: data.end_date,
        max_teams: data.max_teams || undefined,
        official_registration_url: null,
        is_managed_by_platform: true,
        created_at: data.created_at,
        updated_at: data.updated_at,
        registrations_count: registrationsCount || 0,
        latitude: data.latitude ? Number(data.latitude) : undefined,
        longitude: data.longitude ? Number(data.longitude) : undefined,
        referee_name: data.referee_name || null,
        format: (data.format || 'knockout') as any,
        game_format: (data.game_format || null) as any,
        price: data.price ?? null,
        image_url: (data as any).image_url || null,
      };

      setTournament(transformed);
      setLoading(false);
    };

    fetchTournament();
  }, [id]);

  if (loading) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </Layout>
    );
  }

  if (!tournament) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Tournoi non trouvé</h1>
          <Button asChild>
            <Link to="/tournaments">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour aux tournois
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const isExternal = tournament.club_id === null;
  const isPlatformManaged = tournament.is_managed_by_platform;
  const showRegistrationCTA = isPlatformManaged && !isExternal && !playerHasTeam;

  const tournamentImages = [tournament1, tournament2, tournament3, tournament4];
  const imageIndex = parseInt(tournament.id.replace(/\D/g, '') || '1') % tournamentImages.length;
  const displayImage = (tournament as any).image_url || tournamentImages[imageIndex];

  const basePrice = typeof tournament.price === 'number' ? tournament.price : 0;

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'P25': 'bg-success/10 text-success',
      'P50': 'bg-secondary/10 text-secondary-foreground',
      'P100': 'bg-primary/10 text-primary',
      'P250': 'bg-accent/10 text-accent',
    };
    return colors[category] || 'bg-muted text-muted-foreground';
  };


  const getTournamentFormatLabel = (value: any) => {
    const map: Record<string, string> = {
      knockout: 'Tableau direct',
      groups_knockout: 'Poules + tableau',
      round_robin: 'Championnat',
      direct_entry: 'Entrée directe TdS',
    };
    return map[String(value)] || String(value);
  };

  const getGameFormatLabel = (value: any) => {
    const v = String(value);
    return (GAME_FORMAT_CONFIG as any)?.[v]?.label || v;
  };

  const getGenderLabel = (gender: string) => {
    const labels: Record<string, string> = {
      'H': 'Hommes',
      'F': 'Femmes',
      'Mixte': 'Mixte',
    };
    return labels[gender] || gender;
  };

  return (
    <Layout>
      {/* Mobile header with image */}
      <section className="md:hidden">
        <div className="relative">
          <img src={displayImage} alt={tournament.title} className="h-44 w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-black/10" />
          <div className="absolute top-3 left-3">
            <Link
              to="/tournaments"
              className="inline-flex items-center gap-1 rounded-full bg-background/90 px-3 py-2 text-sm shadow"
            >
              <ArrowLeft className="h-4 w-4" />
              Retour
            </Link>
          </div>
          <div className="absolute bottom-3 left-3 right-3">
            <div className="flex flex-wrap gap-2 mb-2">
              <Badge className={getCategoryColor(tournament.category_code)}>{tournament.category_code}</Badge>
              <Badge variant="outline" className="bg-background/90">
                {getGenderLabel(tournament.gender)}
              </Badge>
            </div>
            <h1 className="text-xl font-bold text-white leading-tight">{tournament.title}</h1>
            {tournament.club && (
              <p className="mt-1 text-sm text-white/90">Organisé par {tournament.club.name}</p>
            )}
          </div>
        </div>
      </section>

      {/* Desktop header */}
      <section className="hidden md:block bg-muted/30 py-8 md:py-12">
        <div className="container">
          <Link
            to="/tournaments"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour aux tournois
          </Link>

          <div className="flex flex-wrap gap-2 mb-4">
            <Badge className={getCategoryColor(tournament.category_code)}>
              {tournament.category_code}
            </Badge>
            <Badge variant="outline">
              {getGenderLabel(tournament.gender)}
            </Badge>
            {isExternal ? (
              <Badge variant="external">Tournoi externe</Badge>
            ) : isPlatformManaged ? (
              <Badge variant="platform">Inscriptions sur la plateforme</Badge>
            ) : null}
          </div>

          <h1 className="font-display text-3xl md:text-4xl font-bold mb-4">
            {tournament.title}
          </h1>

          {tournament.club && (
            <p className="text-muted-foreground flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              Organisé par {tournament.club.name}
            </p>
          )}
        </div>
      </section>

      {/* Content */}
      <section className="py-8 md:py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Description */}
              <Card>
                <CardHeader>
                  <CardTitle>À propos du tournoi</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-muted-foreground leading-relaxed ${descExpanded ? '' : 'line-clamp-4'}`}>
                    {tournament.description || 'Description non renseignée.'}
                  </p>
                  {tournament.description && tournament.description.length > 180 && (
                    <Button
                      variant="ghost"
                      className="mt-2 px-0"
                      onClick={() => setDescExpanded(v => !v)}
                    >
                      {descExpanded ? 'Voir moins' : 'Voir plus'}
                    </Button>
                  )}
                </CardContent>
              </Card>

              {/* Player team status (if logged in as player) */}
              <PlayerTeamCard
                tournamentId={tournament.id}
                onTeamLoaded={(team) => setPlayerHasTeam(!!team)}
              />

              {/* Registration */}
              {isPlatformManaged && !isExternal && !playerHasTeam && (
                <div id="registration">
                  <MultiStepRegistrationForm
                    tournamentId={tournament.id}
                    tournamentTitle={tournament.title}
                    tournamentPrice={basePrice || 0}
                  />
                </div>
              )}

              {isPlatformManaged && !isExternal && playerHasTeam && (
                <Card>
                  <CardHeader>
                    <CardTitle>Inscription</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Vous êtes déjà inscrit à ce tournoi. Vous pouvez gérer votre statut et vos paiements dans le bloc
                      <span className="font-medium text-foreground"> Mon équipe</span> ci-dessus.
                    </p>
                  </CardContent>
                </Card>
              )}

              {isExternal && tournament.official_registration_url && (
                <Card>
                  <CardHeader>
                    <CardTitle>Inscription</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">
                      Ce tournoi est géré par un organisme externe. Les inscriptions se font sur le site officiel.
                    </p>
                    <Button variant="external" size="lg" asChild>
                      <a
                        href={tournament.official_registration_url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        S'inscrire sur le site officiel
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Details Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Informations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Calendar className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Dates</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(tournament.start_date), 'd MMMM yyyy', { locale: fr })}
                        {tournament.start_date !== tournament.end_date && (
                          <> - {format(new Date(tournament.end_date), 'd MMMM yyyy', { locale: fr })}</>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Lieu</p>
                      <p className="text-sm text-muted-foreground">
                        {tournament.address}<br />
                        {tournament.postal_code} {tournament.city}<br />
                        {tournament.region}
                      </p>
                    </div>
                  </div>

                  {tournament.club && (
                    (() => {
                      const showEmail = (tournament.club as any).show_email ?? true;
                      const showPhone = (tournament.club as any).show_phone ?? true;
                      const email = showEmail ? (tournament.club as any).email : null;
                      const phone = showPhone ? (tournament.club as any).phone : null;
                      if (!email && !phone) return null;
                      return (
                        <div className="space-y-3">
                          <div className="h-px bg-border" />
                          <p className="font-medium">Contact organisateur</p>
                          {email && (
                            <div className="flex items-start gap-3">
                              <Mail className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                              <div>
                                <p className="text-sm text-muted-foreground">Email</p>
                                <a className="text-sm font-medium hover:underline" href={`mailto:${email}`}>{email}</a>
                              </div>
                            </div>
                          )}
                          {phone && (
                            <div className="flex items-start gap-3">
                              <Phone className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                              <div>
                                <p className="text-sm text-muted-foreground">Téléphone</p>
                                <a className="text-sm font-medium hover:underline" href={`tel:${phone}`}>{phone}</a>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })()
                  )}

                  <div className="flex items-start gap-3">
                    <Users className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Places</p>
                      <p className="text-sm text-muted-foreground">
                        {tournament.registrations_count !== undefined ? (
                          <>{tournament.registrations_count} / {tournament.max_teams} équipes inscrites</>
                        ) : (
                          <>{tournament.max_teams} équipes maximum</>
                        )}
                      </p>
                    </div>
                  </div>

                  {(tournament as any).referee_name && (
                    <div className="flex items-start gap-3">
                      <Tag className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">Juge-arbitre</p>
                        <p className="text-sm text-muted-foreground">{(tournament as any).referee_name}</p>
                      </div>
                    </div>
                  )}

                  {(tournament as any).format && (
                    <div className="flex items-start gap-3">
                      <Trophy className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">Format du tournoi</p>
                        <p className="text-sm text-muted-foreground">{getTournamentFormatLabel((tournament as any).format)}</p>
                      </div>
                    </div>
                  )}

                  {(tournament as any).game_format && (
                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">Format de jeu</p>
                        <p className="text-sm text-muted-foreground">{getGameFormatLabel((tournament as any).game_format)}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-3">
                    <Tag className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Catégorie</p>
                      <p className="text-sm text-muted-foreground">
                        {tournament.category_code} - {getGenderLabel(tournament.gender)}
                      </p>
                    </div>
                  </div>

                </CardContent>
              </Card>

              {/* Progress */}
              {tournament.registrations_count !== undefined && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Inscriptions</span>
                      <span className="font-medium">
                        {tournament.registrations_count} / {tournament.max_teams}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all"
                        style={{
                          width: `${(tournament.registrations_count / tournament.max_teams) * 100}%`,
                        }}
                      />
                    </div>
                    {tournament.registrations_count >= tournament.max_teams ? (
                      <p className="text-sm text-destructive mt-2">Complet</p>
                    ) : (
                      <p className="text-sm text-muted-foreground mt-2">
                        {tournament.max_teams - tournament.registrations_count} place{tournament.max_teams - tournament.registrations_count > 1 ? 's' : ''} restante{tournament.max_teams - tournament.registrations_count > 1 ? 's' : ''}
                      </p>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Sticky CTA (mobile) */}
      {showRegistrationCTA && (
        <div className="md:hidden fixed bottom-16 left-0 right-0 z-40">
          <div className="mx-auto max-w-screen-sm px-4">
            <div className="rounded-2xl border bg-background/95 backdrop-blur shadow-lg p-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs text-muted-foreground">Inscription</div>
                <div className="text-base font-semibold truncate">
                  {basePrice > 0 ? `M'inscrire – ${basePrice.toFixed(0)} € / joueur` : "M'inscrire"}
                </div>
              </div>
              <Button
                className="shrink-0 rounded-xl"
                onClick={() => {
                  const el = document.getElementById('registration');
                  el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
              >
                Continuer
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default TournamentDetail;
