import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { HomeFilters } from '@/components/home/HomeFilters';
import { FeaturedTournamentCard } from '@/components/home/FeaturedTournamentCard';
import { ChampionsPadelLogo } from '@/components/home/ChampionsPadelLogo';
import { supabase } from '@/integrations/supabase/client';
import { ArrowRight, Zap, Shield, BarChart } from 'lucide-react';
import type { Tournament } from '@/types';

const Index = () => {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTournaments = async () => {
      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*, clubs(name, city, region)')
        .gte('end_date', today)
        .order('start_date', { ascending: true })
        .limit(6);

      if (!error && data) {
        const mapped: Tournament[] = data.map((t: any) => ({
          id: t.id,
          club_id: t.club_id,
          club: t.clubs ? {
            id: t.club_id,
            name: t.clubs.name,
            email: '',
            address: t.location || '',
            city: t.clubs.city || t.city || '',
            postal_code: '',
            region: t.clubs.region || t.region || '',
            created_at: '',
            updated_at: '',
          } : undefined,
          title: t.title,
          description: t.description || '',
          address: t.location || '',
          city: t.city || '',
          postal_code: '',
          region: t.region || '',
          category_code: t.category_code || 'P250',
          gender: t.gender || 'Mixte',
          start_date: t.start_date,
          end_date: t.end_date,
          max_teams: t.max_teams || 16,
          official_registration_url: null,
          is_managed_by_platform: true,
          created_at: t.created_at,
          updated_at: t.updated_at,
          latitude: t.latitude,
          longitude: t.longitude,
          image_url: t.image_url || null,
          referee_name: t.referee_name || null,
        }));
        setTournaments(mapped);
      }
      setLoading(false);
    };
    fetchTournaments();
  }, []);


  return (
    <Layout>
      {/* Hero Section - Miles Republic style */}
      <section className="hero-section hero-wave pb-24">
        <div className="container pt-12 pb-20">
          <div className="flex flex-col items-center text-center space-y-6">
            {/* Logo illustration - larger and more prominent */}
            <ChampionsPadelLogo size={120} />

            {/* Main headline - Italic serif like Miles Republic */}
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground max-w-3xl leading-tight">
              TROUVE TON<br />PROCHAIN TOURNOI
            </h1>

            {/* Filters bar - Miles Republic style */}
            <div className="w-full max-w-4xl pt-6">
              <HomeFilters />
            </div>
          </div>
        </div>
      </section>
      {/* Featured Tournaments */}
      <section className="py-16 md:py-20">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-2xl md:text-3xl lg:text-4xl">
              LES TOURNOIS À LA UNE
            </h2>
            <Button variant="ghost" asChild className="hidden sm:flex">
              <Link to="/tournaments">
                Voir tout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {loading ? (
              <p className="text-muted-foreground col-span-full text-center py-8">Chargement...</p>
            ) : tournaments.length > 0 ? (
              tournaments.map((tournament, index) => (
                <FeaturedTournamentCard 
                  key={tournament.id} 
                  tournament={tournament} 
                  index={index}
                />
              ))
            ) : (
              <p className="text-muted-foreground col-span-full text-center py-8">Aucun tournoi trouvé</p>
            )}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Button variant="outline" asChild>
              <Link to="/tournaments">
                Voir tous les tournois
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-secondary">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-display text-primary">500+</div>
              <div className="text-sm text-muted-foreground mt-1">Tournois par an</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-display text-primary">150+</div>
              <div className="text-sm text-muted-foreground mt-1">Clubs partenaires</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-display text-primary">10K+</div>
              <div className="text-sm text-muted-foreground mt-1">Joueurs actifs</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-display text-primary">13</div>
              <div className="text-sm text-muted-foreground mt-1">Régions couvertes</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features for Clubs */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-2xl md:text-3xl lg:text-4xl mb-4">
              ESPACE ORGANISATEUR
            </h2>
            <p className="text-muted-foreground">
              Gérez vos tournois simplement et augmentez votre visibilité
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Inscriptions simplifiées</h3>
              <p className="text-muted-foreground text-sm">
                Gérez toutes les inscriptions depuis un seul tableau de bord. Plus de fichiers Excel !
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <BarChart className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Génération de tableaux</h3>
              <p className="text-muted-foreground text-sm">
                Créez automatiquement vos tableaux de compétition et exportez-les en CSV.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Visibilité nationale</h3>
              <p className="text-muted-foreground text-sm">
                Vos tournois sont visibles par tous les joueurs de France sur notre plateforme.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button size="lg" asChild>
              <Link to="/club/register">
                Créer un compte club
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-secondary">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-2xl md:text-4xl mb-4">
              PRÊT À PARTICIPER ?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Trouvez votre prochain tournoi et inscrivez-vous en quelques clics. 
              Des compétitions pour tous les niveaux vous attendent.
            </p>
            <Button size="lg" asChild>
              <Link to="/tournaments">
                Explorer les tournois
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
