import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Users, UserPlus, Mail, Lock, User, Phone, CreditCard, Calendar, MapPin, ArrowRight, CheckCircle } from 'lucide-react';
import { z } from 'zod';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { frenchRegions } from '@/data/mockData';

// Regex for strong password: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;

const step1Schema = z.object({
  firstName: z.string().min(2, 'Prénom requis'),
  lastName: z.string().min(2, 'Nom requis'),
  email: z.string().email('Email invalide'),
  password: z.string()
    .min(8, 'Minimum 8 caractères')
    .regex(strongPasswordRegex, 'Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial (!@#$%^&*...)'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Les mots de passe ne correspondent pas',
  path: ['confirmPassword'],
});

const step2Schema = z.object({
  phone: z.string().min(10, 'Téléphone requis (min. 10 caractères)'),
  licenseNumber: z.string().optional(),
  dateOfBirth: z.string().min(1, 'Date de naissance requise'),
  city: z.string().min(2, 'Ville requise'),
  region: z.string().min(1, 'Région requise'),
});

export default function PlayerRegister() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', password: '', confirmPassword: '',
    phone: '', licenseNumber: '', dateOfBirth: '', city: '', region: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const updateField = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (errors[field]) setErrors({ ...errors, [field]: '' });
  };

  const validateStep1 = () => {
    const result = step1Schema.safeParse(formData);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    const result = step2Schema.safeParse(formData);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      if (validateStep1()) setStep(2);
      return;
    }

    if (!validateStep2()) return;

    setIsLoading(true);
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: { emailRedirectTo: `${window.location.origin}/player/dashboard` },
      });

      if (authError || !authData.user) {
        toast({ variant: 'destructive', title: 'Erreur', description: authError?.message || 'Erreur de création' });
        setIsLoading(false);
        return;
      }

      // Create player profile
      const { error: profileError } = await supabase
        .from('players')
        .insert({
          user_id: authData.user.id,
          first_name: formData.firstName,
          last_name: formData.lastName,
          email: formData.email,
          phone: formData.phone || null,
          license_number: formData.licenseNumber || null,
          date_of_birth: formData.dateOfBirth || null,
          city: formData.city || null,
          region: formData.region || null,
        });

      if (profileError) {
        console.error('Profile creation error:', profileError);
      }

      toast({ 
        title: 'Compte créé !', 
        description: 'Un email de confirmation vous a été envoyé. Veuillez cliquer sur le lien pour activer votre compte.' 
      });
      navigate('/player/login');
    } catch {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Erreur lors de l\'inscription' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Layout>
      <div className="min-h-[80vh] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-lg space-y-6">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Créer un compte joueur</h1>
          </div>

          <div className="flex items-center justify-center gap-4">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                {step > 1 ? <CheckCircle className="h-5 w-5" /> : '1'}
              </div>
              <span className="text-sm hidden sm:block">Compte</span>
            </div>
            <div className="w-12 h-0.5 bg-muted"><div className={`h-full bg-primary ${step >= 2 ? 'w-full' : 'w-0'}`} /></div>
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>2</div>
              <span className="text-sm hidden sm:block">Profil</span>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><UserPlus className="h-5 w-5" />{step === 1 ? 'Identifiants' : 'Profil joueur'}</CardTitle>
              <CardDescription>{step === 1 ? 'Créez vos identifiants' : 'Complétez votre profil'}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {step === 1 ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Prénom *</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Jean" className="pl-10" value={formData.firstName} onChange={(e) => updateField('firstName', e.target.value)} />
                        </div>
                        {errors.firstName && <p className="text-sm text-destructive">{errors.firstName}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label>Nom *</Label>
                        <Input placeholder="Dupont" value={formData.lastName} onChange={(e) => updateField('lastName', e.target.value)} />
                        {errors.lastName && <p className="text-sm text-destructive">{errors.lastName}</p>}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Email *</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input type="email" placeholder="email@exemple.com" className="pl-10" value={formData.email} onChange={(e) => updateField('email', e.target.value)} />
                      </div>
                      {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Mot de passe *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input type="password" placeholder="••••••••" className="pl-10" value={formData.password} onChange={(e) => updateField('password', e.target.value)} />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Min. 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial
                      </p>
                      {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Confirmer *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input type="password" placeholder="••••••••" className="pl-10" value={formData.confirmPassword} onChange={(e) => updateField('confirmPassword', e.target.value)} />
                      </div>
                      {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
                    </div>
                    <Button type="submit" className="w-full">Continuer <ArrowRight className="ml-2 h-4 w-4" /></Button>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label>Téléphone *</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="06 12 34 56 78" className="pl-10" value={formData.phone} onChange={(e) => updateField('phone', e.target.value)} />
                      </div>
                      {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Numéro de licence FFT</Label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="123456789 (optionnel)" className="pl-10" value={formData.licenseNumber} onChange={(e) => updateField('licenseNumber', e.target.value)} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Date de naissance *</Label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input type="date" className="pl-10" value={formData.dateOfBirth} onChange={(e) => updateField('dateOfBirth', e.target.value)} />
                      </div>
                      {errors.dateOfBirth && <p className="text-sm text-destructive">{errors.dateOfBirth}</p>}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Ville *</Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Paris" className="pl-10" value={formData.city} onChange={(e) => updateField('city', e.target.value)} />
                        </div>
                        {errors.city && <p className="text-sm text-destructive">{errors.city}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label>Région *</Label>
                        <Select value={formData.region} onValueChange={(v) => updateField('region', v)}>
                          <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                          <SelectContent>{frenchRegions.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                        </Select>
                        {errors.region && <p className="text-sm text-destructive">{errors.region}</p>}
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <Button type="button" variant="outline" className="flex-1" onClick={() => setStep(1)}>Retour</Button>
                      <Button type="submit" className="flex-1" disabled={isLoading}>{isLoading ? 'Création...' : 'Créer'}</Button>
                    </div>
                  </>
                )}
              </form>
            </CardContent>
          </Card>

          <p className="text-center text-sm text-muted-foreground">
            Déjà inscrit ? <Link to="/player/login" className="text-primary hover:underline">Se connecter</Link>
          </p>
        </div>
      </div>
    </Layout>
  );
}
