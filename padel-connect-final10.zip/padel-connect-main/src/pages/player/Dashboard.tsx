import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Trophy, LogOut, CreditCard } from 'lucide-react';
import { ProfileEditForm } from '@/components/player/ProfileEditForm';
import { TournamentHistoryCard } from '@/components/player/TournamentHistoryCard';
import { PendingPaymentsCard } from '@/components/player/PendingPaymentsCard';
import { ActiveTeamsCard } from '@/components/player/ActiveTeamsCard';

interface PlayerProfile {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  license_number: string | null;
  date_of_birth: string | null;
  ranking: string | null;
  avatar_url: string | null;
  city: string | null;
  region: string | null;
  created_at: string;
}

interface TournamentParticipation {
  id: string;
  tournament_id: string;
  partner_name: string | null;
  result: string | null;
  ranking_position: number | null;
  created_at: string;
  tournament?: {
    id: string;
    title: string;
    start_date: string;
    end_date: string;
    city: string | null;
    category_code: string | null;
  };
}

export default function PlayerDashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [participations, setParticipations] = useState<TournamentParticipation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { navigate('/player/login'); return; }

      // Fetch player profile
      const { data: playerData, error: playerError } = await supabase
        .from('players')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (playerError || !playerData) {
        toast({ variant: 'destructive', title: 'Erreur', description: 'Profil non trouvé' });
        navigate('/player/login');
        return;
      }

      setProfile(playerData as PlayerProfile);

      // Fetch tournament participations from tournament_teams (single source of truth in current DB schema)
const normalizedEmail = (playerData as any).email.toLowerCase();
const { data: teamsData, error: teamsError } = await supabase
  .from('tournament_teams')
  .select(`
    id,
    created_at,
    tournament_id,
    player1_name,
    player2_name,
    player1_email,
    player2_email,
    status,
    tournament:club_tournaments (
      id,
      title,
      start_date,
      end_date,
      city,
      category_code
    )
  `)
  .or(`player1_email.ilike.${normalizedEmail},player2_email.ilike.${normalizedEmail}`)
  .order('created_at', { ascending: false });

if (teamsError) {
  console.error('Error fetching teams:', teamsError);
} else if (teamsData) {
  const mapped: TournamentParticipation[] = (teamsData as any[])
    .filter((t) => t.tournament)
    .map((t) => ({
      id: t.id,
      tournament_id: t.tournament_id,
      partner_name: t.player1_email?.toLowerCase() === normalizedEmail ? t.player2_name : t.player1_name,
      result: null,
      ranking_position: null,
      created_at: t.created_at || new Date().toISOString(),
      tournament: t.tournament,
    }));
  setParticipations(mapped);
}

setLoading(false);
};
    fetchData();
  }, [navigate, toast]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const handleProfileUpdate = (updatedProfile: PlayerProfile) => {
    setProfile(updatedProfile);
  };

  const handleParticipationCancelled = (participationId: string, _tournamentId: string) => {
    setParticipations(prev => prev.filter(p => p.id !== participationId));
  };

  if (loading) return <Layout><div className="container py-16 text-center"><p className="text-muted-foreground">Chargement...</p></div></Layout>;
  if (!profile) return null;

  const initials = `${profile.first_name[0]}${profile.last_name[0]}`.toUpperCase();
  const tournamentsCount = participations.length;
  const victoriesCount = participations.filter(p => p.ranking_position === 1).length;

  return (
    <Layout>
      <div className="container py-8 max-w-6xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={profile.avatar_url || undefined} />
              <AvatarFallback className="text-2xl bg-primary text-primary-foreground">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold">{profile.first_name} {profile.last_name}</h1>
              <p className="text-muted-foreground">{profile.email}</p>
              {profile.license_number && (
                <Badge variant="secondary" className="mt-1">
                  <CreditCard className="h-3 w-3 mr-1" />
                  Licence: {profile.license_number}
                </Badge>
              )}
            </div>
          </div>
          <Button variant="ghost" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Déconnexion
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="p-3 rounded-full bg-primary/10">
                <Trophy className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">{tournamentsCount}</p>
                <p className="text-sm text-muted-foreground">Tournois</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="p-3 rounded-full bg-yellow-500/10">
                <Trophy className="h-6 w-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-3xl font-bold text-yellow-500">{victoriesCount}</p>
                <p className="text-sm text-muted-foreground">Victoires</p>
              </div>
            </CardContent>
          </Card>
          <Link to="/tournaments" className="block sm:col-span-1 col-span-2">
            <Card className="hover:border-primary transition-colors h-full">
              <CardContent className="flex items-center gap-4 p-6">
                <div className="p-3 rounded-full bg-primary/10">
                  <Trophy className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-semibold">Trouver un tournoi</p>
                  <p className="text-sm text-muted-foreground">Explorer</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Pending Payments Alert */}
        <PendingPaymentsCard 
          playerEmail={profile.email}
          onPaymentComplete={() => {
            // Refresh participations if needed
          }}
        />

        {/* Active teams (status + payments) */}
        <div className="mt-6">
          <ActiveTeamsCard playerEmail={profile.email} />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Profile Edit Form */}
          <ProfileEditForm 
            profile={profile} 
            onUpdate={handleProfileUpdate} 
          />

          {/* Tournament History */}
          <TournamentHistoryCard
            participations={participations}
            playerId={profile.id}
            playerEmail={profile.email}
            onParticipationCancelled={handleParticipationCancelled}
          />
        </div>
      </div>
    </Layout>
  );
}
