import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ClubTournament, TournamentTeam, DrawResult, GroupResult, GeneratedMatch } from '@/types/tournament';
import { generateDraw } from '@/lib/drawEngine';
import { TournamentPublicDisplay } from '@/components/tournaments/TournamentPublicDisplay';
import { TvKnockoutBracket } from '@/components/tv/TvKnockoutBracket';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Tv } from 'lucide-react';


// Build a display draw structure directly from DB matches to avoid any mismatch between regenerated draws and saved matches.
function buildDrawFromDb(dbMatches: any[]): { knockoutDraw?: DrawResult; groupDraw?: GroupResult; roundRobinMatches?: GeneratedMatch[] } | null {
  if (!dbMatches || dbMatches.length === 0) return null;

  // Historically we used round_order>=100 to mark the final bracket.
  // Some DB rows may have round_order starting at 0 even for the final stage, but round_name is prefixed.
  // Use both signals to be robust.
  const isFinalStage = (m: any) => {
    const rn = String(m.round_name || '');
    const ro = m.round_order ?? 0;
    return ro >= 100 || /^Tableau\s+final/i.test(rn);
  };

  const finalStage = dbMatches.filter(isFinalStage);
  const groupStage = dbMatches.filter((m: any) => !isFinalStage(m));

  // Group draw
  let groupDraw: GroupResult | undefined;
  const groupNames = Array.from(new Set(groupStage.map((m: any) => String(m.round_name || ''))))
    .filter(n => n.trim().length > 0)
    .sort((a, b) => a.localeCompare(b));

  if (groupNames.length > 0) {
    const groups = groupNames.map((name, i) => {
      const teamSet = new Set<string>();
      groupStage.filter((m: any) => m.round_name === name).forEach((m: any) => {
        if (m.team_a_id) teamSet.add(m.team_a_id);
        if (m.team_b_id) teamSet.add(m.team_b_id);
      });
      return { name, order: i, team_ids: Array.from(teamSet) };
    });

    const matches: GeneratedMatch[] = groupStage.map((m: any) => ({
      id: m.id,
      round_name: String(m.round_name || ''),
      round_order: m.round_order ?? 0,
      match_order: m.match_order ?? 0,
      slot_a: -1,
      slot_b: -1,
      team_a_id: m.team_a_id || undefined,
      team_b_id: m.team_b_id || undefined,
      is_bye: !!m.is_bye,
      score_a: m.score_a || undefined,
      score_b: m.score_b || undefined,
      winner_id: m.winner_id || undefined,
    })).sort((a, b) => a.round_name.localeCompare(b.round_name) || a.match_order - b.match_order);

    groupDraw = { groups, matches, exemptSeeds: [], finalBracket: undefined };
  }

  // Round robin
  const rr = groupStage.filter((m: any) => String(m.round_name || '').toLowerCase() === 'championnat');
  const roundRobinMatches = rr.length > 0 ? rr.map((m: any) => ({
    id: m.id,
    round_name: String(m.round_name || ''),
    round_order: m.round_order ?? 0,
    match_order: m.match_order ?? 0,
    slot_a: -1,
    slot_b: -1,
    team_a_id: m.team_a_id || undefined,
    team_b_id: m.team_b_id || undefined,
    is_bye: !!m.is_bye,
    score_a: m.score_a || undefined,
    score_b: m.score_b || undefined,
    winner_id: m.winner_id || undefined,
  })).sort((a, b) => a.match_order - b.match_order) : undefined;

  // Knockout draw (final stage)
  let knockoutDraw: DrawResult | undefined;
  if (finalStage.length > 0) {
    const normalized: GeneratedMatch[] = finalStage.map((m: any) => ({
      id: m.id,
      round_name: String(m.round_name || '').replace(/^Tableau final\s*•\s*/i, ''),
      round_order: (() => {
        const ro = m.round_order ?? 0;
        return ro >= 100 ? ro - 100 : ro;
      })(),
      match_order: m.match_order ?? 0,
      slot_a: -1,
      slot_b: -1,
      team_a_id: m.team_a_id || undefined,
      team_b_id: m.team_b_id || undefined,
      is_bye: !!m.is_bye,
      score_a: m.score_a || undefined,
      score_b: m.score_b || undefined,
      winner_id: m.winner_id || undefined,
    })).sort((a, b) => a.round_order - b.round_order || a.match_order - b.match_order);

    knockoutDraw = { slots: [], rounds: [], matches: normalized };
  }

  return { groupDraw, knockoutDraw, roundRobinMatches };
}


const TournamentLiveDisplay = () => {
  const queryClient = useQueryClient();
  const { id } = useParams<{ id: string }>();

  // Realtime sync: refresh TV when a score is entered
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`tv-matches-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tournament_matches', filter: `tournament_id=eq.${id}` }, () => {
        queryClient.invalidateQueries({ queryKey: ['tournament-matches-public', id] });
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'club_tournaments', filter: `id=eq.${id}` }, () => {
        queryClient.invalidateQueries({ queryKey: ['tournament-public', id] });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, queryClient]);


  // Fetch tournament
  const { data: tournament, isLoading: tournamentLoading } = useQuery({
    queryKey: ['tournament-public', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('club_tournaments')
        .select('*, clubs(name)')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data as (ClubTournament & { clubs?: { name: string } }) | null;
    },
    enabled: !!id,
    refetchInterval: 10000, // Refresh every 10 seconds for live updates
  });

  // Fetch teams
  const { data: teams = [], isLoading: teamsLoading } = useQuery({
    queryKey: ['tournament-teams-public', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tournament_teams')
        .select('*')
        .eq('tournament_id', id)
        .order('seed_rank', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data as TournamentTeam[];
    },
    enabled: !!id,
    refetchInterval: 10000,
  });

  // Fetch matches from database
  const { data: dbMatches = [] } = useQuery({
    queryKey: ['tournament-matches-public', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tournament_matches')
        .select('*')
        .eq('tournament_id', id)
        .order('round_order', { ascending: true })
        .order('match_order', { ascending: true });
      
      if (error) throw error;
      return data;
    },
    enabled: !!id,
    refetchInterval: 5000, // Refresh matches more frequently
  });

  // Generate draw structure
  const [localDraw, setLocalDraw] = useState<{
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  } | null>(null);

  useEffect(() => {
    if (tournament && teams.length > 0 && tournament.draw_generated) {
      // Prefer DB matches as source of truth to avoid any mismatch between regenerated draws and saved matches.
      if (dbMatches && dbMatches.length > 0) {
        const fromDb = buildDrawFromDb(dbMatches);
        if (fromDb) {
          setLocalDraw(fromDb);
          return;
        }
      }

      const confirmedTeams = teams.filter(t => t.status === 'confirmed');
      if (confirmedTeams.length >= 2) {
        const result = generateDraw(tournament as any, confirmedTeams, tournament.random_seed || undefined);
        setLocalDraw(result);
      }
    }
  }, [tournament, teams, dbMatches]);

  if (tournamentLoading || teamsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Tv className="h-16 w-16 text-primary mx-auto animate-pulse" />
          <p className="text-xl text-muted-foreground">Chargement du tableau...</p>
        </div>
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Tournoi non trouvé</h1>
          <p className="text-muted-foreground">Ce tournoi n'existe pas ou n'est pas accessible.</p>
          <Button asChild>
            <Link to="/tournaments">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voir tous les tournois
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  if (!tournament.draw_generated || !localDraw) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Tv className="h-16 w-16 text-muted-foreground mx-auto" />
          <h1 className="text-2xl font-bold">{tournament.title}</h1>
          <p className="text-muted-foreground">Le tableau n'a pas encore été généré.</p>
          <p className="text-sm text-muted-foreground">Revenez plus tard lorsque le tournoi aura commencé.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* TV header */}
      <div className="px-6 py-4 border-b flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">{tournament.title}</h1>
          <p className="text-sm text-muted-foreground">{tournament.clubs?.name || ''}</p>
        </div>
        <div className="text-sm text-muted-foreground">
          {tournament.location || ''}
        </div>
      </div>

      {localDraw.knockoutDraw ? (
        <div className="p-4">
          <TvKnockoutBracket matches={localDraw.knockoutDraw.matches} teams={teams} />
        </div>
      ) : (
        <TournamentPublicDisplay
          tournament={{
            id: tournament.id,
            title: tournament.title,
            format: tournament.format,
            game_format: tournament.game_format,
            qualifiers_per_group: tournament.qualifiers_per_group,
            start_date: tournament.start_date,
            end_date: tournament.end_date,
            location: tournament.location || undefined,
          }}
          teams={teams}
          knockoutDraw={localDraw.knockoutDraw}
          groupDraw={localDraw.groupDraw}
          roundRobinMatches={localDraw.roundRobinMatches}
          clubName={tournament.clubs?.name}
        />
      )}
    </div>
  );
};

export default TournamentLiveDisplay;