import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { supabase } from '@/integrations/supabase/client';
import { BarChart3, Bug, DollarSign, Shield, Trophy, Users } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { data: adminData, isLoading: adminLoading } = useIsAdmin();

  const { data: pendingCount } = useQuery({
    queryKey: ['admin', 'club_requests', 'pending_count'],
    queryFn: async () => {
      const { count } = await supabase
        .from('club_requests')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'pending');
      return count ?? 0;
    },
    enabled: !!adminData?.isAdmin,
  });

  if (!adminLoading && !adminData?.isAdmin) {
    // Not admin: redirect to login
    navigate('/admin/login');
  }

  return (
    <Layout>
      <div className="py-8">
        <div className="container max-w-6xl space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold">Centre de contrôle</h1>
              <p className="text-muted-foreground">🧠 Sport • 💰 Finance • 📊 Business • ⚙️ Technique</p>
            </div>
            <div className="flex gap-2">
              <Button asChild variant="outline">
                <Link to="/admin/club-requests">Demandes clubs</Link>
              </Button>
              <Button
                variant="outline"
                onClick={async () => {
                  await supabase.auth.signOut();
                  navigate('/');
                }}
              >
                Déconnexion
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Shield className="h-4 w-4" /> Validation clubs
                </CardTitle>
              </CardHeader>
              <CardContent className="flex items-center justify-between">
                <div className="text-2xl font-bold">{pendingCount ?? '—'}</div>
                <Badge variant="secondary">pending</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Trophy className="h-4 w-4" /> Contrôle sportif
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Tournois, tirages, résultats, classements.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="h-4 w-4" /> Contrôle financier
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Paiements, frais plateforme, exports.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Bug className="h-4 w-4" /> Contrôle technique
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Logs, erreurs, emails, actions admin.</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><Users className="h-4 w-4" /> Clubs</CardTitle>
              </CardHeader>
              <CardContent className="flex gap-2 flex-wrap">
                <Button asChild size="sm"><Link to="/admin/club-requests">Voir les demandes</Link></Button>
                <Button asChild size="sm" variant="outline"><Link to="/club/register">Formulaire public</Link></Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="h-4 w-4" /> Business</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  À brancher : KPI par club/tournoi, revenus frais plateforme (2€ / paiement joueur), rétention.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
