import { Link, useNavigate, useParams } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { supabase } from '@/integrations/supabase/client';
import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';

type ClubRequest = any;

export default function AdminClubRequestDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: adminData, isLoading: adminLoading } = useIsAdmin();
  const [note, setNote] = useState('');
  const [reason, setReason] = useState('');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['admin', 'club_requests', 'detail', id],
    queryFn: async () => {
      const { data, error } = await supabase.from('club_requests').select('*').eq('id', id).single();
      if (error) throw new Error(error.message);
      return data as ClubRequest;
    },
    enabled: !!adminData?.isAdmin && !!id,
  });

  if (!adminLoading && !adminData?.isAdmin) {
    navigate('/admin/login');
  }

  const clubName = useMemo(() => {
    if (!data) return '';
    return data.commercial_name || data.legal_name;
  }, [data]);

  const updateStatus = async (status: 'approved' | 'rejected') => {
    if (!id) return;
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const reviewer = sessionData.session?.user?.id;

      const payload: any = {
        status,
        reviewed_at: new Date().toISOString(),
        reviewed_by: reviewer ?? null,
        internal_note: note || null,
      };
      if (status === 'rejected') payload.rejection_reason = reason || null;
      if (status === 'approved') payload.rejection_reason = null;

      const { error } = await supabase.from('club_requests').update(payload).eq('id', id);
      if (error) throw new Error(error.message);

      toast({
        title: status === 'approved' ? 'Demande approuvée ✅' : 'Demande refusée',
        description: status === 'approved' ? "Le club peut maintenant être onboardé (création du compte organisateur)." : 'La demande a été mise en rejet.',
      });
      await refetch();
    } catch (err: any) {
      toast({ title: 'Erreur', description: err?.message || 'Action impossible', variant: 'destructive' });
    }
  };

  return (
    <Layout>
      <div className="py-8">
        <div className="container max-w-5xl space-y-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold">Demande club</h1>
              <p className="text-muted-foreground">Validation manuelle • {clubName || '—'}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" asChild><Link to="/admin/club-requests">Retour</Link></Button>
              <Button variant="outline" onClick={() => refetch()}>Rafraîchir</Button>
            </div>
          </div>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-base">Détails</CardTitle>
              {data?.status && (
                <Badge variant={data.status === 'pending' ? 'secondary' : data.status === 'approved' ? 'default' : 'destructive'}>
                  {data.status}
                </Badge>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoading ? (
                <p className="text-sm text-muted-foreground">Chargement…</p>
              ) : !data ? (
                <p className="text-sm text-muted-foreground">Demande introuvable.</p>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Club</div>
                    <div className="font-medium">{clubName}</div>
                    <div className="text-sm text-muted-foreground">{data.address} • {data.postal_code} {data.city}</div>
                    <div className="text-sm text-muted-foreground">{data.country}</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Contact</div>
                    <div className="font-medium">{data.representative_first_name} {data.representative_last_name} — {data.representative_role}</div>
                    <div className="text-sm">{data.representative_email}</div>
                    <div className="text-sm">{data.representative_phone || '—'}</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Identifiant</div>
                    <div className="text-sm">Structure: {data.structure_type || '—'}</div>
                    <div className="text-sm">SIREN/SIRET: {data.siren_siret || '—'}</div>
                    <div className="text-sm">RNA: {data.rna_number || '—'}</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Infos</div>
                    <div className="text-sm">Site: {data.website || '—'}</div>
                    <div className="text-sm">Terrains: {data.courts_count ?? '—'}</div>
                    <div className="text-sm">Message: {data.message || '—'}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Traitement admin</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="note">Note interne (optionnel)</Label>
                <Textarea id="note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="ex: OK après appel / vérifier RNA / etc." />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reason">Raison de refus (si rejet)</Label>
                <Input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="ex: infos incomplètes" />
              </div>
              <div className="flex gap-2 flex-wrap">
                <Button onClick={() => updateStatus('approved')} disabled={!id}>Approuver</Button>
                <Button variant="destructive" onClick={() => updateStatus('rejected')} disabled={!id}>Refuser</Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Note: l'étape suivante (onboarding) consiste à créer le compte organisateur et le club dans la table <code>clubs</code>.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
