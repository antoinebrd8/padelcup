import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { supabase } from '@/integrations/supabase/client';
import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';

type ClubRequestRow = {
  id: string;
  created_at: string;
  status: string;
  legal_name: string;
  commercial_name: string | null;
  city: string | null;
  representative_email: string;
  representative_phone: string | null;
};

export default function AdminClubRequests() {
  const navigate = useNavigate();
  const { data: adminData, isLoading: adminLoading } = useIsAdmin();
  const [q, setQ] = useState('');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['admin', 'club_requests', 'list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('club_requests')
        .select('id, created_at, status, legal_name, commercial_name, city, representative_email, representative_phone')
        .order('created_at', { ascending: false });
      if (error) throw new Error(error.message);
      return (data || []) as ClubRequestRow[];
    },
    enabled: !!adminData?.isAdmin,
  });

  if (!adminLoading && !adminData?.isAdmin) {
    navigate('/admin/login');
  }

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return data || [];
    return (data || []).filter((r) => {
      const name = (r.commercial_name || r.legal_name || '').toLowerCase();
      const city = (r.city || '').toLowerCase();
      const email = (r.representative_email || '').toLowerCase();
      return name.includes(term) || city.includes(term) || email.includes(term);
    });
  }, [data, q]);

  return (
    <Layout>
      <div className="py-8">
        <div className="container max-w-5xl space-y-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold">Demandes clubs</h1>
              <p className="text-muted-foreground">Validation manuelle des accès organisateur</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" asChild><Link to="/admin">Retour</Link></Button>
              <Button variant="outline" onClick={() => refetch()}>Rafraîchir</Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Input placeholder="Rechercher (club, ville, email)…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Liste</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {isLoading ? (
                <p className="text-sm text-muted-foreground">Chargement…</p>
              ) : filtered.length === 0 ? (
                <p className="text-sm text-muted-foreground">Aucune demande.</p>
              ) : (
                <div className="space-y-2">
                  {filtered.map((r) => (
                    <Link key={r.id} to={`/admin/club-requests/${r.id}`} className="block">
                      <div className="flex items-center justify-between gap-3 rounded-lg border p-3 hover:bg-muted/30 transition-colors">
                        <div className="min-w-0">
                          <div className="font-medium truncate">{r.commercial_name || r.legal_name}</div>
                          <div className="text-sm text-muted-foreground truncate">{r.city || '—'} • {r.representative_email}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={r.status === 'pending' ? 'secondary' : r.status === 'approved' ? 'default' : 'destructive'}>
                            {r.status}
                          </Badge>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
