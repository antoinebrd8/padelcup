import { useState, useMemo, useEffect, Suspense } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { TournamentListCard } from '@/components/tournaments/TournamentListCard';
// Lazy-load the map: it is heavy and slows down mobile significantly.
import React from 'react';
// Some previous iterations referenced `TournamentMap` directly in JSX.
// Expose the lazy component with that exact name to avoid runtime ReferenceError.
const TournamentMap = React.lazy(async () => {
  const mod = await import('@/components/tournaments/TournamentMap');
  return { default: mod.TournamentMap };
});
import { TournamentFilters } from '@/components/tournaments/TournamentFilters';
import { TournamentFilters as FiltersType, Tournament, CategoryCode, Gender } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from '@/components/ui/sheet';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { SlidersHorizontal, Map } from 'lucide-react';

// Calcul de distance Haversine entre deux points GPS en km
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Rayon de la Terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Validate category code
const isValidCategory = (value: string | null): value is CategoryCode => {
  return value !== null && ['P25', 'P50', 'P100', 'P250'].includes(value);
};

// Validate gender
const isValidGender = (value: string | null): value is Gender => {
  return value !== null && ['H', 'F', 'Mixte'].includes(value);
};

const Tournaments = () => {
  const [searchParams] = useSearchParams();
  
  // Parse initial filters from URL params with type validation
  const categoryParam = searchParams.get('category');
  const genderParam = searchParams.get('gender');
  
  const initialFilters: FiltersType = {
    region: searchParams.get('region') || undefined,
    city: searchParams.get('city') || undefined,
    category: isValidCategory(categoryParam) ? categoryParam : undefined,
    gender: isValidGender(genderParam) ? genderParam : undefined,
    start_date: searchParams.get('start_date') || undefined,
    end_date: searchParams.get('end_date') || undefined,
    max_distance: searchParams.get('max_distance') ? Number(searchParams.get('max_distance')) : undefined,
  };
  
  // Parse initial user location from URL params
  const initialUserLocation = searchParams.get('lat') && searchParams.get('lng')
    ? { lat: Number(searchParams.get('lat')), lng: Number(searchParams.get('lng')) }
    : null;

  const [filters, setFilters] = useState<FiltersType>(initialFilters);
  const [selectedTournamentId, setSelectedTournamentId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>('date');
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(initialUserLocation);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [mapOpen, setMapOpen] = useState(false);

  useEffect(() => {
    const fetchTournaments = async () => {
      setLoading(true);
      
      // Fetch club tournaments from Supabase
      const { data: clubTournaments, error } = await supabase
        .from('club_tournaments')
        .select(`
          *,
          clubs (
            id,
            name,
            email,
            address,
            city,
            region
          )
        `);

      if (error) {
        console.error('Error fetching tournaments:', error);
        setLoading(false);
        return;
      }

      // Fetch registrations count for each tournament
      const tournamentIds = clubTournaments?.map(t => t.id) || [];
      const registrationCounts: Record<string, number> = {};
      
      if (tournamentIds.length > 0) {
        const { data: teams } = await supabase
          .from('tournament_teams')
          .select('tournament_id')
          .in('tournament_id', tournamentIds);
        
        if (teams) {
          teams.forEach(team => {
            registrationCounts[team.tournament_id] = (registrationCounts[team.tournament_id] || 0) + 1;
          });
        }
      }

      // Transform club tournaments to match Tournament type
      const transformedTournaments: Tournament[] = (clubTournaments || []).map((t) => ({
        id: t.id,
        club_id: t.club_id,
        club: t.clubs ? {
          id: t.clubs.id,
          name: t.clubs.name,
          email: t.clubs.email,
          address: t.clubs.address || '',
          city: t.clubs.city || '',
          postal_code: '',
          region: t.clubs.region || '',
          created_at: '',
          updated_at: '',
        } : undefined,
        title: t.title,
        description: t.description || '',
        address: t.location || '',
        city: t.city || '',
        postal_code: '',
        region: t.region || '',
        category_code: (t.category_code || 'P100') as Tournament['category_code'],
        gender: (t.gender || 'Mixte') as Tournament['gender'],
        start_date: t.start_date,
        end_date: t.end_date,
        max_teams: t.max_teams || 16,
        official_registration_url: null,
        is_managed_by_platform: true,
        created_at: t.created_at,
        updated_at: t.updated_at,
        registrations_count: registrationCounts[t.id] || 0,
        latitude: t.latitude ? Number(t.latitude) : undefined,
        longitude: t.longitude ? Number(t.longitude) : undefined,
        image_url: t.image_url || null,
        referee_name: t.referee_name || null,
        price: t.price ?? null,
      }));

      setTournaments(transformedTournaments);
      setLoading(false);
    };

    fetchTournaments();
  }, []);

  const filteredTournaments = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let filtered = tournaments.filter((tournament) => {
      // Exclure les tournois passés
      if (new Date(tournament.end_date) < today) return false;
      
      if (filters.region && tournament.region !== filters.region) return false;
      if (filters.city && tournament.city !== filters.city) return false;
      if (filters.category && tournament.category_code !== filters.category) return false;
      if (filters.gender && tournament.gender !== filters.gender) return false;
      // Filtre par date: afficher les tournois qui commencent à partir de cette date
      if (filters.start_date && tournament.start_date < filters.start_date) return false;
      // Filtre par date fin: afficher uniquement les tournois qui commencent avant cette date
      if (filters.end_date && tournament.start_date > filters.end_date) return false;
      
      // Filtre par distance si l'utilisateur a une position et un max_distance
      if (userLocation && filters.max_distance && tournament.latitude && tournament.longitude) {
        const distance = calculateDistance(
          userLocation.lat,
          userLocation.lng,
          tournament.latitude,
          tournament.longitude
        );
        if (distance > filters.max_distance) return false;
      }
      
      return true;
    });

    // Sort
    switch (sortBy) {
      case 'date':
        filtered.sort((a, b) => new Date(a.start_date).getTime() - new Date(b.start_date).getTime());
        break;
      case 'name':
        filtered.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'registrations':
        filtered.sort((a, b) => (b.registrations_count || 0) - (a.registrations_count || 0));
        break;
      case 'distance':
        if (userLocation) {
          filtered.sort((a, b) => {
            const distA = a.latitude && a.longitude 
              ? calculateDistance(userLocation.lat, userLocation.lng, a.latitude, a.longitude) 
              : Infinity;
            const distB = b.latitude && b.longitude 
              ? calculateDistance(userLocation.lat, userLocation.lng, b.latitude, b.longitude) 
              : Infinity;
            return distA - distB;
          });
        }
        break;
    }

    return filtered;
  }, [tournaments, filters, sortBy, userLocation]);

  // Calcul des distances pour affichage
  const tournamentsWithDistance = useMemo(() => {
    if (!userLocation) return filteredTournaments.map(t => ({ ...t, distance: undefined }));
    
    return filteredTournaments.map(t => ({
      ...t,
      distance: t.latitude && t.longitude
        ? Math.round(calculateDistance(userLocation.lat, userLocation.lng, t.latitude, t.longitude))
        : undefined,
    }));
  }, [filteredTournaments, userLocation]);

  // Extract unique cities from tournaments
  const availableCities = useMemo(() => {
    return [...new Set(tournaments.map(t => t.city).filter(Boolean))].sort();
  }, [tournaments]);

  return (
    <Layout>
      <div className="h-[calc(100vh-4rem)] flex flex-col">
        {/* Mobile top controls */}
        <div className="md:hidden border-b border-border bg-background/80 backdrop-blur">
          <div className="container py-3 flex items-center gap-2">
            <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filtres
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>Filtres</SheetTitle>
                </SheetHeader>
                <div className="mt-4">
                  <TournamentFilters
                    filters={filters}
                    onFiltersChange={setFilters}
                    userLocation={userLocation}
                    onUserLocationChange={setUserLocation}
                    availableCities={availableCities}
                  />
                  <div className="mt-4">
                    <Button className="w-full" onClick={() => setFiltersOpen(false)}>
                      Voir les résultats
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="flex-1 text-sm">
                <span className="text-muted-foreground mr-1">Trier :</span>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Date</SelectItem>
                <SelectItem value="name">Nom</SelectItem>
                {userLocation && <SelectItem value="distance">Distance</SelectItem>}
                <SelectItem value="registrations">Popularité</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              className="shrink-0"
              onClick={() => setMapOpen(true)}
              aria-label="Carte"
            >
              <Map className="h-4 w-4" />
            </Button>

            <Sheet open={mapOpen} onOpenChange={setMapOpen}>
              <SheetContent side="bottom" className="h-[85vh] p-0">
                <div className="h-full flex flex-col">
                  <SheetHeader className="px-4 py-3 border-b flex items-center justify-between">
                    <div>
                      <SheetTitle>Carte</SheetTitle>
                      <VisuallyHidden>
                        <SheetDescription>Affiche les tournois sur une carte.</SheetDescription>
                      </VisuallyHidden>
                    </div>
                    <Button variant="ghost" onClick={() => setMapOpen(false)}>Fermer</Button>
                  </SheetHeader>
                  <div className="flex-1">
	                    <Suspense fallback={<div className="h-full flex items-center justify-center text-sm text-muted-foreground">Chargement de la carte…</div>}>
	                      <TournamentMap
                        tournaments={tournamentsWithDistance}
                        selectedTournamentId={selectedTournamentId}
                        onTournamentSelect={setSelectedTournamentId}
                      />
                    </Suspense>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Desktop filters */}
        <div className="hidden md:block container py-4 border-b border-border">
          <TournamentFilters
            filters={filters}
            onFiltersChange={setFilters}
            userLocation={userLocation}
            onUserLocationChange={setUserLocation}
            availableCities={availableCities}
          />
        </div>
        
        {/* Header */}
        <div className="container py-4 border-b border-border">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <h1 className="font-display text-xl md:text-2xl font-bold italic">
              {filteredTournaments.length} tournoi{filteredTournaments.length > 1 ? 's' : ''} trouvé{filteredTournaments.length > 1 ? 's' : ''}
              {userLocation && filters.max_distance && (
                <span className="text-muted-foreground font-normal text-base ml-2">
                  dans un rayon de {filters.max_distance} km
                </span>
              )}
            </h1>
            
            <div className="hidden md:flex items-center gap-3">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px] text-sm">
                  <span className="text-muted-foreground mr-1">Trier :</span>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="name">Nom</SelectItem>
                  {userLocation && <SelectItem value="distance">Distance</SelectItem>}
                  <SelectItem value="registrations">Popularité</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Main content - Split view */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left column - Tournament list */}
          <div className="w-full lg:w-3/4 overflow-y-auto">
            <div className="p-4">
              {tournamentsWithDistance.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                  {tournamentsWithDistance.map((tournament) => (
                    <TournamentListCard
                      key={tournament.id}
                      tournament={tournament}
                      distance={tournament.distance}
                      isSelected={selectedTournamentId === tournament.id}
                      onMouseEnter={() => setSelectedTournamentId(tournament.id)}
                      onMouseLeave={() => setSelectedTournamentId(null)}
                    />
                  ))}
                </div>
              ) : loading ? (
                <div className="text-center py-16">
                  <p className="text-muted-foreground">Chargement des tournois...</p>
                </div>
              ) : (
                <div className="text-center py-16">
                  <h3 className="font-semibold text-lg mb-2">Aucun tournoi trouvé</h3>
                  <p className="text-muted-foreground">
                    Essayez de modifier vos filtres pour voir plus de résultats
                  </p>
                </div>
              )}
            </div>
          </div>
          
          {/* Right column - Map (hidden on mobile) */}
          <div className="hidden lg:block lg:w-1/4 p-4 pl-0">
	            <Suspense fallback={<div className="h-[60vh] rounded-xl bg-muted animate-pulse" />}> 
	              <TournamentMap
                tournaments={filteredTournaments}
                selectedTournamentId={selectedTournamentId}
                onTournamentSelect={setSelectedTournamentId}
                userLocation={userLocation}
              />
            </Suspense>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Tournaments;
