import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { TvKnockoutBracket } from '@/components/tv/TvKnockoutBracket';
import { TournamentPublicDisplay } from '@/components/tournaments/TournamentPublicDisplay';
import { generateDraw } from '@/lib/drawEngine';
import { ClubTournament, TournamentTeam, TournamentFormat, GameFormat } from '@/types/tournament';
import { cn } from '@/lib/utils';

type Scenario = {
  key: string;
  title: string;
  subtitle: string;
  tournament: Pick<ClubTournament,
    | 'id'
    | 'club_id'
    | 'title'
    | 'start_date'
    | 'end_date'
    | 'format'
    | 'draw_size_mode'
    | 'draw_size_manual'
    | 'seeds_direct_count'
    | 'group_size'
    | 'qualifiers_per_group'
    | 'byes_priority_for_seeds'
    | 'draw_generated'
    | 'draw_locked'
    | 'random_seed'
    | 'game_format'
    | 'created_at'
    | 'updated_at'
  >;
  teamsCount: number;
  seedRanks?: number[]; // seed ranks to assign to first N teams
};

function isoDate(daysFromNow: number) {
  const d = new Date();
  d.setDate(d.getDate() + daysFromNow);
  return d.toISOString().slice(0, 10);
}

function makeTeams(tournamentId: string, n: number, seedRanks?: number[]): TournamentTeam[] {
  const now = new Date().toISOString();
  return Array.from({ length: n }).map((_, i) => {
    const seed_rank = seedRanks && i < seedRanks.length ? seedRanks[i] : undefined;
    const p1 = `Joueur ${i + 1}`;
    const p2 = `Coéquipier ${i + 1}`;
    return {
      id: `team_${tournamentId}_${i + 1}`,
      tournament_id: tournamentId,
      name: `${p1} / ${p2}`,
      player1_name: p1,
      player1_email: `player${i + 1}@example.com`,
      player2_name: p2,
      player2_email: `mate${i + 1}@example.com`,
      seed_rank,
      status: 'confirmed',
      player1_payment_status: 'paid',
      player2_payment_status: 'paid',
      player1_has_license: true,
      player2_has_license: true,
      created_at: now,
      updated_at: now,
    };
  });
}

function baseTournament(format: TournamentFormat, gameFormat: GameFormat, overrides?: Partial<ClubTournament>): ClubTournament {
  const now = new Date().toISOString();
  return {
    id: overrides?.id ?? `dbg_${format}_${Math.random().toString(16).slice(2)}`,
    club_id: 'dbg_club',
    title: overrides?.title ?? `Debug ${format}`,
    description: 'Tournoi de test (debug)',
    start_date: isoDate(1),
    end_date: isoDate(1),
    location: 'Debug Court',
    city: 'Lyon',
    region: 'Auvergne-Rhône-Alpes',
    category_code: 'P25',
    gender: 'male',
    max_teams: 64,
    price: 10,
    format,
    draw_size_mode: 'auto',
    draw_size_manual: undefined,
    final_draw_size: undefined,
    seeds_direct_count: 0,
    group_size: 4,
    qualifiers_per_group: 2,
    byes_priority_for_seeds: true,
    draw_generated: true,
    draw_locked: true,
    random_seed: 12345,
    game_format: gameFormat,
    created_at: now,
    updated_at: now,
    ...overrides,
  };
}

const SCENARIOS: Scenario[] = [
  {
    key: 'ko8',
    title: 'Knockout 8 équipes',
    subtitle: 'Tableau 8 (seeds 1-2-3-4)',
    tournament: {
      ...baseTournament('knockout', 'D2', { title: 'KO 8 équipes' }),
    },
    teamsCount: 8,
    seedRanks: [1, 2, 3, 4],
  },
  {
    key: 'ko5',
    title: 'Knockout 5 équipes',
    subtitle: 'Tableau auto 8 + BYEs',
    tournament: {
      ...baseTournament('knockout', 'D2', { title: 'KO 5 équipes' }),
    },
    teamsCount: 5,
    seedRanks: [1, 2],
  },
  {
    key: 'gk_4x4_q2',
    title: 'Poules + KO (4 poules de 4)',
    subtitle: '2 qualifiés / poule + 2 TdS exemptées',
    tournament: {
      ...baseTournament('groups_knockout', 'D2', {
        title: 'Groupes 4x4 → KO',
        group_size: 4,
        qualifiers_per_group: 2,
        seeds_direct_count: 2,
      }),
    },
    teamsCount: 16,
    seedRanks: [1, 2, 3, 4],
  },
  {
    key: 'gk_4x3_q1',
    title: 'Poules + KO (4 poules de 3)',
    subtitle: '1 qualifié / poule (petit tableau)',
    tournament: {
      ...baseTournament('groups_knockout', 'D2', {
        title: 'Groupes 4x3 → KO',
        group_size: 3,
        qualifiers_per_group: 1,
        seeds_direct_count: 0,
      }),
    },
    teamsCount: 12,
    seedRanks: [1, 2],
  },
  {
    key: 'rr5',
    title: 'Round robin (5 équipes)',
    subtitle: 'Tous contre tous (10 matchs)',
    tournament: {
      ...baseTournament('round_robin', 'D2', { title: 'Round robin 5' }),
    },
    teamsCount: 5,
  },
  {
    key: 'de10',
    title: 'Direct entry (10 équipes)',
    subtitle: 'Tableau auto (16) + byes, seeds 1-2-3-4',
    tournament: {
      ...baseTournament('direct_entry', 'D2', { title: 'Direct entry 10' }),
    },
    teamsCount: 10,
    seedRanks: [1, 2, 3, 4],
  },
];

export default function DebugFormats() {
  const [activeKey, setActiveKey] = useState(SCENARIOS[0].key);

  const scenario = useMemo(() => SCENARIOS.find((s) => s.key === activeKey)!, [activeKey]);
  const tournament = useMemo(() => ({ ...scenario.tournament } as ClubTournament), [scenario]);
  const teams = useMemo(() => makeTeams(tournament.id, scenario.teamsCount, scenario.seedRanks), [tournament.id, scenario]);

  const draw = useMemo(() => {
    // IMPORTANT: drawEngine expects confirmed teams only; our mocks are all confirmed.
    return generateDraw(tournament, teams, tournament.random_seed ?? 12345);
  }, [tournament, teams]);

  const matches = useMemo(() => {
    const all: any[] = [];
    if (draw.knockoutDraw?.matches) all.push(...draw.knockoutDraw.matches);
    if (draw.groupDraw?.matches) all.push(...draw.groupDraw.matches);
    if (draw.groupDraw?.finalBracket?.matches) all.push(...draw.groupDraw.finalBracket.matches);
    if (draw.roundRobinMatches) all.push(...draw.roundRobinMatches);
    return all;
  }, [draw]);

  const hasKnockout = !!draw.knockoutDraw || !!draw.groupDraw?.finalBracket;
  const knockoutMatches = draw.knockoutDraw?.matches ?? draw.groupDraw?.finalBracket?.matches ?? [];

  const summary = useMemo(() => {
    const groupMatches = draw.groupDraw?.matches?.length ?? 0;
    const finalMatches = draw.groupDraw?.finalBracket?.matches?.filter(m => !m.is_bye).length ?? 0;
    const koMatches = draw.knockoutDraw?.matches?.filter(m => !m.is_bye).length ?? 0;
    const rrMatches = draw.roundRobinMatches?.filter(m => !m.is_bye).length ?? 0;
    return {
      teams: teams.length,
      groupMatches,
      finalMatches,
      koMatches,
      rrMatches,
      totalMatches: matches.filter(m => !m.is_bye).length,
    };
  }, [draw, teams.length, matches]);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-2xl font-extrabold">Debug • Formats & Tableaux</div>
            <div className="text-muted-foreground">
              Page de test locale pour vérifier que chaque format se génère et s’affiche (public + TV).
            </div>
          </div>
          <Badge variant="secondary" className="h-7">/debug/formats</Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Scénarios</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {SCENARIOS.map((s) => (
                <Button
                  key={s.key}
                  variant={s.key === activeKey ? 'default' : 'outline'}
                  onClick={() => setActiveKey(s.key)}
                  className="h-9"
                >
                  {s.title}
                </Button>
              ))}
            </div>
            <div className="mt-3 text-sm text-muted-foreground">{scenario.subtitle}</div>

            <Separator className="my-4" />

            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Format</div>
                <div className="font-semibold">{tournament.format}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Équipes</div>
                <div className="font-semibold">{summary.teams}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Matchs poules</div>
                <div className="font-semibold">{summary.groupMatches}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Matchs KO</div>
                <div className="font-semibold">{summary.koMatches || summary.finalMatches}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Round robin</div>
                <div className="font-semibold">{summary.rrMatches}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Total</div>
                <div className="font-semibold">{summary.totalMatches}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Rendu public (référence)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-2xl border bg-muted/20 p-4">
                <TournamentPublicDisplay
                  tournament={{
                    id: tournament.id,
                    title: tournament.title,
                    format: tournament.format,
                    game_format: tournament.game_format,
                    qualifiers_per_group: tournament.qualifiers_per_group,
                    start_date: tournament.start_date,
                    end_date: tournament.end_date,
                    location: tournament.location,
                  }}
                  teams={teams}
                  knockoutDraw={draw.knockoutDraw ?? draw.groupDraw?.finalBracket}
                  groupDraw={draw.groupDraw}
                  roundRobinMatches={draw.roundRobinMatches}
                  clubName="Debug Club"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Rendu TV (bracket KO)</CardTitle>
            </CardHeader>
            <CardContent>
              {!hasKnockout ? (
                <div className="text-sm text-muted-foreground">
                  Ce scénario n’a pas de tableau KO (normal pour round robin).
                </div>
              ) : (
                <div className={cn('rounded-2xl border bg-background/60', 'overflow-hidden')}>
                  <TvKnockoutBracket matches={knockoutMatches} teams={teams} />
                </div>
              )}
              <div className="mt-3 text-xs text-muted-foreground">
                Astuce: si le bracket te paraît “écrasé”, mets la page en plein écran.
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
