import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export interface PlayerProfile {
  id: string;
  user_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  license_number: string | null;
  date_of_birth: string | null;
  ranking: string | null;
  avatar_url: string | null;
  city: string | null;
  region: string | null;
  created_at: string;
  updated_at: string;
}

interface PlayerAuthContextType {
  user: User | null;
  session: Session | null;
  player: PlayerProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  refreshPlayer: () => Promise<void>;
}

const PlayerAuthContext = createContext<PlayerAuthContextType | undefined>(undefined);

export function PlayerAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [player, setPlayer] = useState<PlayerProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchPlayer = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from('players')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (data && !error) {
      setPlayer(data as PlayerProfile);
    } else {
      setPlayer(null);
    }
  }, []);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setTimeout(() => {
            fetchPlayer(session.user.id);
          }, 0);
        } else {
          setPlayer(null);
        }
        
        setIsLoading(false);
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchPlayer(session.user.id);
      }
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [fetchPlayer]);

  const refreshPlayer = useCallback(async () => {
    if (user) {
      await fetchPlayer(user.id);
    }
  }, [user, fetchPlayer]);

  return (
    <PlayerAuthContext.Provider value={{
      user,
      session,
      player,
      isAuthenticated: !!session && !!player,
      isLoading,
      refreshPlayer,
    }}>
      {children}
    </PlayerAuthContext.Provider>
  );
}

export function usePlayerAuth() {
  const context = useContext(PlayerAuthContext);
  if (context === undefined) {
    throw new Error('usePlayerAuth must be used within a PlayerAuthProvider');
  }
  return context;
}
