import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface Club {
  id: string;
  user_id: string;
  name: string;
  email: string;
  phone?: string;
  show_email?: boolean | null;
  show_phone?: boolean | null;
  address?: string;
  city?: string;
  region?: string;
  logo_url?: string;
  created_at: string;
  updated_at: string;
  registration_status?: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  club: Club | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ error: string | null }>;
  register: (email: string, password: string, clubName: string) => Promise<{ error: string | null }>;
  logout: () => Promise<void>;
  refreshClub: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [club, setClub] = useState<Club | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchClub = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from('clubs')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (data && !error) {
      setClub(data as Club);
    } else {
      setClub(null);
    }
  }, []);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Defer Supabase calls with setTimeout
        if (session?.user) {
          setTimeout(() => {
            fetchClub(session.user.id);
          }, 0);
        } else {
          setClub(null);
        }
        
        setIsLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchClub(session.user.id);
      }
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [fetchClub]);

  const login = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (error) {
      return { error: error.message };
    }
    return { error: null };
  }, []);

  const register = useCallback(async (email: string, password: string, clubName: string) => {
    const redirectUrl = `${window.location.origin}/club/dashboard`;
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl
      }
    });
    
    if (error) {
      return { error: error.message };
    }
    
    // Create the club profile
    if (data.user) {
      const { error: clubError } = await supabase
        .from('clubs')
        .insert({
          user_id: data.user.id,
          name: clubName,
          email: email,
        });
      
      if (clubError) {
        return { error: clubError.message };
      }
      
      // Fetch the club
      await fetchClub(data.user.id);
    }
    
    return { error: null };
  }, [fetchClub]);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setClub(null);
  }, []);

  const refreshClub = useCallback(async () => {
    if (user) {
      await fetchClub(user.id);
    }
  }, [user, fetchClub]);

  return (
    <AuthContext.Provider value={{
      user,
      session,
      club,
      isAuthenticated: !!session && !!club && (club as any).registration_status !== 'pending' && (club as any).registration_status !== 'rejected',
      isLoading,
      login,
      register,
      logout,
      refreshClub,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}