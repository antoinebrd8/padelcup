import { useState, useEffect, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Trophy } from 'lucide-react';
import { TournamentTeam, DrawResult, GeneratedMatch, GroupResult } from '@/types/tournament';
import { cn } from '@/lib/utils';
import { calculateFftGroupStandingsExplained } from '@/lib/standingExplanations';
import { Database } from '@/integrations/supabase/types';
import { GAME_FORMAT_CONFIG } from '@/lib/gameFormatConfig';

type GameFormat = Database['public']['Enums']['game_format'];


// Game format descriptions
const GAME_FORMAT_INFO: Record<GameFormat, { label: string; description: string }> = {
  'A1': { label: 'A1', description: '3 sets à 6 jeux' },
  'A2': { label: 'A2', description: '3 sets à 6 jeux + PD' },
  'B1': { label: 'B1', description: '2 sets + super TB' },
  'B2': { label: 'B2', description: '2 sets + super TB + PD' },
  'C1': { label: 'C1', description: '2 sets à 4 jeux + super TB' },
  'C2': { label: 'C2', description: '2 sets à 4 jeux + super TB + PD' },
  'D1': { label: 'D1', description: '1 set à 9 jeux' },
  'D2': { label: 'D2', description: '1 set à 9 jeux + PD' },
  'E': { label: 'E', description: '1 super TB à 10 pts' },
  'F': { label: 'F', description: '1 set à 4 jeux + PD' },
};

// Parse scores comparing both players to determine sets won
const parseScoresForStats = (scoreA: string, scoreB: string, gameFormat: GameFormat): {
  setsA: number; setsB: number;
  gamesA: number; gamesB: number
} => {
  // Handle "/" format (new format: "6/4/10")
  const partsA = scoreA ? scoreA.split('/').map(s => parseInt(s) || 0) : [];
  const partsB = scoreB ? scoreB.split('/').map(s => parseInt(s) || 0) : [];
  
  let setsA = 0, setsB = 0, gamesA = 0, gamesB = 0;
  const maxLen = Math.max(partsA.length, partsB.length);
  
  const cfg = GAME_FORMAT_CONFIG[gameFormat];

  const maxSetsToCount = (() => {
    // Format E (1 super TB) -> no sets counted for standings
    if (gameFormat === 'E') return 0;
    // Two-set formats with deciding super TB -> only count first 2 sets
    if (cfg.sets === 2 && cfg.hasDecidingSuperTB) return 2;
    // Otherwise count the number of normal sets for the format
    return cfg.sets;
  })();

  for (let i = 0; i < Math.min(maxLen, maxSetsToCount); i++) {
    const a = partsA[i] || 0;
    const b = partsB[i] || 0;

    gamesA += a;
    gamesB += b;

    if (a > b) setsA++;
    else if (b > a) setsB++;
  }
  
  return { setsA, setsB, gamesA, gamesB };
};

// Format score for display (e.g., "6/4/10" -> "6-4 | 4-6 | 10-7")
const formatScoreForDisplay = (scoreA: string, scoreB: string): { displayA: string; displayB: string } => {
  if (!scoreA && !scoreB) return { displayA: '-', displayB: '-' };
  
  const partsA = scoreA ? scoreA.split('/').map(s => parseInt(s) || 0) : [];
  const partsB = scoreB ? scoreB.split('/').map(s => parseInt(s) || 0) : [];
  const maxLen = Math.max(partsA.length, partsB.length);
  
  const setsDisplay: string[] = [];
  for (let i = 0; i < maxLen; i++) {
    const a = partsA[i] || 0;
    const b = partsB[i] || 0;
    if (a > 0 || b > 0) {
      setsDisplay.push(`${a}-${b}`);
    }
  }
  
  return {
    displayA: setsDisplay.join(' ') || '-',
    displayB: setsDisplay.map(s => {
      const [a, b] = s.split('-');
      return `${b}-${a}`;
    }).join(' ') || '-'
  };
};

// Calculate group standings
const calculateGroupStandings = (
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  _gameFormat: GameFormat
) => {
  return calculateFftGroupStandingsExplained(groupTeamIds, teams, matches);
};

interface TournamentPublicDisplayProps {
  tournament: {
    id: string;
    title: string;
    format: string;
    game_format?: GameFormat | null;
    qualifiers_per_group?: number | null;
    start_date?: string;
    end_date?: string;
    location?: string;
  };
  teams: TournamentTeam[];
  knockoutDraw?: DrawResult;
  groupDraw?: GroupResult;
  roundRobinMatches?: GeneratedMatch[];
  clubName?: string;
}

// Display-only match card (no input)
const DisplayMatchCard = ({
  match,
  teams,
  isLarge = false
}: {
  match: GeneratedMatch;
  teams: TournamentTeam[];
  isLarge?: boolean;
}) => {
  const teamA = match.team_a_id ? teams.find(t => t.id === match.team_a_id) : null;
  const teamB = match.team_b_id ? teams.find(t => t.id === match.team_b_id) : null;

  if (match.is_bye) return null;

  const isCompleted = !!match.winner_id;
  const isWinnerA = match.winner_id === match.team_a_id;
  const isWinnerB = match.winner_id === match.team_b_id;
  const isInProgress = !isCompleted && teamA && teamB;

  // Format scores for display
  const { displayA, displayB } = formatScoreForDisplay(match.score_a || '', match.score_b || '');

  return (
    <Card className={cn(
      "transition-all",
      isInProgress && "ring-2 ring-primary animate-pulse",
      isCompleted && "opacity-90"
    )}>
      <CardContent className={cn("p-3", isLarge && "p-4")}>
        <div className="flex items-center justify-between mb-2">
          <Badge variant={isCompleted ? "secondary" : isInProgress ? "default" : "outline"} className={cn("text-xs", isLarge && "text-sm")}>
            {isCompleted ? 'Terminé' : isInProgress ? 'En cours' : 'À venir'}
          </Badge>
          <span className={cn("text-xs text-muted-foreground", isLarge && "text-sm")}>{match.round_name}</span>
        </div>

        <div className="space-y-2">
          {/* Team A */}
          <div className={cn(
            "flex items-center gap-3 p-2 rounded-lg",
            isWinnerA && "bg-primary/20 border-2 border-primary",
            !isCompleted && "bg-muted/50",
            isLarge && "p-3"
          )}>
            <div className="flex-1 flex items-center gap-2 min-w-0">
              {teamA?.seed_rank && (
                <Badge variant="outline" className={cn("shrink-0", isLarge ? "h-7 w-7 text-sm" : "h-5 w-5 text-xs")}>
                  {teamA.seed_rank}
                </Badge>
              )}
              <span className={cn(
                "font-semibold truncate",
                isWinnerA && "text-primary",
                isLarge ? "text-base" : "text-sm"
              )}>
                {teamA?.name || 'TBD'}
              </span>
              {isWinnerA && <Trophy className={cn("shrink-0 text-primary", isLarge ? "h-5 w-5" : "h-4 w-4")} />}
            </div>
            <span className={cn("font-mono font-bold whitespace-nowrap", isLarge ? "text-base" : "text-sm")}>
              {displayA}
            </span>
          </div>

          {/* Team B */}
          <div className={cn(
            "flex items-center gap-3 p-2 rounded-lg",
            isWinnerB && "bg-primary/20 border-2 border-primary",
            !isCompleted && "bg-muted/50",
            isLarge && "p-3"
          )}>
            <div className="flex-1 flex items-center gap-2 min-w-0">
              {teamB?.seed_rank && (
                <Badge variant="outline" className={cn("shrink-0", isLarge ? "h-7 w-7 text-sm" : "h-5 w-5 text-xs")}>
                  {teamB.seed_rank}
                </Badge>
              )}
              <span className={cn(
                "font-semibold truncate",
                isWinnerB && "text-primary",
                isLarge ? "text-base" : "text-sm"
              )}>
                {teamB?.name || 'TBD'}
              </span>
              {isWinnerB && <Trophy className={cn("shrink-0 text-primary", isLarge ? "h-5 w-5" : "h-4 w-4")} />}
            </div>
            <span className={cn("font-mono font-bold whitespace-nowrap", isLarge ? "text-base" : "text-sm")}>
              {displayB}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Large group standings table for TV
const LargeGroupStandingsTable = ({
  groupName,
  standings,
  qualifiersCount
}: {
  groupName: string;
  standings: ReturnType<typeof calculateGroupStandings>;
  qualifiersCount: number;
}) => {
  return (
    <div className="rounded-xl border-2 bg-card overflow-hidden">
      <div className="p-4 border-b bg-muted/50">
        <h3 className="font-bold text-xl">{groupName}</h3>
      </div>
      <table className="w-full">
        <thead>
          <tr className="border-b bg-muted/30 text-sm">
            <th className="text-left p-3 font-semibold">#</th>
            <th className="text-left p-3 font-semibold">Équipe</th>
            <th className="text-center p-3 font-semibold">J</th>
            <th className="text-center p-3 font-semibold">V</th>
            <th className="text-center p-3 font-semibold">D</th>
            <th className="text-center p-3 font-semibold">Sets</th>
            <th className="text-center p-3 font-semibold">Jeux</th>
            <th className="text-center p-3 font-semibold">Pts</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {standings.map((entry, index) => {
            const isQualified = index < qualifiersCount;
            return (
              <tr 
                key={entry.team.id}
                className={cn(
                  "transition-colors text-base",
                  isQualified && "bg-primary/10"
                )}
              >
                <td className="p-3">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center font-bold",
                    isQualified && "bg-primary text-primary-foreground",
                    !isQualified && "bg-muted text-muted-foreground"
                  )}>
                    {index + 1}
                  </div>
                </td>
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    {entry.team.seed_rank && (
                      <Badge variant="outline" className="text-sm">
                        TdS {entry.team.seed_rank}
                      </Badge>
                    )}
                    <span className="font-semibold text-base">{entry.team.name}</span>
                  </div>
                  {entry.tie_break_explanation && (
                    <div className="text-xs text-muted-foreground mt-1">{entry.tie_break_explanation}</div>
                  )}
                </td>
                <td className="p-3 text-center font-mono text-base">{entry.played}</td>
                <td className="p-3 text-center font-mono text-base text-green-600 font-bold">{entry.wins}</td>
                <td className="p-3 text-center font-mono text-base text-red-600">{entry.losses}</td>
                <td className="p-3 text-center font-mono">
                  {entry.setsWon}-{entry.setsLost}
                  <span className={cn(
                    "ml-1 text-sm",
                    entry.setsDiff > 0 && "text-green-600",
                    entry.setsDiff < 0 && "text-red-600"
                  )}>
                    ({entry.setsDiff > 0 ? '+' : ''}{entry.setsDiff})
                  </span>
                </td>
                <td className="p-3 text-center font-mono">
                  {entry.gamesWon}-{entry.gamesLost}
                  <span className={cn(
                    "ml-1 text-sm",
                    entry.gamesDiff > 0 && "text-green-600",
                    entry.gamesDiff < 0 && "text-red-600"
                  )}>
                    ({entry.gamesDiff > 0 ? '+' : ''}{entry.gamesDiff})
                  </span>
                </td>
                <td className="p-3 text-center">
                  <span className="font-bold text-xl">{entry.points}</span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

// Groups display view
const GroupsDisplayView = ({
  groupDraw,
  teams,
  qualifiersPerGroup,
  gameFormat
}: {
  groupDraw: GroupResult;
  teams: TournamentTeam[];
  qualifiersPerGroup: number;
  gameFormat: GameFormat;
}) => {
  // TV mode: show everything on one screen (standings + match order per group)
  // No tabs to keep it readable from far away.

  const groupsWithStandings = useMemo(() => {
    return groupDraw.groups.map(group => {
      const groupMatches = groupDraw.matches.filter(m => 
        group.team_ids.includes(m.team_a_id || '') && 
        group.team_ids.includes(m.team_b_id || '')
      );
      
      const standings = calculateGroupStandings(group.team_ids, teams, groupMatches, gameFormat);
      
      return {
        ...group,
        matches: groupMatches,
        standings,
        completedMatches: groupMatches.filter(m => m.winner_id).length,
        totalMatches: groupMatches.length
      };
    });
  }, [groupDraw, teams]);

  const teamName = (id?: string | null) => {
    if (!id) return '—';
    return teams.find(t => t.id === id)?.name ?? '—';
  };

  const teamNum = (group: { team_ids: string[] }, id?: string | null) => {
    if (!id) return '—';
    const idx = group.team_ids.findIndex(tid => tid === id);
    return idx >= 0 ? String(idx + 1) : '—';
  };


  const scoreText = (m: GeneratedMatch) => {
    if (m.is_bye) return 'BYE';
    if (!m.score_a && !m.score_b) return '';
    return `${m.score_a ?? ''} - ${m.score_b ?? ''}`.trim();
  };

  return (
    <div className="w-full">
      <div className={cn("grid gap-3", groupsWithStandings.length <= 1 ? "grid-cols-1" : groupsWithStandings.length === 2 ? "grid-cols-2" : groupsWithStandings.length === 4 ? "grid-cols-2" : "grid-cols-3")}>
        {groupsWithStandings.map((group, gi) => {
          const teamsCount = group.team_ids.length;
          const remaining = group.totalMatches - group.completedMatches;

          const headerIsRed = true;

          return (
            <div
              key={group.order}
              className="rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-[0_14px_40px_rgba(15,23,42,0.14)]"
            >
              {/* Pool header band */}
              <div className={cn(
                "px-4 py-2",
                headerIsRed ? "bg-gradient-to-r from-red-700 to-red-600 text-white" : "bg-slate-100 text-slate-900"
              )}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-lg font-extrabold tracking-wide uppercase">
                      {group.name.replace('Poule', 'POULE')}
                    </div>
                    <div className={cn(
                      "font-semibold",
                      headerIsRed ? "text-white/90" : "text-slate-700"
                    )}>
                      {teamsCount} équipes — {remaining} match{remaining > 1 ? 's' : ''} restant{remaining > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      "text-sm font-semibold",
                      headerIsRed ? "text-white/90" : "text-slate-700"
                    )}>Matchs joués</div>
                    <div className="text-lg font-extrabold">
                      {group.completedMatches} / {group.totalMatches}
                    </div>
                  </div>
                </div>
              </div>

              {/* Standings */}
              <div className="bg-[#F5F7FA] text-slate-900">
                <div className="px-4 py-2">
                  <div className="grid grid-cols-12 text-xs font-bold text-slate-500 uppercase tracking-wide">
                    <div className="col-span-1">#</div>
                    <div className="col-span-8">Équipe</div>
                    <div className="col-span-1 text-center">V/D</div>
                    <div className="col-span-1 text-center">Sets</div>
                    <div className="col-span-1 text-right">Pts</div>
                  </div>
                </div>

                <div className="divide-y divide-slate-200">
                  {group.standings.map((row, idx) => {
                    const isQualified = idx < qualifiersPerGroup;
                    const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : '•';

                    return (
                      <div
                        key={row.team.id}
                        className={cn(
                          "px-4 py-3 grid grid-cols-12 items-center",
                          isQualified ? "bg-emerald-50" : "bg-transparent"
                        )}
                      >
                        <div className="col-span-1 font-extrabold">
                          <span className="inline-flex items-center justify-center w-7">
                            {medal}
                          </span>
                        </div>
                        <div className="col-span-8 min-w-0">
                          <div className="font-extrabold truncate">
                            {row.team.name}
                          </div>
                        </div>
                        <div className="col-span-1 text-center font-bold">
                          <span className="text-emerald-700">{row.wins}</span>
                          <span className="text-slate-400">/</span>
                          <span className="text-red-700">{row.losses}</span>
                        </div>
                        <div className="col-span-1 text-center font-bold">
                          {row.setsDiff > 0 ? `+${row.setsDiff}` : row.setsDiff}
                        </div>
                        <div className="col-span-1 text-right font-extrabold text-base">
                          {row.points}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Upcoming matches */}
                <div className="mt-1 border-t border-slate-200">
                  <div className="px-4 py-3 bg-slate-100">
                    <div className="text-sm font-extrabold tracking-wide uppercase text-slate-700">
                      Prochains matchs
                    </div>
                  </div>

                  <div className="px-4 py-2 space-y-2">
                    {group.matches
                      .slice()
                      .sort((a, b) => (a.match_order ?? 0) - (b.match_order ?? 0))
                      .filter(m => !m.winner_id && !m.is_bye)
                      .slice(0, 3)
                      .map((m, idx) => {
                        const done = !!m.winner_id;
                        return (
                          <div
                            key={m.id || `${group.name}-${idx}`}
                            className={cn(
                              "rounded-xl border border-slate-200 px-3 py-2",
                              done ? "bg-emerald-50" : "bg-white"
                            )}
                          >
                            <div className="flex items-center justify-between gap-3">
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-slate-500">
                                  Match {idx + 1} — {group.name}
                                </div>
                                <div className="font-extrabold truncate">
                                  {teamNum(group, m.team_a_id)} <span className="text-slate-400 font-bold">vs</span> {teamNum(group, m.team_b_id)}
                                </div>
                              </div>
                              <div className="shrink-0 font-mono font-bold text-slate-700">
                                {done ? (scoreText(m) ? scoreText(m) : '✓') : ''}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Knockout bracket display
const KnockoutDisplayBracket = ({
  drawResult,
  teams
}: {
  drawResult: DrawResult;
  teams: TournamentTeam[];
}) => {
  const roundsWithMatches = useMemo(() => {
    const grouped: Record<number, GeneratedMatch[]> = {};
    drawResult.matches.forEach(match => {
      if (!grouped[match.round_order]) {
        grouped[match.round_order] = [];
      }
      grouped[match.round_order].push(match);
    });
    return Object.entries(grouped)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([, matches]) => matches);
  }, [drawResult.matches]);

  return (
    <div className="flex gap-8 overflow-x-auto p-4">
      {roundsWithMatches.map((matches, roundIndex) => (
        <div key={roundIndex} className="flex flex-col min-w-[320px]">
          <div className="text-center font-bold text-xl mb-6">
            {matches[0]?.round_name}
          </div>
          <div 
            className="flex flex-col gap-4 justify-around flex-1"
            style={{
              paddingTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 24}px` : 0,
              gap: `${Math.pow(2, roundIndex + 1) * 12}px`
            }}
          >
            {matches.filter(m => !m.is_bye).map((match, idx) => (
              <DisplayMatchCard
                key={`${match.round_order}-${match.match_order}`}
                match={match}
                teams={teams}
                isLarge
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export const TournamentPublicDisplay = ({
  tournament,
  teams,
  knockoutDraw,
  groupDraw,
  roundRobinMatches,
  clubName
}: TournamentPublicDisplayProps) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const gameFormat: GameFormat = tournament.game_format || 'B1';
  const qualifiersPerGroup = tournament.qualifiers_per_group || 2;
  const formatInfo = GAME_FORMAT_INFO[gameFormat];

  // Get all matches for stats
  const allMatches = knockoutDraw?.matches || groupDraw?.matches || roundRobinMatches || [];
  const completedMatches = allMatches.filter(m => m.winner_id).length;
  const remainingMatches = allMatches.filter(m => !m.winner_id && !m.is_bye).length;

  return (
    <div className="h-screen w-full bg-gradient-to-b from-slate-50 to-slate-100 text-slate-900 overflow-hidden">
      {/* TV frame */}
      <div className="h-full w-full p-4">
        <div className="mx-auto max-w-[1800px] h-[calc(100vh-48px)] rounded-2xl border border-slate-200 bg-white shadow-[0_20px_60px_rgba(15,23,42,0.18)] overflow-hidden">
          {/* Header */}
          <div className="px-8 py-6 border-b border-slate-200 bg-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-5 min-w-0">
                {/* Logo placeholder */}
                <div className="h-14 w-14 rounded-full bg-slate-100 ring-1 ring-slate-200 flex items-center justify-center shrink-0">
                  <Trophy className="h-7 w-7 text-slate-700" />
                </div>

                <div className="min-w-0">
                  <div className="flex items-baseline gap-3 min-w-0">
                    <h1 className="text-3xl font-extrabold tracking-tight truncate">
                      {tournament.title}
                    </h1>
                    {clubName ? (
                      <span className="text-slate-600 font-semibold truncate">
                        — {clubName}
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-2 flex items-center gap-3 text-slate-600">
                    <span className="inline-flex items-center rounded-md bg-slate-100 px-3 py-1 text-sm font-semibold text-slate-700">
                      Format : {formatInfo.label} — {formatInfo.description}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-8 shrink-0">
                <div className="text-right">
                  <div className="text-4xl font-mono font-bold">
                    {currentTime.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                <div className="h-12 w-px bg-slate-200" />
                <div className="text-right">
                  <div className="text-slate-600 text-sm font-semibold">Matchs joués :</div>
                  <div className="text-lg font-extrabold">
                    {completedMatches} / {completedMatches + remainingMatches}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="h-[calc(100%-96px-1px)] overflow-hidden">
            <div className="h-full overflow-hidden p-3">
              {/* Poules */}
              {groupDraw && (
                <GroupsDisplayView
                  groupDraw={groupDraw}
                  teams={teams}
                  qualifiersPerGroup={qualifiersPerGroup}
                  gameFormat={tournament.game_format as GameFormat}
                />
              )}

              {/* Tableau final (si présent) */}
              {knockoutDraw && (
                <div className="mt-8">
                  <div className="mb-4 flex items-center justify-between">
                    <div className="text-xl font-extrabold tracking-tight">Tableau final</div>
                    <div className="text-slate-500 text-sm">Mise à jour automatique</div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white">
                    <KnockoutDisplayBracket drawResult={knockoutDraw} teams={teams} />
                  </div>
                </div>
              )}

              {/* Championnat */}
              {roundRobinMatches && (
                <div className="mt-6 grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {roundRobinMatches.map((match, idx) => (
                    <DisplayMatchCard key={idx} match={match} teams={teams} isLarge />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
