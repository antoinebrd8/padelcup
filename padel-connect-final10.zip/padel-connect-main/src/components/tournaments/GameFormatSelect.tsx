import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { HelpCircle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { GAME_FORMAT_CONFIG, type GameFormat } from '@/lib/gameFormatConfig';

const ORDER: GameFormat[] = ['A1','A2','B1','B2','C1','C2','D1','D2','E','F','G'];

export const gameFormatOptions: { value: GameFormat; label: string; description: string }[] =
  ORDER.map((v) => ({
    value: v,
    label: GAME_FORMAT_CONFIG[v].label,
    description: GAME_FORMAT_CONFIG[v].description,
  }));

interface GameFormatSelectProps {
  value: GameFormat;
  onChange: (value: GameFormat) => void;
  disabled?: boolean;
}

export function GameFormatSelect({ value, onChange, disabled }: GameFormatSelectProps) {
  const selectedFormat = gameFormatOptions.find(f => f.value === value);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Label htmlFor="game_format">Format de jeu</Label>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
            </TooltipTrigger>
            <TooltipContent side="right" className="max-w-xs">
              <p className="text-sm">
                PD = Point décisif (no-ad)<br/>
                TB = Tie-break<br/>
                Super TB = Super tie-break à 10 points<br/>
                Format G = meilleur de 3 super TB (2 gagnants)
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <Select
        value={value}
        onValueChange={(v) => onChange(v as GameFormat)}
        disabled={disabled}
      >
        <SelectTrigger id="game_format">
          <SelectValue placeholder="Sélectionner un format" />
        </SelectTrigger>
        <SelectContent>
          {gameFormatOptions.map((format) => (
            <SelectItem key={format.value} value={format.value}>
              <div className="flex flex-col">
                <span>{format.label}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {selectedFormat && (
        <p className="text-xs text-muted-foreground">{selectedFormat.description}</p>
      )}
    </div>
  );
}
