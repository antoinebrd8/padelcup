import { Tournament } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, ExternalLink, X } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Link } from 'react-router-dom';
import { useMemo, useState, useCallback } from 'react';
import Map, { Marker, Popup, NavigationControl } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';

interface TournamentMapProps {
  tournaments: Tournament[];
  selectedTournamentId?: string | null;
  onTournamentSelect?: (id: string | null) => void;
  userLocation?: { lat: number; lng: number } | null;
}

// Custom tennis/padel ball marker component
const TennisBallMarker = ({ isSelected }: { isSelected: boolean }) => (
  <div 
    className={`
      cursor-pointer transition-all duration-200 transform
      ${isSelected ? 'scale-150' : 'hover:scale-125'}
    `}
    style={{
      filter: isSelected ? 'drop-shadow(0 0 8px rgba(234, 179, 8, 0.8))' : 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))'
    }}
  >
    <svg 
      width="28" 
      height="28" 
      viewBox="0 0 100 100"
    >
      {/* Ball base - yellow */}
      <circle 
        cx="50" 
        cy="50" 
        r="45" 
        fill="#DFFF00"
        stroke="#C5E600"
        strokeWidth="2"
      />
      
      {/* Gradient overlay for 3D effect */}
      <defs>
        <radialGradient id={`ballGradient${isSelected ? 'Selected' : ''}`} cx="35%" cy="35%" r="60%">
          <stop offset="0%" stopColor="#F0FF4D" />
          <stop offset="50%" stopColor="#DFFF00" />
          <stop offset="100%" stopColor="#B8D900" />
        </radialGradient>
      </defs>
      <circle 
        cx="50" 
        cy="50" 
        r="44" 
        fill={`url(#ballGradient${isSelected ? 'Selected' : ''})`}
      />
      
      {/* Tennis ball curved seam - left */}
      <path
        d="M 25 20 Q 15 50 25 80"
        fill="none"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
      />
      
      {/* Tennis ball curved seam - right */}
      <path
        d="M 75 20 Q 85 50 75 80"
        fill="none"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
      />
      
      {/* Highlight */}
      <ellipse
        cx="35"
        cy="35"
        rx="12"
        ry="8"
        fill="white"
        opacity="0.4"
        transform="rotate(-30 35 35)"
      />
      
      {/* Selection ring */}
      {isSelected && (
        <circle
          cx="50"
          cy="50"
          r="48"
          fill="none"
          stroke="#ea580c"
          strokeWidth="3"
          className="animate-pulse"
        />
      )}
    </svg>
  </div>
);

export function TournamentMap({ 
  tournaments, 
  selectedTournamentId, 
  onTournamentSelect,
  userLocation 
}: TournamentMapProps) {
  const [popupInfo, setPopupInfo] = useState<Tournament | null>(null);
  
  const validTournaments = useMemo(() => 
    tournaments.filter(t => t.latitude && t.longitude),
    [tournaments]
  );

  // Calculate initial view state based on tournaments
  const initialViewState = useMemo(() => {
    if (validTournaments.length === 0) {
      return {
        longitude: 1.888334,
        latitude: 46.603354,
        zoom: 5
      };
    }

    if (validTournaments.length === 1) {
      return {
        longitude: validTournaments[0].longitude!,
        latitude: validTournaments[0].latitude!,
        zoom: 12
      };
    }

    // Calculate bounds
    const lngs = validTournaments.map(t => t.longitude!);
    const lats = validTournaments.map(t => t.latitude!);
    
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    
    const centerLng = (minLng + maxLng) / 2;
    const centerLat = (minLat + maxLat) / 2;
    
    // Calculate zoom based on spread
    const lngSpread = maxLng - minLng;
    const latSpread = maxLat - minLat;
    const maxSpread = Math.max(lngSpread, latSpread);
    
    let zoom = 5;
    if (maxSpread < 0.5) zoom = 11;
    else if (maxSpread < 1) zoom = 10;
    else if (maxSpread < 2) zoom = 8;
    else if (maxSpread < 5) zoom = 6;
    
    return {
      longitude: centerLng,
      latitude: centerLat,
      zoom
    };
  }, [validTournaments]);

  const handleMarkerClick = useCallback((tournament: Tournament) => {
    setPopupInfo(tournament);
    onTournamentSelect?.(tournament.id);
  }, [onTournamentSelect]);

  const handleClosePopup = useCallback(() => {
    setPopupInfo(null);
    onTournamentSelect?.(null);
  }, [onTournamentSelect]);

  return (
    <div className="relative h-full w-full rounded-xl overflow-hidden border border-border shadow-lg">
      <Map
        initialViewState={initialViewState}
        style={{ width: '100%', height: '100%' }}
        mapStyle="https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json"
      >
        <NavigationControl position="top-right" />
        
        {/* User location marker */}
        {userLocation && (
          <Marker
            longitude={userLocation.lng}
            latitude={userLocation.lat}
            anchor="center"
          >
            <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse" />
          </Marker>
        )}
        
        {/* Tournament markers */}
        {validTournaments.map((tournament) => (
          <Marker
            key={tournament.id}
            longitude={tournament.longitude!}
            latitude={tournament.latitude!}
            anchor="center"
            onClick={(e) => {
              e.originalEvent.stopPropagation();
              handleMarkerClick(tournament);
            }}
          >
            <TennisBallMarker isSelected={selectedTournamentId === tournament.id} />
          </Marker>
        ))}
        
        {/* Popup for selected tournament */}
        {popupInfo && popupInfo.latitude && popupInfo.longitude && (
          <Popup
            longitude={popupInfo.longitude}
            latitude={popupInfo.latitude}
            anchor="bottom"
            onClose={handleClosePopup}
            closeButton={false}
            className="tournament-popup"
            maxWidth="320px"
          >
            <Card className="border-0 shadow-none bg-transparent">
              <CardContent className="p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {popupInfo.category_code}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {popupInfo.gender}
                      </Badge>
                    </div>
                    <h4 className="font-semibold text-sm truncate mb-1">
                      {popupInfo.title}
                    </h4>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(popupInfo.start_date), 'd MMM', { locale: fr })}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {popupInfo.city}
                      </span>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6 shrink-0"
                    onClick={handleClosePopup}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <Button size="sm" className="w-full mt-3" asChild>
                  <Link to={`/tournaments/${popupInfo.id}`}>
                    <ExternalLink className="h-3 w-3 mr-1" />
                    Voir le tournoi
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </Popup>
        )}
      </Map>
      
      {/* Tournament count legend */}
      <div className="absolute bottom-4 left-4 bg-background/95 backdrop-blur-sm rounded-lg p-3 shadow-md border border-border z-10">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-lime-500 border-2 border-lime-600"></div>
          <p className="text-xs font-medium text-muted-foreground">
            {validTournaments.length} tournoi{validTournaments.length !== 1 ? 's' : ''} sur la carte
          </p>
        </div>
      </div>
    </div>
  );
}
