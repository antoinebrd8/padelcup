import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Maximize2, 
  Minimize2, 
  Trophy, 
  X, 
  Check,
  Users,
  LayoutGrid
} from 'lucide-react';
import { TournamentTeam, DrawResult, GeneratedMatch, GroupResult } from '@/types/tournament';
import { cn } from '@/lib/utils';
import { calculateFftGroupStandingsExplained } from '@/lib/standingExplanations';
import { Database } from '@/integrations/supabase/types';

type GameFormat = Database['public']['Enums']['game_format'];

// Game format configurations - defines how many sets and scoring rules
const GAME_FORMAT_CONFIG: Record<GameFormat, { 
  label: string; 
  sets: number; 
  hasSuperTiebreak: boolean;
  description: string;
}> = {
  'A1': { label: 'A1', sets: 3, hasSuperTiebreak: false, description: '3 sets à 6 jeux' },
  'A2': { label: 'A2', sets: 3, hasSuperTiebreak: false, description: '3 sets à 6 jeux + PD' },
  'B1': { label: 'B1', sets: 2, hasSuperTiebreak: true, description: '2 sets + super TB' },
  'B2': { label: 'B2', sets: 2, hasSuperTiebreak: true, description: '2 sets + super TB + PD' },
  'C1': { label: 'C1', sets: 2, hasSuperTiebreak: true, description: '2 sets à 4 jeux + super TB' },
  'C2': { label: 'C2', sets: 2, hasSuperTiebreak: true, description: '2 sets à 4 jeux + super TB + PD' },
  'D1': { label: 'D1', sets: 1, hasSuperTiebreak: false, description: '1 set à 9 jeux' },
  'D2': { label: 'D2', sets: 1, hasSuperTiebreak: false, description: '1 set à 9 jeux + PD' },
  'E': { label: 'E', sets: 1, hasSuperTiebreak: false, description: '1 super TB à 10 points' },
  'F': { label: 'F', sets: 1, hasSuperTiebreak: false, description: '1 set à 4 jeux + PD' },
};

interface TournamentModeProps {
  tournament: {
    id: string;
    title: string;
    format: string;
    game_format?: GameFormat | null;
    qualifiers_per_group?: number | null;
  };
  teams: TournamentTeam[];
  knockoutDraw?: DrawResult;
  groupDraw?: GroupResult;
  roundRobinMatches?: GeneratedMatch[];
  onScoreUpdate: (matchId: string, scoreA: string, scoreB: string, winnerId: string) => void;
  onClose: () => void;
}

// Parse score string to calculate sets/games won
const parseScore = (score: string): { sets: number; games: number } => {
  if (!score) return { sets: 0, games: 0 };
  
  const parts = score.trim().split(/\s+/);
  let setsWon = 0;
  let gamesWon = 0;
  
  parts.forEach(part => {
    const match = part.match(/^(\d+)-(\d+)$/);
    if (match) {
      const won = parseInt(match[1]);
      const lost = parseInt(match[2]);
      gamesWon += won;
      if (won > lost) setsWon++;
    }
  });
  
  return { sets: setsWon, games: gamesWon };
};

// Calculate detailed standings for a group (FFT P25 -> P500)
const calculateGroupStandings = (
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[]
) => {
  return calculateFftGroupStandingsExplained(groupTeamIds, teams, matches);
};

// Helper to parse score string to array of set scores
const parseScoreToSets = (score: string): number[] => {
  if (!score) return [];
  return score.trim().split(/\s+/).map(s => {
    const match = s.match(/^(\d+)/);
    return match ? parseInt(match[1]) : 0;
  });
};

// Helper to convert set arrays to score strings
const setsToScoreString = (setsA: number[], setsB: number[]): { scoreA: string; scoreB: string } => {
  const parts: string[] = [];
  const partsB: string[] = [];
  for (let i = 0; i < Math.max(setsA.length, setsB.length); i++) {
    if (setsA[i] !== undefined && setsB[i] !== undefined) {
      parts.push(`${setsA[i]}-${setsB[i]}`);
    }
  }
  return { scoreA: parts.join(' '), scoreB: parts.join(' ').split(' ').map(p => p.split('-').reverse().join('-')).join(' ') };
};

// Calculate winner from set scores
const calculateWinner = (setsA: number[], setsB: number[], gameFormat: GameFormat): 'A' | 'B' | null => {
  const config = GAME_FORMAT_CONFIG[gameFormat];
  let setsWonA = 0;
  let setsWonB = 0;
  
  for (let i = 0; i < setsA.length; i++) {
    if (setsA[i] > setsB[i]) setsWonA++;
    else if (setsB[i] > setsA[i]) setsWonB++;
  }
  
  // For formats with super tiebreak (B1, B2, C1, C2), need 1 set + tiebreak or 2 sets
  if (config.hasSuperTiebreak) {
    if (setsWonA >= 2 || (setsWonA === 1 && setsWonB === 1 && setsA.length === 3 && setsA[2] > setsB[2])) return 'A';
    if (setsWonB >= 2 || (setsWonB === 1 && setsWonA === 1 && setsB.length === 3 && setsB[2] > setsA[2])) return 'B';
  } else {
    // For other formats
    const setsToWin = config.sets === 3 ? 2 : 1;
    if (setsWonA >= setsToWin) return 'A';
    if (setsWonB >= setsToWin) return 'B';
  }
  
  return null;
};

// Live match card with score input based on game format - auto-submit on winner detected
const LiveMatchCard = ({
  match,
  teams,
  gameFormat,
  onScoreSubmit,
  isCompact = false
}: {
  match: GeneratedMatch;
  teams: TournamentTeam[];
  gameFormat: GameFormat;
  onScoreSubmit: (matchId: string, scoreA: string, scoreB: string, winnerId: string) => void;
  isCompact?: boolean;
}) => {
  const config = GAME_FORMAT_CONFIG[gameFormat] || GAME_FORMAT_CONFIG['B1'];
  const maxSets = config.hasSuperTiebreak ? 3 : config.sets;
  
  // Initialize set scores from existing score
  const [setsA, setSetsA] = useState<number[]>(() => {
    if (match.score_a) {
      return match.score_a.split(' ').map(s => parseInt(s.split('-')[0]) || 0);
    }
    return Array(maxSets).fill(0);
  });
  
  const [setsB, setSetsB] = useState<number[]>(() => {
    if (match.score_b) {
      return match.score_b.split(' ').map(s => parseInt(s.split('-')[0]) || 0);
    }
    return Array(maxSets).fill(0);
  });
  
  // Track if we already submitted to prevent duplicate submissions
  const [hasSubmitted, setHasSubmitted] = useState(!!match.winner_id);
  const lastSubmittedRef = useRef<string | null>(null);

  const teamA = match.team_a_id ? teams.find(t => t.id === match.team_a_id) : null;
  const teamB = match.team_b_id ? teams.find(t => t.id === match.team_b_id) : null;

  // Helper to submit score
  const submitScore = useCallback((newSetsA: number[], newSetsB: number[]) => {
    const winner = calculateWinner(newSetsA, newSetsB, gameFormat);
    if (winner && match.id) {
      const winnerId = winner === 'A' ? teamA?.id : teamB?.id;
      if (winnerId) {
        const scorePartsA: string[] = [];
        const scorePartsB: string[] = [];
        for (let i = 0; i < maxSets; i++) {
          if (newSetsA[i] > 0 || newSetsB[i] > 0) {
            scorePartsA.push(`${newSetsA[i]}-${newSetsB[i]}`);
            scorePartsB.push(`${newSetsB[i]}-${newSetsA[i]}`);
          }
        }
        const scoreKey = `${scorePartsA.join(' ')}-${winnerId}`;
        if (lastSubmittedRef.current !== scoreKey) {
          lastSubmittedRef.current = scoreKey;
          setHasSubmitted(true);
          onScoreSubmit(match.id, scorePartsA.join(' '), scorePartsB.join(' '), winnerId);
        }
      }
    }
  }, [match.id, teamA?.id, teamB?.id, maxSets, gameFormat, onScoreSubmit]);

  // Auto-calculate winner based on scores
  const calculatedWinner = useMemo(() => calculateWinner(setsA, setsB, gameFormat), [setsA, setsB, gameFormat]);

  // Update local state when match scores change from props
  useEffect(() => {
    if (match.score_a) {
      setSetsA(match.score_a.split(' ').map(s => parseInt(s.split('-')[0]) || 0));
    }
    if (match.score_b) {
      setSetsB(match.score_b.split(' ').map(s => parseInt(s.split('-')[0]) || 0));
    }
    if (match.winner_id) {
      setHasSubmitted(true);
    } else {
      setHasSubmitted(false);
      lastSubmittedRef.current = null;
    }
  }, [match.score_a, match.score_b, match.winner_id]);

  const handleSetChange = (team: 'A' | 'B', setIndex: number, value: string) => {
    const numValue = parseInt(value) || 0;
    
    let newSetsA = [...setsA];
    let newSetsB = [...setsB];
    
    if (team === 'A') {
      newSetsA[setIndex] = numValue;
      setSetsA(newSetsA);
    } else {
      newSetsB[setIndex] = numValue;
      setSetsB(newSetsB);
    }
    
    // Immediately check and submit if winner detected
    submitScore(newSetsA, newSetsB);
  };

  // Skip bye matches
  if (match.is_bye) return null;

  const isCompleted = !!match.winner_id;
  const isWinnerA = match.winner_id === match.team_a_id;
  const isWinnerB = match.winner_id === match.team_b_id;

  // Count sets won for display
  const setsWonA = setsA.filter((s, i) => s > setsB[i]).length;
  const setsWonB = setsB.filter((s, i) => s > setsA[i]).length;

  // Don't show input if teams not ready
  if (!teamA || !teamB) {
    return (
      <Card className="border-2 border-dashed border-muted-foreground/30 bg-muted/20">
        <CardContent className={cn("p-4", isCompact && "p-3")}>
          <div className="flex items-center justify-between mb-3">
            <Badge variant="outline" className="text-xs">
              {match.round_name}
            </Badge>
          </div>
          <div className="text-center py-4 text-muted-foreground text-sm">
            En attente des équipes...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn(
      "transition-all duration-300 border-2",
      isCompleted && "border-green-500/50 bg-gradient-to-br from-green-50 to-green-100/50",
      !isCompleted && "border-amber-400/50 bg-gradient-to-br from-amber-50/50 to-orange-50/30"
    )}>
      <CardContent className={cn("p-4", isCompact && "p-3")}>
        {/* Match header */}
        <div className="flex items-center justify-between mb-3">
          <Badge 
            variant={isCompleted ? "default" : "outline"} 
            className={cn(
              "text-xs font-semibold",
              isCompleted && "bg-green-600"
            )}
          >
            {isCompleted ? '✓ Terminé' : '⏳ En cours'}
          </Badge>
          <span className="text-xs font-medium text-muted-foreground bg-white/80 px-2 py-1 rounded">
            {match.round_name}
          </span>
        </div>

        {/* Scoreboard style layout */}
        <div className="bg-white rounded-lg border-2 border-gray-200 overflow-hidden shadow-sm">
          {/* Header row with set numbers */}
          <div className={cn(
            "grid bg-gray-800 text-white text-xs font-bold",
            maxSets === 1 && "grid-cols-[1fr_64px_64px]",
            maxSets === 2 && "grid-cols-[1fr_48px_48px_64px]",
            maxSets === 3 && "grid-cols-[1fr_48px_48px_48px_64px]"
          )}>
            <div className="p-2">Équipe</div>
            {Array.from({ length: maxSets }).map((_, i) => (
              <div key={i} className="p-2 text-center border-l border-gray-600">
                {maxSets === 1 ? 'Score' : (i < 2 ? `S${i + 1}` : 'TB')}
              </div>
            ))}
            <div className="p-2 text-center border-l border-gray-600 bg-green-700">Sets</div>
          </div>

          {/* Team A row */}
          <div className={cn(
            "grid border-b-2 transition-colors",
            maxSets === 1 && "grid-cols-[1fr_64px_64px]",
            maxSets === 2 && "grid-cols-[1fr_48px_48px_64px]",
            maxSets === 3 && "grid-cols-[1fr_48px_48px_48px_64px]",
            isWinnerA && "bg-green-100",
            calculatedWinner === 'A' && !isCompleted && "bg-green-50"
          )}>
            <div className="p-2 flex items-center gap-2">
              {teamA?.seed_rank && (
                <Badge className="bg-primary text-primary-foreground h-5 w-5 p-0 justify-center text-xs font-bold shrink-0">
                  {teamA.seed_rank}
                </Badge>
              )}
              <span className={cn(
                "font-semibold text-sm truncate",
                (isWinnerA || calculatedWinner === 'A') && "text-green-700"
              )}>
                {teamA.name}
              </span>
              {isWinnerA && <Trophy className="h-4 w-4 text-green-600 shrink-0" />}
            </div>
            {Array.from({ length: maxSets }).map((_, i) => (
              <div key={i} className="border-l border-gray-200 flex items-center justify-center p-1">
                <Input
                  type="number"
                  min="0"
                  max="99"
                  value={setsA[i] || ''}
                  onChange={(e) => handleSetChange('A', i, e.target.value)}
                  placeholder="0"
                  className={cn(
                    "w-full h-10 text-center font-mono font-bold text-xl p-0 border-0",
                    setsA[i] > setsB[i] && "bg-green-100 text-green-700",
                    setsA[i] < setsB[i] && "bg-red-50 text-red-400",
                    setsA[i] === setsB[i] && setsA[i] > 0 && "bg-yellow-50"
                  )}
                />
              </div>
            ))}
            <div className={cn(
              "border-l-2 border-gray-300 flex items-center justify-center font-bold text-xl",
              setsWonA > setsWonB && "bg-green-200 text-green-800",
              setsWonA < setsWonB && "bg-gray-100 text-gray-500",
              setsWonA === setsWonB && "bg-gray-50"
            )}>
              {setsWonA}
            </div>
          </div>

          {/* Team B row */}
          <div className={cn(
            "grid transition-colors",
            maxSets === 1 && "grid-cols-[1fr_64px_64px]",
            maxSets === 2 && "grid-cols-[1fr_48px_48px_64px]",
            maxSets === 3 && "grid-cols-[1fr_48px_48px_48px_64px]",
            isWinnerB && "bg-green-100",
            calculatedWinner === 'B' && !isCompleted && "bg-green-50"
          )}>
            <div className="p-2 flex items-center gap-2">
              {teamB?.seed_rank && (
                <Badge className="bg-primary text-primary-foreground h-5 w-5 p-0 justify-center text-xs font-bold shrink-0">
                  {teamB.seed_rank}
                </Badge>
              )}
              <span className={cn(
                "font-semibold text-sm truncate",
                (isWinnerB || calculatedWinner === 'B') && "text-green-700"
              )}>
                {teamB.name}
              </span>
              {isWinnerB && <Trophy className="h-4 w-4 text-green-600 shrink-0" />}
            </div>
            {Array.from({ length: maxSets }).map((_, i) => (
              <div key={i} className="border-l border-gray-200 flex items-center justify-center p-1">
                <Input
                  type="number"
                  min="0"
                  max="99"
                  value={setsB[i] || ''}
                  onChange={(e) => handleSetChange('B', i, e.target.value)}
                  placeholder="0"
                  className={cn(
                    "w-full h-10 text-center font-mono font-bold text-xl p-0 border-0",
                    setsB[i] > setsA[i] && "bg-green-100 text-green-700",
                    setsB[i] < setsA[i] && "bg-red-50 text-red-400",
                    setsB[i] === setsA[i] && setsB[i] > 0 && "bg-yellow-50"
                  )}
                />
              </div>
            ))}
            <div className={cn(
              "border-l-2 border-gray-300 flex items-center justify-center font-bold text-xl",
              setsWonB > setsWonA && "bg-green-200 text-green-800",
              setsWonB < setsWonA && "bg-gray-100 text-gray-500",
              setsWonB === setsWonA && "bg-gray-50"
            )}>
              {setsWonB}
            </div>
          </div>
        </div>

        {/* Winner indicator */}
        {(isCompleted || calculatedWinner) && (
          <div className={cn(
            "mt-3 p-2 rounded-lg text-center text-sm font-semibold",
            isCompleted ? "bg-green-100 border border-green-300 text-green-700" : "bg-yellow-100 border border-yellow-300 text-yellow-700"
          )}>
            {isCompleted ? (
              <>🏆 Vainqueur : {isWinnerA ? teamA.name : teamB.name}</>
            ) : (
              <>⏳ Enregistrement...</>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Group standings table
const GroupStandingsTable = ({
  groupName,
  standings,
  qualifiersCount
}: {
  groupName: string;
  standings: ReturnType<typeof calculateGroupStandings>;
  qualifiersCount: number;
}) => {
  return (
    <div className="rounded-xl border-2 border-primary/20 bg-white overflow-hidden shadow-lg">
      <div className="p-4 border-b-2 border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5">
        <h3 className="font-bold text-lg text-primary flex items-center gap-2">
          <Users className="h-5 w-5" />
          {groupName}
        </h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-100 border-b-2 border-gray-200">
              <th className="text-left p-3 font-bold text-gray-700">#</th>
              <th className="text-left p-3 font-bold text-gray-700">Équipe</th>
              <th className="text-center p-3 font-bold text-gray-700">J</th>
              <th className="text-center p-3 font-bold text-gray-700">V</th>
              <th className="text-center p-3 font-bold text-gray-700">D</th>
              <th className="text-center p-3 font-bold text-gray-700">Sets</th>
              <th className="text-center p-3 font-bold text-gray-700">Jeux</th>
              <th className="text-center p-3 font-bold text-gray-700">Pts</th>
            </tr>
          </thead>
          <tbody>
            {standings.map((entry, index) => {
              const isQualified = index < qualifiersCount;
              const isFirst = index === 0;
              return (
                <tr 
                  key={entry.team.id}
                  className={cn(
                    "transition-colors border-b",
                    isFirst && "bg-gradient-to-r from-amber-100 to-amber-50",
                    isQualified && !isFirst && "bg-green-50",
                    !isQualified && "bg-white hover:bg-gray-50"
                  )}
                >
                  <td className="p-3">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-sm",
                      isFirst && "bg-amber-400 text-white",
                      isQualified && !isFirst && "bg-green-500 text-white",
                      !isQualified && "bg-gray-300 text-gray-600"
                    )}>
                      {index + 1}
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      {entry.team.seed_rank && (
                        <Badge className="bg-primary/80 text-white text-xs h-5">
                          TdS {entry.team.seed_rank}
                        </Badge>
                      )}
                      <span className={cn(
                        "font-semibold truncate max-w-40",
                        isFirst && "text-amber-800",
                        isQualified && !isFirst && "text-green-800"
                      )}>
                        {entry.team.name}
                      </span>
                      {isFirst && <Trophy className="h-4 w-4 text-amber-500" />}
                    </div>
                    {entry.tie_break_explanation && (
                      <div className="text-xs text-gray-500 mt-1">
                        {entry.tie_break_explanation}
                      </div>
                    )}
                  </td>
                  <td className="p-3 text-center font-mono font-bold">{entry.played}</td>
                  <td className="p-3 text-center">
                    <span className="font-mono font-bold text-green-600 bg-green-100 px-2 py-1 rounded">
                      {entry.wins}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span className="font-mono font-bold text-red-600 bg-red-100 px-2 py-1 rounded">
                      {entry.losses}
                    </span>
                  </td>
                  <td className="p-3 text-center font-mono text-sm">
                    <span className="font-bold">{entry.setsWon}-{entry.setsLost}</span>
                    <span className={cn(
                      "ml-1 text-xs",
                      entry.setsDiff > 0 && "text-green-600",
                      entry.setsDiff < 0 && "text-red-600"
                    )}>
                      ({entry.setsDiff > 0 ? '+' : ''}{entry.setsDiff})
                    </span>
                  </td>
                  <td className="p-3 text-center font-mono text-sm">
                    <span className="font-bold">{entry.gamesWon}-{entry.gamesLost}</span>
                    <span className={cn(
                      "ml-1 text-xs",
                      entry.gamesDiff > 0 && "text-green-600",
                      entry.gamesDiff < 0 && "text-red-600"
                    )}>
                      ({entry.gamesDiff > 0 ? '+' : ''}{entry.gamesDiff})
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span className={cn(
                      "font-bold text-lg px-3 py-1 rounded-full",
                      isFirst && "bg-amber-400 text-white",
                      isQualified && !isFirst && "bg-green-500 text-white",
                      !isQualified && "bg-gray-200 text-gray-700"
                    )}>
                      {entry.points}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="p-3 bg-gray-50 border-t flex items-center gap-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-amber-400"></div>
          <span>1er</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span>Qualifié</span>
        </div>
      </div>
    </div>
  );
};

// Live groups view with all pools
const LiveGroupsView = ({
  groupDraw,
  teams,
  gameFormat,
  qualifiersPerGroup,
  onScoreSubmit
}: {
  groupDraw: GroupResult;
  teams: TournamentTeam[];
  gameFormat: GameFormat;
  qualifiersPerGroup: number;
  onScoreSubmit: (matchId: string, scoreA: string, scoreB: string, winnerId: string) => void;
}) => {
  const [activeTab, setActiveTab] = useState<string>('all');

  // Calculate standings for each group
  const groupsWithStandings = useMemo(() => {
    return groupDraw.groups.map(group => {
      // Get matches for this group
      const groupMatches = groupDraw.matches.filter(m => 
        group.team_ids.includes(m.team_a_id || '') && 
        group.team_ids.includes(m.team_b_id || '')
      );
      
      const standings = calculateGroupStandings(group.team_ids, teams, groupMatches);
      
      return {
        ...group,
        matches: groupMatches,
        standings,
        completedMatches: groupMatches.filter(m => m.winner_id).length,
        totalMatches: groupMatches.length
      };
    });
  }, [groupDraw, teams]);

  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="border-b px-4">
          <TabsList className="h-12">
            <TabsTrigger value="all" className="gap-2">
              <LayoutGrid className="h-4 w-4" />
              Toutes les poules
            </TabsTrigger>
            {groupsWithStandings.map(group => (
              <TabsTrigger key={group.order} value={`group-${group.order}`} className="gap-2">
                <Users className="h-4 w-4" />
                {group.name}
                <Badge variant="secondary" className="ml-1 text-xs">
                  {group.completedMatches}/{group.totalMatches}
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {/* All groups view */}
        <TabsContent value="all" className="flex-1 m-0 p-4 overflow-auto">
          <details className="mb-4 rounded-xl border bg-white p-4">
            <summary className="cursor-pointer font-semibold">Aide — classement & départage</summary>
            <div className="mt-3 text-sm text-gray-700 space-y-2">
              <div><span className="font-semibold">Départage en poule (FFT)</span> : points → différence de sets → différence de jeux → mini-classement (confrontations directes). Si égalité parfaite, l’organisateur peut appliquer un tirage au sort.</div>
              <div><span className="font-semibold">Meilleur 2e / 3e</span> : si des poules n’ont pas la même taille (ex. 4,4,3), la comparaison est normalisée en ignorant le match contre le dernier de chaque poule “plus grande”.</div>
            </div>
          </details>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {groupsWithStandings.map(group => (
              <div key={group.order} className="space-y-4">
                <GroupStandingsTable
                  groupName={group.name}
                  standings={group.standings}
                  qualifiersCount={qualifiersPerGroup}
                />
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {group.matches.map((match, idx) => (
                    <LiveMatchCard
                      key={match.id || idx}
                      match={match}
                      teams={teams}
                      gameFormat={gameFormat}
                      onScoreSubmit={onScoreSubmit}
                      isCompact
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Individual group views */}
        {groupsWithStandings.map(group => (
          <TabsContent key={group.order} value={`group-${group.order}`} className="flex-1 m-0 overflow-auto">
            <div className="p-4 space-y-6">
              <GroupStandingsTable
                groupName={group.name}
                standings={group.standings}
                qualifiersCount={qualifiersPerGroup}
              />
              
              <div>
                <h4 className="font-semibold mb-4">Matchs</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {group.matches.map((match, idx) => (
                    <LiveMatchCard
                      key={match.id || idx}
                      match={match}
                      teams={teams}
                      gameFormat={gameFormat}
                      onScoreSubmit={onScoreSubmit}
                    />
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

// Live bracket visualization for knockout
const LiveKnockoutBracket = ({
  drawResult,
  teams,
  gameFormat,
  onScoreSubmit
}: {
  drawResult: DrawResult;
  teams: TournamentTeam[];
  gameFormat: GameFormat;
  onScoreSubmit: (matchId: string, scoreA: string, scoreB: string, winnerId: string) => void;
}) => {
  const roundsWithMatches = useMemo(() => {
    const grouped: Record<number, GeneratedMatch[]> = {};
    drawResult.matches.forEach(match => {
      if (!grouped[match.round_order]) {
        grouped[match.round_order] = [];
      }
      grouped[match.round_order].push(match);
    });
    return Object.entries(grouped)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([, matches]) => matches);
  }, [drawResult.matches]);

  return (
    <div className="flex gap-6 overflow-x-auto pb-4 p-4">
      {roundsWithMatches.map((matches, roundIndex) => (
        <div key={roundIndex} className="flex flex-col min-w-[280px]">
          <div className="text-center font-semibold mb-4 text-lg">
            {matches[0]?.round_name}
          </div>
          <div 
            className="flex flex-col gap-4 justify-around flex-1"
            style={{
              paddingTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 16}px` : 0,
              gap: `${Math.pow(2, roundIndex + 1) * 8}px`
            }}
          >
            {matches.filter(m => !m.is_bye).map((match, idx) => (
              <LiveMatchCard
                key={`${match.round_order}-${match.match_order}`}
                match={match}
                teams={teams}
                gameFormat={gameFormat}
                onScoreSubmit={onScoreSubmit}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export const TournamentMode = ({
  tournament,
  teams,
  knockoutDraw,
  groupDraw,
  roundRobinMatches,
  onScoreUpdate,
  onClose
}: TournamentModeProps) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const gameFormat: GameFormat = tournament.game_format || 'B1';
  const qualifiersPerGroup = tournament.qualifiers_per_group || 2;

  // Handle fullscreen
  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  // Listen for fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !document.fullscreenElement) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const formatInfo = GAME_FORMAT_CONFIG[gameFormat];

  return (
    <div className={cn(
      "fixed inset-0 z-50 bg-background",
      "flex flex-col"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-card shrink-0">
        <div className="flex items-center gap-4">
          <Badge variant="default" className="text-sm animate-pulse">
            🔴 LIVE
          </Badge>
          <h1 className="text-xl font-bold">{tournament.title}</h1>
          <Badge variant="secondary" className="text-xs">
            Format {formatInfo.label} • {formatInfo.description}
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={toggleFullscreen}
          >
            {isFullscreen ? (
              <Minimize2 className="h-4 w-4" />
            ) : (
              <Maximize2 className="h-4 w-4" />
            )}
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        {knockoutDraw && (
          <LiveKnockoutBracket 
            drawResult={knockoutDraw} 
            teams={teams}
            gameFormat={gameFormat}
            onScoreSubmit={onScoreUpdate}
          />
        )}

        {groupDraw && (
          <LiveGroupsView
            groupDraw={groupDraw}
            teams={teams}
            gameFormat={gameFormat}
            qualifiersPerGroup={qualifiersPerGroup}
            onScoreSubmit={onScoreUpdate}
          />
        )}

        {roundRobinMatches && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {roundRobinMatches.map((match, idx) => (
              <LiveMatchCard
                key={idx}
                match={match}
                teams={teams}
                gameFormat={gameFormat}
                onScoreSubmit={onScoreUpdate}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
