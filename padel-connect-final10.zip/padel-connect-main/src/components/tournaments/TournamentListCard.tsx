import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Tournament } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Calendar, MapPin, Heart, Users } from 'lucide-react';
import tournament1 from '@/assets/tournament-1.jpg';
import tournament2 from '@/assets/tournament-2.jpg';
import tournament3 from '@/assets/tournament-3.jpg';
import tournament4 from '@/assets/tournament-4.jpg';

const tournamentImages = [tournament1, tournament2, tournament3, tournament4];

interface TournamentListCardProps {
  tournament: Tournament;
  distance?: number;
  isSelected?: boolean;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
}

export function TournamentListCard({ 
  tournament, 
  distance,
  isSelected,
  onMouseEnter,
  onMouseLeave 
}: TournamentListCardProps) {
  const imageIndex = parseInt(tournament.id.replace(/\D/g, '') || '1') % tournamentImages.length;
  const displayImage = tournament.image_url || tournamentImages[imageIndex];
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      P25: 'bg-green-500 text-white',
      P50: 'bg-slate-500 text-white',
      P100: 'bg-blue-500 text-white',
      P250: 'bg-purple-500 text-white',
    };
    return colors[category] || 'bg-gray-500 text-white';
  };

  const getGenderBadgeColor = (gender: string) => {
    const colors: Record<string, string> = {
      H: 'bg-sky-400 text-white',
      F: 'bg-pink-400 text-white',
      Mixte: 'bg-violet-400 text-white',
    };
    return colors[gender] || 'bg-gray-400 text-white';
  };

  return (
    <Link
      to={`/tournaments/${tournament.id}`}
      className={`block group transition-all duration-200 ${isSelected ? 'scale-[1.02]' : ''}`}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      {/* Mobile card (list-style) */}
      <div className="sm:hidden rounded-2xl border bg-card shadow-sm overflow-hidden">
        <div className="flex gap-3 p-3">
          <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl">
            <img src={displayImage} alt={tournament.title} className="h-full w-full object-cover" />
            {tournament.is_managed_by_platform && (
              <div className="absolute left-1 top-1">
                <Badge className="bg-cyan-400 hover:bg-cyan-400 text-white text-[10px] px-1.5 py-0.5 rounded">
                  Direct
                </Badge>
              </div>
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-semibold text-sm leading-snug line-clamp-2">
                {tournament.title}
              </h3>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                className="p-2 -mr-2 -mt-2 rounded-full"
                aria-label="Favori"
              >
                <Heart className="h-5 w-5 text-gray-400" />
              </button>
            </div>

            {tournament.club?.name && (
              <div className="mt-0.5 text-xs text-muted-foreground truncate">
                {tournament.club.name}
              </div>
            )}

            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="h-3.5 w-3.5" />
              <span>{format(new Date(tournament.start_date), 'd MMM', { locale: fr })}</span>
              <span className="text-muted-foreground/50">•</span>
              <MapPin className="h-3.5 w-3.5" />
              <span className="truncate">
                {tournament.city}
                {distance !== undefined ? ` • ${distance} km` : ''}
              </span>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Badge className={`text-[11px] font-medium rounded px-2 py-0.5 ${getCategoryColor(tournament.category_code)}`}>
                {tournament.category_code}
              </Badge>
              <Badge className={`text-[11px] font-medium rounded px-2 py-0.5 ${getGenderBadgeColor(tournament.gender)}`}>
                {tournament.gender === 'H' ? 'H' : tournament.gender === 'F' ? 'F' : 'Mixte'}
              </Badge>

              {tournament.max_teams !== undefined && tournament.registrations_count !== undefined && (
                <span className="ml-auto inline-flex items-center gap-1 text-xs text-muted-foreground">
                  <Users className="h-3.5 w-3.5" />
                  {tournament.registrations_count}/{tournament.max_teams}
                </span>
              )}
            </div>

            <div className="mt-2 flex items-center justify-between">
              <div className="text-sm font-semibold">
                {tournament.price && tournament.price > 0
                  ? `${tournament.price.toFixed(0)} € / joueur`
                  : 'Prix à définir'}
              </div>
              <span className="text-primary text-sm font-medium">Voir</span>
            </div>
          </div>
        </div>
      </div>

      {/* Desktop card (grid-style) */}
      <div className="hidden sm:block space-y-3">
        {/* Image Container */}
        <div className={`relative aspect-square overflow-hidden rounded-xl transition-all duration-200 ${
          isSelected ? 'ring-2 ring-primary shadow-lg' : ''
        }`}>
          <img
            src={displayImage}
            alt={tournament.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          
          {/* Badge "Achat instantané" / Inscription directe */}
          {tournament.is_managed_by_platform && (
            <div className="absolute top-3 left-3">
              <Badge className="bg-cyan-400 hover:bg-cyan-400 text-white text-xs font-medium px-3 py-1 rounded-md shadow-sm">
                Achat instantané
              </Badge>
            </div>
          )}
          
          {/* Favorite button */}
          <button 
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            className="absolute top-3 right-3 p-2 rounded-full bg-white/90 hover:bg-white transition-colors shadow-sm"
          >
            <Heart className="h-5 w-5 text-gray-400 hover:text-red-500 transition-colors" />
          </button>
        </div>
        
        {/* Content */}
        <div className="space-y-2">
          <h3 className="font-display font-bold italic text-base uppercase tracking-wide group-hover:text-primary transition-colors line-clamp-2 leading-tight">
            {tournament.title}
          </h3>

          {tournament.club?.name && (
            <div className="text-sm text-muted-foreground">
              {tournament.club.name}
            </div>
          )}
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4 shrink-0" />
            <span>
              {format(new Date(tournament.start_date), 'd MMMM yyyy', { locale: fr })}
            </span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0" />
            <span>
              {tournament.city}
              {tournament.region && ` (${tournament.region.slice(0, 2).toUpperCase()})`}
              {distance !== undefined && (
                <span className="text-primary font-medium ml-1">• {distance} km</span>
              )}
            </span>
          </div>
          
          {tournament.price !== undefined && tournament.price > 0 && (
            <p className="text-sm font-medium text-foreground">
              À partir de {tournament.price.toFixed(2).replace('.', ',')} €
            </p>
          )}
          
          {tournament.max_teams !== undefined && tournament.registrations_count !== undefined && (
            <div className="pt-1">
              {tournament.registrations_count >= tournament.max_teams ? (
                <Badge className="bg-destructive text-white text-xs font-medium rounded px-2 py-0.5">
                  Complet • Liste d’attente
                </Badge>
              ) : (
                <Badge className="bg-emerald-600 text-white text-xs font-medium rounded px-2 py-0.5">
                  {tournament.max_teams - tournament.registrations_count} place{(tournament.max_teams - tournament.registrations_count) > 1 ? 's' : ''} restante{(tournament.max_teams - tournament.registrations_count) > 1 ? 's' : ''}
                </Badge>
              )}
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1">
            <Badge className={`text-xs font-medium rounded px-2 py-0.5 ${getCategoryColor(tournament.category_code)}`}>
              {tournament.category_code}
            </Badge>
            <Badge className={`text-xs font-medium rounded px-2 py-0.5 ${getGenderBadgeColor(tournament.gender)}`}>
              {tournament.gender === 'H' ? 'Hommes' : tournament.gender === 'F' ? 'Femmes' : 'Mixte'}
            </Badge>
          </div>
        </div>
      </div>
    </Link>
  );
}
