import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TournamentFilters as FiltersType } from '@/types';
import { frenchRegions, categoryOptions, genderOptions } from '@/data/mockData';
import { X, MapPin, Navigation, Loader2, Calendar } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

interface TournamentFiltersProps {
  filters: FiltersType;
  onFiltersChange: (filters: FiltersType) => void;
  userLocation?: { lat: number; lng: number } | null;
  onUserLocationChange?: (location: { lat: number; lng: number } | null) => void;
  showSearchButton?: boolean;
  onSearch?: () => void;
  availableCities?: string[];
}

export function TournamentFilters({ 
  filters, 
  onFiltersChange, 
  userLocation,
  onUserLocationChange,
  showSearchButton = false,
  onSearch,
  availableCities = [],
}: TournamentFiltersProps) {
  const [isGeolocating, setIsGeolocating] = useState(false);
  const [maxDistance, setMaxDistance] = useState<number>(filters.max_distance || 50);

  const updateFilter = (key: keyof FiltersType, value: string | number | undefined) => {
    onFiltersChange({
      ...filters,
      [key]: value === 'all' ? undefined : value,
    });
  };

  const clearFilters = () => {
    onFiltersChange({});
    onUserLocationChange?.(null);
    setMaxDistance(50);
  };

  const hasActiveFilters = Object.values(filters).some(v => v !== undefined) || userLocation;
  const activeFiltersCount = Object.values(filters).filter(v => v !== undefined).length + (userLocation ? 1 : 0);

  // Géolocalisation automatique
  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      alert('La géolocalisation n\'est pas supportée par votre navigateur');
      return;
    }

    setIsGeolocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        onUserLocationChange?.({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        updateFilter('max_distance', maxDistance);
        setIsGeolocating(false);
      },
      (error) => {
        console.error('Erreur de géolocalisation:', error);
        alert('Impossible d\'obtenir votre position');
        setIsGeolocating(false);
      }
    );
  };

  const handleDistanceChange = (value: number[]) => {
    setMaxDistance(value[0]);
    if (userLocation) {
      updateFilter('max_distance', value[0]);
    }
  };

  const clearLocation = () => {
    onUserLocationChange?.(null);
    updateFilter('max_distance', undefined);
  };

  // Unique sorted cities
  const uniqueCities = [...new Set(availableCities)].filter(Boolean).sort();

  return (
    <div className="space-y-4">
      {/* Mobile (stacked) */}
      <div className="md:hidden space-y-3">
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant={userLocation ? 'default' : 'outline'}
            onClick={handleGeolocation}
            disabled={isGeolocating}
            className="gap-2"
          >
            {isGeolocating ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Navigation className="h-4 w-4" />
            )}
            {userLocation ? 'Localisation active' : 'Me localiser'}
          </Button>

          {userLocation && (
            <Button type="button" variant="ghost" onClick={clearLocation}>
              <X className="h-4 w-4 mr-1" />
              Effacer
            </Button>
          )}
        </div>

        {userLocation && (
          <div className="rounded-xl border bg-background p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Distance max</span>
              <span className="text-sm font-semibold">{maxDistance} km</span>
            </div>
            <Slider
              value={[maxDistance]}
              onValueChange={handleDistanceChange}
              min={5}
              max={200}
              step={5}
            />
          </div>
        )}

        <Select value={filters.region || 'all'} onValueChange={(value) => updateFilter('region', value)}>
          <SelectTrigger className="w-full h-12">
            <SelectValue placeholder="Toutes régions" />
          </SelectTrigger>
          <SelectContent className="max-h-[300px]">
            <SelectItem value="all">Toutes régions</SelectItem>
            {frenchRegions.map((region) => (
              <SelectItem key={region} value={region}>{region}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {uniqueCities.length > 0 && (
          <Select value={filters.city || 'all'} onValueChange={(value) => updateFilter('city', value)}>
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Toutes villes" />
            </SelectTrigger>
            <SelectContent className="max-h-[300px]">
              <SelectItem value="all">Toutes villes</SelectItem>
              {uniqueCities.map((city) => (
                <SelectItem key={city} value={city}>{city}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        <div className="grid grid-cols-2 gap-2">
          <Select value={filters.category || 'all'} onValueChange={(value) => updateFilter('category', value)}>
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Niveau" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous niveaux</SelectItem>
              {categoryOptions.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filters.gender || 'all'} onValueChange={(value) => updateFilter('gender', value)}>
            <SelectTrigger className="w-full h-12">
              <SelectValue placeholder="Genre" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Genre</SelectItem>
              {genderOptions.map((g) => (
                <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">À partir du</label>
            <Input
              type="date"
              value={filters.start_date || ''}
              onChange={(e) => updateFilter('start_date', e.target.value || undefined)}
              className="h-12"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">Jusqu'au</label>
            <Input
              type="date"
              value={filters.end_date || ''}
              onChange={(e) => updateFilter('end_date', e.target.value || undefined)}
              className="h-12"
            />
          </div>
        </div>

        {hasActiveFilters && (
          <Button type="button" variant="ghost" onClick={clearFilters} className="w-full">
            <X className="h-4 w-4 mr-1" />
            Effacer les filtres
          </Button>
        )}

        {showSearchButton && (
          <Button type="button" className="w-full" onClick={onSearch}>
            Rechercher
          </Button>
        )}
      </div>

      {/* Main filter bar container */}
      <div className="hidden md:flex items-center gap-4 w-full">
        {/* Filter bar with rounded borders */}
        <div className="bg-background rounded-2xl shadow-2xl border-2 border-border flex items-center px-3 gap-1">
                    {/* Geolocation button */}
          <button
            onClick={handleGeolocation}
            disabled={isGeolocating}
            className="h-14 px-3 flex items-center justify-center rounded-xl hover:bg-muted/50 transition-colors"
            title="Me géolocaliser"
          >
            {isGeolocating ? (
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            ) : (
              <Navigation className={`h-5 w-5 ${userLocation ? 'text-primary fill-primary/20' : 'text-muted-foreground'}`} />
            )}
          </button>

          {/* Distance slider (visible when location is set) */}
          {userLocation && (
            <>
              <div className="w-px h-8 bg-border/50" />
              <div className="flex items-center gap-2 px-3">
                <span className="text-sm font-medium whitespace-nowrap">{maxDistance} km</span>
                <Slider
                  value={[maxDistance]}
                  onValueChange={handleDistanceChange}
                  min={5}
                  max={200}
                  step={5}
                  className="w-20"
                />
                <button 
                  onClick={clearLocation}
                  className="p-1 hover:bg-muted rounded-full"
                  title="Effacer la localisation"
                >
                  <X className="h-4 w-4 text-muted-foreground" />
                </button>
              </div>
            </>
          )}

          <div className="w-px h-8 bg-border/50" />

          {/* Region select */}
          <div className="flex flex-shrink-0">
            <Select
              value={filters.region || 'all'}
              onValueChange={(value) => updateFilter('region', value)}
            >
              <SelectTrigger className="border-0 rounded-xl h-14 px-4 focus:ring-0 focus:ring-offset-0 text-sm hover:bg-muted/50 transition-colors">
                <span className="font-medium">
                  <SelectValue placeholder="Régions" />
                </span>
              </SelectTrigger>
              <SelectContent className="max-h-[300px] bg-background border shadow-lg z-50">
                <SelectItem value="all">Toutes régions</SelectItem>
                {frenchRegions.map((region) => (
                  <SelectItem key={region} value={region}>
                    {region}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-px h-8 bg-border/50" />

          {/* Category select */}
          <div className="flex flex-shrink-0">
            <Select
              value={filters.category || 'all'}
              onValueChange={(value) => updateFilter('category', value)}
            >
              <SelectTrigger className="border-0 rounded-xl h-14 px-4 focus:ring-0 focus:ring-offset-0 text-sm hover:bg-muted/50 transition-colors">
                <span className="font-medium">
                  <SelectValue placeholder="Niveaux" />
                </span>
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                <SelectItem value="all">Tous niveaux</SelectItem>
                {categoryOptions.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-px h-8 bg-border/50" />

          {/* Gender select */}
          <div className="flex flex-shrink-0">
            <Select
              value={filters.gender || 'all'}
              onValueChange={(value) => updateFilter('gender', value)}
            >
              <SelectTrigger className="border-0 rounded-xl h-14 px-4 focus:ring-0 focus:ring-offset-0 text-sm hover:bg-muted/50 transition-colors">
                <span className="font-medium">
                  <SelectValue placeholder="Genre" />
                </span>
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                <SelectItem value="all">Genre</SelectItem>
                {genderOptions.map((g) => (
                  <SelectItem key={g.value} value={g.value}>
                    {g.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-px h-8 bg-border/50" />

          {/* Dates popover */}
          <div className="flex flex-shrink-0">
            <Popover>
              <PopoverTrigger asChild>
                <button className="h-14 px-4 flex items-center gap-2 text-sm rounded-xl hover:bg-muted/50 transition-colors font-medium">
                  <Calendar className="h-5 w-5 text-primary shrink-0" />
                  <span className={filters.start_date ? 'text-foreground' : 'text-muted-foreground'}>
                    {filters.start_date ? `${filters.start_date}` : 'Dates'}
                  </span>
                </button>
              </PopoverTrigger>
            <PopoverContent className="w-80 bg-background border shadow-lg z-50 pointer-events-auto" align="end">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">À partir du</label>
                  <Input
                    type="date"
                    value={filters.start_date || ''}
                    onChange={(e) => updateFilter('start_date', e.target.value || undefined)}
                    className="pointer-events-auto"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Jusqu'au (optionnel)</label>
                  <Input
                    type="date"
                    value={filters.end_date || ''}
                    onChange={(e) => updateFilter('end_date', e.target.value || undefined)}
                    className="pointer-events-auto"
                  />
                </div>
                {(filters.start_date || filters.end_date) && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => {
                      updateFilter('start_date', undefined);
                      updateFilter('end_date', undefined);
                    }}
                    className="w-full"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Effacer les dates
                  </Button>
                )}
              </div>
            </PopoverContent>
          </Popover>
        </div>

        </div>

        {/* Search button - outside the rounded bar */}
        {showSearchButton && (
          <Button className="rounded-2xl h-14 px-8 text-sm font-bold shadow-lg flex-shrink-0" onClick={onSearch}>
            Rechercher
          </Button>
        )}
      </div>

      {/* Active filters chips */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 px-2">
          {userLocation && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
              <Navigation className="h-3 w-3" />
              {maxDistance} km
              <button onClick={clearLocation} className="hover:bg-primary/20 rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.city && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
              <MapPin className="h-3 w-3" />
              {filters.city}
              <button onClick={() => updateFilter('city', undefined)} className="hover:bg-primary/20 rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.region && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
              {filters.region}
              <button onClick={() => updateFilter('region', undefined)} className="hover:bg-primary/20 rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.category && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
              {filters.category}
              <button onClick={() => updateFilter('category', undefined)} className="hover:bg-primary/20 rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.gender && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm">
              {filters.gender === 'H' ? 'Hommes' : filters.gender === 'F' ? 'Femmes' : 'Mixte'}
              <button onClick={() => updateFilter('gender', undefined)} className="hover:bg-primary/20 rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
}
