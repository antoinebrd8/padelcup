import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { supabase } from '@/integrations/supabase/client';
import { isValidFftLicenseNumber } from '@/lib/license';
import { Users, Mail, ArrowRight, ArrowLeft, CheckCircle, XCircle, Loader2, User, AlertTriangle } from 'lucide-react';
import { PlayerProfile } from '@/contexts/PlayerAuthContext';

interface TeammateInfo {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  license_number: string | null;
}

interface RegistrationStep2Props {
  currentPlayer: PlayerProfile;
  teammateMode: 'account' | 'manual';
  setTeammateMode: (mode: 'account' | 'manual') => void;
  teammateEmail: string;
  setTeammateEmail: (email: string) => void;
  teammate: TeammateInfo | null;
  setTeammate: (teammate: TeammateInfo | null) => void;
  manualTeammateFirstName: string;
  setManualTeammateFirstName: (v: string) => void;
  manualTeammateLastName: string;
  setManualTeammateLastName: (v: string) => void;
  manualTeammateLicense: string;
  setManualTeammateLicense: (v: string) => void;
  teammateHasLicense: boolean;
  setTeammateHasLicense: (value: boolean) => void;
  onNext: () => void;
  onBack: () => void;
  licenseRequired?: boolean;
}

export function RegistrationStep2({
  currentPlayer,
  teammateMode,
  setTeammateMode,
  teammateEmail,
  setTeammateEmail,
  teammate,
  setTeammate,
  manualTeammateFirstName,
  setManualTeammateFirstName,
  manualTeammateLastName,
  setManualTeammateLastName,
  manualTeammateLicense,
  setManualTeammateLicense,
  teammateHasLicense,
  setTeammateHasLicense,
  onNext,
  onBack,
  licenseRequired = false,
}: RegistrationStep2Props) {
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [licenseAnswered, setLicenseAnswered] = useState(false);
  const teammateLicenseOk = isValidFftLicenseNumber(teammate?.license_number);
  const manualLicenseOk = !manualTeammateLicense ? false : isValidFftLicenseNumber(manualTeammateLicense);

  useEffect(() => {
    if (teammateMode !== 'account') {
      // Reset account teammate when switching to manual mode
      setTeammate(null);
      setSearchError(null);
      setHasSearched(false);
      return;
    }
    const searchTeammate = async () => {
      // Manual mode: no account lookup
      if (teammateMode === 'manual') {
        setTeammate(null);
        setSearchError(null);
        setHasSearched(false);
        return;
      }

      if (!teammateEmail || teammateEmail.length < 5 || !teammateEmail.includes('@')) {
        setTeammate(null);
        setSearchError(null);
        setHasSearched(false);
        setLicenseAnswered(false);
        return;
      }

      // Don't allow registering with yourself
      if (teammateEmail.toLowerCase() === currentPlayer.email.toLowerCase()) {
        setTeammate(null);
        setSearchError('Vous ne pouvez pas vous inscrire avec vous-même');
        setHasSearched(true);
        return;
      }

      setIsSearching(true);
      setSearchError(null);

      const normalizedEmail = teammateEmail.trim().toLowerCase();

      // Lookup teammate by email.
      // IMPORTANT: the `players` table may have RLS enabled (only self-readable),
      // so we use a SECURITY DEFINER RPC (see migration: find_player_by_email_rpc.sql)
      // to allow safe, minimal-field lookup for registrations.
      const { data, error } = await supabase
        .rpc('find_player_by_email', { p_email: normalizedEmail })
        .maybeSingle();

      setIsSearching(false);
      setHasSearched(true);

      if (error) {
        setSearchError('Erreur lors de la recherche');
        setTeammate(null);
        return;
      }

      const teammateRow = (data as any) || null;
      if (teammateRow) {
        setTeammate(teammateRow as TeammateInfo);
        setSearchError(null);
        // Auto-set license status if teammate has license number
        if ((teammateRow as any).license_number) {
          setTeammateHasLicense(true);
          setLicenseAnswered(true);
        } else {
          setLicenseAnswered(false);
        }
      } else {
        setTeammate(null);
        setSearchError('Aucun joueur trouvé avec cet email. Il doit s\'inscrire sur la plateforme.');
      }
    };

    const debounce = setTimeout(searchTeammate, 500);
    return () => clearTimeout(debounce);
  }, [teammateEmail, teammateMode, currentPlayer.email, setTeammate, setTeammateHasLicense]);

  const handleLicenseChange = (value: string) => {
    setTeammateHasLicense(value === 'yes');
    setLicenseAnswered(true);
  };

  const canContinue = teammateMode === 'account'
    ? (!!teammate && (licenseRequired ? teammateLicenseOk : (teammate.license_number || licenseAnswered)))
    : (
        manualTeammateFirstName.trim().length > 0 &&
        manualTeammateLastName.trim().length > 0 &&
        (licenseRequired ? manualLicenseOk : true)
      );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
            2
          </div>
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Votre coéquipier
            </CardTitle>
            <CardDescription>
              Entrez l'email de votre partenaire de jeu
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 rounded-lg border border-border bg-background">
          <Label className="text-base font-medium mb-3 block">Comment ajouter votre coéquipier ? *</Label>
          <RadioGroup
            value={teammateMode}
            onValueChange={(v) => {
              const mode = (v as 'account' | 'manual');
              setTeammateMode(mode);
              // Reset state when switching mode
              setTeammateEmail('');
              setTeammate(null);
              setSearchError(null);
              setHasSearched(false);
            }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="account" id="mode-account" />
              <Label htmlFor="mode-account" className="font-normal cursor-pointer">Par email (coéquipier a un compte)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="manual" id="mode-manual" />
              <Label htmlFor="mode-manual" className="font-normal cursor-pointer">Renseigner ses infos (je paie tout)</Label>
            </div>
          </RadioGroup>
        </div>

        {teammateMode === 'account' && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="teammate_email">Email du coéquipier *</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="teammate_email"
                type="email"
                placeholder="partenaire@email.com"
                className="pl-10 pr-10"
                value={teammateEmail}
                onChange={(e) => setTeammateEmail(e.target.value)}
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {isSearching && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                {!isSearching && hasSearched && teammate && (
                  <CheckCircle className="h-5 w-5 text-success" />
                )}
                {!isSearching && hasSearched && !teammate && teammateEmail && (
                  <XCircle className="h-5 w-5 text-destructive" />
                )}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Votre coéquipier doit être inscrit sur la plateforme
            </p>
          </div>

          {searchError && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
              <p className="text-sm text-destructive">{searchError}</p>
            </div>
          )}

          {teammate && (
            <div className="p-4 rounded-lg bg-success/10 border border-success/20">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-success/20">
                  <User className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="font-medium text-success">
                    {teammate.first_name} {teammate.last_name}
                  </p>
                  {/* username removed: identification is email-based */}
                  <p className="text-sm text-muted-foreground">{teammate.email}</p>
                  {teammate.license_number && (
                    <p className="text-xs text-muted-foreground">
                      Licence: {teammate.license_number}
                    </p>
                  )}
                </div>
                <CheckCircle className="h-6 w-6 text-success ml-auto" />
              </div>
            </div>
          )}

          {licenseRequired && teammate && !teammateLicenseOk && (
            <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-destructive">Licence FFT obligatoire</p>
                  <p className="text-xs text-muted-foreground">
                    Ce tournoi nécessite une licence FFT valide pour votre coéquipier (format : 7 chiffres puis 1 lettre).
                    Demandez-lui de compléter son profil (numéro de licence) pour continuer.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* License question for teammate - only show if no license number */}
          {teammate && !teammate.license_number && !licenseRequired && (
            <div className="p-4 rounded-lg border border-border bg-background">
              <Label className="text-base font-medium mb-3 block">
                Votre coéquipier possède-t-il une licence FFT ? *
              </Label>
              <RadioGroup 
                value={teammateHasLicense ? 'yes' : 'no'} 
                onValueChange={handleLicenseChange}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="yes" id="teammate-license-yes" />
                  <Label htmlFor="teammate-license-yes" className="font-normal cursor-pointer">Oui</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="no" id="teammate-license-no" />
                  <Label htmlFor="teammate-license-no" className="font-normal cursor-pointer">Non</Label>
                </div>
              </RadioGroup>
              
              {licenseAnswered && !teammateHasLicense && (
                <div className="mt-3 p-3 rounded-lg bg-warning/10 border border-warning/20">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-warning">Attention</p>
                      <p className="text-xs text-muted-foreground">
                        Votre coéquipier sera signalé comme joueur sans licence auprès de l'organisateur.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        )}

        {teammateMode === 'manual' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="manual_first_name">Prénom du coéquipier *</Label>
                <Input
                  id="manual_first_name"
                  placeholder="Prénom"
                  value={manualTeammateFirstName}
                  onChange={(e) => setManualTeammateFirstName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manual_last_name">Nom du coéquipier *</Label>
                <Input
                  id="manual_last_name"
                  placeholder="Nom"
                  value={manualTeammateLastName}
                  onChange={(e) => setManualTeammateLastName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="manual_license">Licence FFT {licenseRequired ? '*' : '(optionnel)'}</Label>
              <Input
                id="manual_license"
                placeholder="1234567A"
                value={manualTeammateLicense}
                onChange={(e) => setManualTeammateLicense(e.target.value.toUpperCase())}
              />
              <p className="text-xs text-muted-foreground">Format : 7 chiffres puis 1 lettre.</p>
            </div>

            {licenseRequired && !manualLicenseOk && (
              <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-destructive">Licence FFT obligatoire</p>
                    <p className="text-xs text-muted-foreground">
                      Ce tournoi nécessite une licence FFT valide pour votre coéquipier (format : 7 chiffres puis 1 lettre).
                    </p>
                  </div>
                </div>
              </div>
            )}

            {!licenseRequired && !manualTeammateLicense && (
              <div className="p-4 rounded-lg border border-border bg-background">
                <Label className="text-base font-medium mb-3 block">
                  Votre coéquipier possède-t-il une licence FFT ? *
                </Label>
                <RadioGroup
                  value={teammateHasLicense ? 'yes' : 'no'}
                  onValueChange={handleLicenseChange}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="manual-license-yes" />
                    <Label htmlFor="manual-license-yes" className="font-normal cursor-pointer">Oui</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="manual-license-no" />
                    <Label htmlFor="manual-license-no" className="font-normal cursor-pointer">Non</Label>
                  </div>
                </RadioGroup>
              </div>
            )}
          </div>
        )}

        <div className="flex gap-3">
          <Button variant="outline" onClick={onBack} className="flex-1">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour
          </Button>
          <Button 
            onClick={onNext} 
            className="flex-1" 
            disabled={!canContinue}
          >
            Continuer
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
