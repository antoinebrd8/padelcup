import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { PlayerProfile } from '@/contexts/PlayerAuthContext';
import { 
  CreditCard, 
  ArrowLeft, 
  Users, 
  User, 
  Euro, 
  CheckCircle,
  Mail,
  Loader2,
  Share2,
  Clock
} from 'lucide-react';

import { PADEL_CUP_FEE_PER_PLAYER_EUR, playerTotalPrice, teamTotalPrice } from '@/lib/fees';

interface TeammateInfo {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  license_number: string | null;
}

interface RegistrationStep3Props {
  player: PlayerProfile;
  teammate: TeammateInfo;
  teammateMode: 'account' | 'manual';
  tournamentTitle: string;
  tournamentPrice: number;
  onBack: () => void;
  onPayHalf: () => Promise<void>;
  onPayFull: () => Promise<void>;
  isWaitlist?: boolean;
}

export function RegistrationStep3({
  player,
  teammate,
  teammateMode,
  tournamentTitle,
  tournamentPrice,
  onBack,
  onPayHalf,
  onPayFull,
  isWaitlist = false,
}: RegistrationStep3Props) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedOption, setSelectedOption] = useState<'half' | 'full' | null>(null);

  // In manual teammate mode, split payment is not available
  useEffect(() => {
    if (teammateMode === 'manual') {
      setSelectedOption('full');
    }
  }, [teammateMode]);

  // Pricing model:
  // - Organizer sets a base price PER PLAYER (tournamentPrice)
  // - Player pays base + Padel Cup fee (4€)
  const basePerPlayer = tournamentPrice;
  const halfPrice = playerTotalPrice(basePerPlayer);
  const fullPrice = teamTotalPrice(basePerPlayer);

  const handlePayHalf = async () => {
    setIsProcessing(true);
    setSelectedOption('half');
    await onPayHalf();
    setIsProcessing(false);
  };

  const handlePayFull = async () => {
    setIsProcessing(true);
    setSelectedOption('full');
    await onPayFull();
    setIsProcessing(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
            3
          </div>
          <div>
            <CardTitle className="flex items-center gap-2">
              {isWaitlist ? (
                <>
                  <Clock className="h-5 w-5" />
                  Liste d'attente
                </>
              ) : (
                <>
                  <CreditCard className="h-5 w-5" />
                  Paiement
                </>
              )}
            </CardTitle>
            <CardDescription>
              {isWaitlist 
                ? "Le tournoi est complet - Inscrivez-vous sur liste d'attente"
                : "Choisissez votre mode de paiement"
              }
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Récapitulatif de l'équipe */}
        <div className="p-4 rounded-lg bg-muted/50 border">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Users className="h-4 w-4" />
            Récapitulatif de l'équipe
          </h4>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-medium">{player.first_name} {player.last_name}</p>
                <p className="text-xs text-muted-foreground">{player.email}</p>
              </div>
              <Badge variant="secondary">Vous</Badge>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-success/10">
                <User className="h-4 w-4 text-success" />
              </div>
              <div className="flex-1">
                <p className="font-medium">{teammate.first_name} {teammate.last_name}</p>
                <p className="text-xs text-muted-foreground">{teammate.email}</p>
              </div>
              <Badge variant="outline">Coéquipier</Badge>
            </div>
          </div>
        </div>

        {/* Prix du tournoi */}
        <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Prix organisateur</span>
            <span className="text-2xl font-bold">{basePerPlayer}€</span>
          </div>
          <p className="text-sm text-muted-foreground mt-1">Par joueur</p>
          <div className="mt-3 text-sm text-muted-foreground space-y-1">
            <div className="flex justify-between">
              <span>Frais Padel Cup</span>
              <span>+{PADEL_CUP_FEE_PER_PLAYER_EUR}€ / joueur</span>
            </div>
            <div className="flex justify-between font-medium text-foreground">
              <span>Total équipe</span>
              <span>{teamTotalPrice(basePerPlayer)}€</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Options de paiement / waitlist */}
        {isWaitlist ? (
          <div className="space-y-4">
            <div className="p-4 rounded-lg border-2 border-warning bg-warning/5">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-warning/10 shrink-0">
                  <Clock className="h-6 w-6 text-warning" />
                </div>
                <div className="flex-1">
                  <h5 className="font-semibold mb-1">Inscription en liste d'attente</h5>
                  <p className="text-sm text-muted-foreground">
                    Vous serez automatiquement inscrit et contacté par email si une place se libère.
                    Aucun paiement n'est requis pour l'instant.
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <h4 className="font-medium">Choisissez votre option</h4>
          
          {/* Option 1: Payer sa part */}
          {teammateMode === 'account' && (
          <div 
            className={`p-4 rounded-lg border-2 transition-all cursor-pointer hover:border-primary/50 ${
              selectedOption === 'half' ? 'border-primary bg-primary/5' : 'border-border'
            }`}
            onClick={() => !isProcessing && setSelectedOption('half')}
          >
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 shrink-0">
                <Share2 className="h-6 w-6 text-accent" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h5 className="font-semibold">Je paye ma part</h5>
                  <Badge variant="secondary" className="text-lg px-3 py-1 bg-accent/10 text-accent">
                    {halfPrice}€
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Vous payez votre inscription (prix organisateur + frais Padel Cup) et un lien de paiement sera envoyé à{' '}
                  <strong>{teammate.first_name}</strong> pour régler sa part.
                </p>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span>Lien de paiement envoyé à {teammate.email}</span>
                </div>
              </div>
            </div>
          </div>
          )}

          {/* Option 2: Payer la totalité */}
          <div 
            className={`p-4 rounded-lg border-2 transition-all cursor-pointer hover:border-primary/50 ${
              selectedOption === 'full' ? 'border-primary bg-primary/5' : 'border-border'
            }`}
            onClick={() => !isProcessing && setSelectedOption('full')}
          >
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-success/10 shrink-0">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h5 className="font-semibold">Je paye la totalité</h5>
                  <Badge variant="success" className="text-lg px-3 py-1">
                    {fullPrice}€
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Vous réglez l'intégralité (2 joueurs) et <strong>{teammate.first_name}</strong>{' '}
                  recevra une invitation au tournoi par email.
                </p>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span>
                    "{player.first_name} vous a invité au tournoi {tournamentTitle}"
                  </span>
                </div>
              </div>
            </div>
          </div>
          </div>
        )}

        {/* Boutons d'action */}
        <div className="flex gap-3 pt-2">
          <Button 
            variant="outline" 
            onClick={onBack} 
            className="flex-1"
            disabled={isProcessing}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour
          </Button>
          
          {isWaitlist ? (
            <Button 
              onClick={handlePayFull} 
              className="flex-1"
              disabled={isProcessing}
              variant="default"
            >
              {isProcessing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Clock className="mr-2 h-4 w-4" />
              )}
              S'inscrire en liste d'attente
            </Button>
          ) : (
            <>
              {selectedOption === 'half' && (
                <Button 
                  onClick={handlePayHalf} 
                  className="flex-1"
                  disabled={isProcessing}
                  variant="accent"
                >
                  {isProcessing ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Euro className="mr-2 h-4 w-4" />
                  )}
                  Payer {halfPrice}€
                </Button>
              )}
              
              {selectedOption === 'full' && (
                <Button 
                  onClick={handlePayFull} 
                  className="flex-1"
                  disabled={isProcessing}
                  variant="success"
                >
                  {isProcessing ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <CreditCard className="mr-2 h-4 w-4" />
                  )}
                  Payer {fullPrice}€
                </Button>
              )}
              
              {!selectedOption && (
                <Button className="flex-1" disabled>
                  Sélectionnez une option
                </Button>
              )}
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
