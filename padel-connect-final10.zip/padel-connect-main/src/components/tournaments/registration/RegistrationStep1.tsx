import { useState } from 'react';
import { Link } from 'react-router-dom';
import { PlayerProfile } from '@/contexts/PlayerAuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { isValidFftLicenseNumber } from '@/lib/license';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { User, CreditCard, Mail, Phone, CheckCircle, ArrowRight, AlertTriangle } from 'lucide-react';

interface RegistrationStep1Props {
  player: PlayerProfile;
  hasLicense: boolean;
  setHasLicense: (value: boolean) => void;
  onNext: () => void;
  licenseRequired?: boolean;
}

export function RegistrationStep1({ player, hasLicense, setHasLicense, onNext, licenseRequired = false }: RegistrationStep1Props) {
  const fullName = `${player.first_name} ${player.last_name}`;
  const [licenseAnswered, setLicenseAnswered] = useState(false);
  const [selectedValue, setSelectedValue] = useState<string | undefined>(undefined);
  const licenseOk = isValidFftLicenseNumber(player.license_number);

  const handleLicenseChange = (value: string) => {
    setSelectedValue(value);
    setHasLicense(value === 'yes');
    setLicenseAnswered(true);
  };

  const handleNext = async () => {
    if (licenseRequired && !licenseOk) return;
    onNext();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
            1
          </div>
          <div>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Vos informations
            </CardTitle>
            <CardDescription>Vérifiez vos informations de joueur</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 bg-muted/50 rounded-lg border border-border">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle className="h-5 w-5 text-success" />
            <span className="font-medium text-success">Compte vérifié</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            <div className="space-y-2">
              <Label className="text-muted-foreground text-sm">Numéro de licence</Label>
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <Input 
                  value={player.license_number || 'Non renseigné'} 
                  disabled 
                  className="bg-background"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground text-sm">Nom complet</Label>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <Input 
                  value={fullName} 
                  disabled 
                  className="bg-background"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground text-sm">Téléphone</Label>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <Input 
                  value={player.phone || 'Non renseigné'} 
                  disabled 
                  className="bg-background"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground text-sm">Email</Label>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <Input 
                  value={player.email} 
                  disabled 
                  className="bg-background"
                />
              </div>
            </div>
          </div>

          {player.ranking && (
            <div className="mt-4 flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Classement:</span>
              <Badge variant="secondary">{player.ranking}</Badge>
            </div>
          )}
        </div>

        {/* FFT license requirement */}
        {licenseRequired && !licenseOk && (
          <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-destructive">Licence FFT obligatoire pour ce tournoi</p>
                <p className="text-xs text-muted-foreground">
                  Renseignez un numéro de licence FFT valide dans votre profil (format : 7 chiffres + 1 lettre, ex: 1234567A).
                </p>
                <div className="mt-3">
                  <Button asChild variant="outline" size="sm">
                    {/* Player profile is edited from the dashboard */}
                    <Link to="/player/dashboard">Compléter mon profil</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {licenseRequired && !licenseOk && (
          <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-destructive">Ce tournoi nécessite une licence FFT valide</p>
                <p className="text-xs text-muted-foreground">
                  Pour vous inscrire, renseignez votre numéro de licence dans votre profil (format : 7 chiffres + 1 lettre).
                </p>
                <Button asChild variant="outline" className="mt-3">
                  {/* Player profile is edited from the dashboard */}
                  <Link to="/player/dashboard">Compléter mon profil</Link>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* License question - only show if no license number in profile */}
        {!licenseRequired && !player.license_number && (
          <div className="p-4 rounded-lg border border-border bg-background">
            <Label className="text-base font-medium mb-3 block">
              Possédez-vous une licence FFT ? *
            </Label>
            <RadioGroup 
              value={selectedValue}
              onValueChange={handleLicenseChange}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="license-yes" />
                <Label htmlFor="license-yes" className="font-normal cursor-pointer">Oui</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="license-no" />
                <Label htmlFor="license-no" className="font-normal cursor-pointer">Non</Label>
              </div>
            </RadioGroup>
            
            {licenseAnswered && selectedValue === 'no' && (
              <div className="mt-3 p-3 rounded-lg bg-warning/10 border border-warning/20">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-warning">Attention</p>
                    <p className="text-xs text-muted-foreground">
                      Vous serez signalé comme joueur sans licence auprès de l'organisateur. 
                      Une licence peut être requise pour participer à certains tournois.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <Button 
          onClick={handleNext} 
          className="w-full" 
          size="lg"
          disabled={(licenseRequired && !licenseOk) || (!licenseRequired && !player.license_number && !licenseAnswered)}
        >
          Continuer
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );
}
