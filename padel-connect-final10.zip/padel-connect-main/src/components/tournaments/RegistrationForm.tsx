import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Users } from 'lucide-react';

interface RegistrationFormProps {
  tournamentId: string;
  tournamentTitle: string;
  onSuccess?: () => void;
}

export function RegistrationForm({ tournamentId, tournamentTitle, onSuccess }: RegistrationFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    team_name: '',
    player1_name: '',
    player1_email: '',
    player2_name: '',
    player2_email: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: "Inscription réussie !",
      description: `Votre équipe "${formData.team_name || 'Sans nom'}" est inscrite au tournoi.`,
    });

    setFormData({
      team_name: '',
      player1_name: '',
      player1_email: '',
      player2_name: '',
      player2_email: '',
    });

    setIsSubmitting(false);
    onSuccess?.();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Inscription
        </CardTitle>
        <CardDescription>
          Inscrivez votre équipe au {tournamentTitle}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="team_name">Nom de l'équipe (optionnel)</Label>
            <Input
              id="team_name"
              value={formData.team_name}
              onChange={(e) => setFormData({ ...formData, team_name: e.target.value })}
              placeholder="Les Champions"
            />
          </div>

          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground">Joueur 1</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="player1_name">Nom complet *</Label>
                <Input
                  id="player1_name"
                  required
                  value={formData.player1_name}
                  onChange={(e) => setFormData({ ...formData, player1_name: e.target.value })}
                  placeholder="Jean Dupont"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="player1_email">Email *</Label>
                <Input
                  id="player1_email"
                  type="email"
                  required
                  value={formData.player1_email}
                  onChange={(e) => setFormData({ ...formData, player1_email: e.target.value })}
                  placeholder="jean@email.com"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground">Joueur 2</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="player2_name">Nom complet *</Label>
                <Input
                  id="player2_name"
                  required
                  value={formData.player2_name}
                  onChange={(e) => setFormData({ ...formData, player2_name: e.target.value })}
                  placeholder="Pierre Martin"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="player2_email">Email *</Label>
                <Input
                  id="player2_email"
                  type="email"
                  required
                  value={formData.player2_email}
                  onChange={(e) => setFormData({ ...formData, player2_email: e.target.value })}
                  placeholder="pierre@email.com"
                />
              </div>
            </div>
          </div>

          <Button type="submit" variant="accent" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? 'Inscription en cours...' : "Valider l'inscription"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
