import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { usePlayerAuth } from '@/contexts/PlayerAuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { RegistrationStepper } from './registration/RegistrationStepper';
import { RegistrationStep1 } from './registration/RegistrationStep1';
import { RegistrationStep2 } from './registration/RegistrationStep2';
import { RegistrationStep3 } from './registration/RegistrationStep3';
import { format, parseISO, setHours, setMinutes, subHours } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Users, LogIn, CheckCircle, Trophy, AlertCircle, Clock } from 'lucide-react';
import { isValidFftLicenseNumber } from '@/lib/license';

interface TeammateInfo {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  license_number: string | null;
}

interface MultiStepRegistrationFormProps {
  tournamentId: string;
  tournamentTitle: string;
  tournamentPrice?: number;
  onSuccess?: () => void;
}

const REGISTRATION_STEPS = [
  { label: 'Vos infos', description: 'Vérification' },
  { label: 'Coéquipier', description: 'Validation' },
  { label: 'Paiement', description: 'Finalisation' },
];

export function MultiStepRegistrationForm({
  tournamentId,
  tournamentTitle,
  tournamentPrice = 40,
  onSuccess,
}: MultiStepRegistrationFormProps) {
  const { player, isAuthenticated, isLoading } = usePlayerAuth();
  const { toast } = useToast();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [teammateMode, setTeammateMode] = useState<'account' | 'manual'>('account');
  const [teammateEmail, setTeammateEmail] = useState('');
  const [teammate, setTeammate] = useState<TeammateInfo | null>(null);
  const [manualTeammateFirstName, setManualTeammateFirstName] = useState('');
  const [manualTeammateLastName, setManualTeammateLastName] = useState('');
  const [manualTeammateLicense, setManualTeammateLicense] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [registeredTeamId, setRegisteredTeamId] = useState<string | null>(null);
  const [alreadyRegistered, setAlreadyRegistered] = useState(false);
  const [tournamentFull, setTournamentFull] = useState(false);
  const [maxTeams, setMaxTeams] = useState(16);
  const [allowOnSiteLicense, setAllowOnSiteLicense] = useState(false);
  const [currentTeams, setCurrentTeams] = useState(0);
  const [checkingStatus, setCheckingStatus] = useState(true);
  const [player1HasLicense, setPlayer1HasLicense] = useState(true);
  const [player2HasLicense, setPlayer2HasLicense] = useState(true);
  const [registrationClosed, setRegistrationClosed] = useState(false);
  const [registrationDeadline, setRegistrationDeadline] = useState<Date | null>(null);

  // Check if player is already registered and if tournament is full
  useEffect(() => {
    const checkStatus = async () => {
      // Defensive guards: during initial renders, tournamentId/player can be temporarily undefined.
      // Querying Supabase with an undefined tournamentId can lead to a false-positive "already registered"
      // because the tournament_id filter may not be applied as expected.
      if (!tournamentId) {
        setCheckingStatus(false);
        return;
      }

      if (!player) {
        setCheckingStatus(false);
        return;
      }

      const normalizedEmail = (player.email || '').trim().toLowerCase();
      // If we don't have a usable email, we cannot reliably check duplicates.
      // An empty value can lead to unexpected matches depending on how filters are parsed.
      if (!normalizedEmail || !normalizedEmail.includes('@')) {
        setCheckingStatus(false);
        return;
      }

      // Reset on re-check
      setAlreadyRegistered(false);

      // Check if already registered (DB schema uses tournament_teams with player1_email/player2_email)
      // Use ILIKE for case-insensitive exact match.
      const { data: existingTeam } = await supabase
        .from('tournament_teams')
        .select('id')
        .eq('tournament_id', tournamentId)
        .or(`player1_email.ilike.${normalizedEmail},player2_email.ilike.${normalizedEmail}`)
        .limit(1)
        .maybeSingle();

      if (existingTeam?.id) {
        setAlreadyRegistered(true);
      }
// Check tournament capacity
      const { data: tournament } = await supabase
        .from('club_tournaments')
        .select('max_teams, start_date, allow_on_site_license')
        .eq('id', tournamentId)
        .single();

      if (tournament) {
        setMaxTeams(tournament.max_teams || 16);
        setAllowOnSiteLicense(!!(tournament as any).allow_on_site_license);
        // Registration closes 15 hours before tournament start
        // Par défaut : heure de début 09:00 (la DB ne stocke pas l'heure).
        if (tournament.start_date) {
          const start = tournament.start_date ? new Date(`${tournament.start_date}T09:00:00`) : null;
          const deadline = start ? subHours(start, 15) : null;
          if (deadline) {
            setRegistrationDeadline(deadline);
            setRegistrationClosed(new Date() > deadline);
          }
        }
      }

      const { count } = await supabase
        .from('tournament_teams')
        .select('*', { count: 'exact', head: true })
        .eq('tournament_id', tournamentId)
        .eq('status', 'confirmed');

      setCurrentTeams(count || 0);
      if (tournament && count !== null && count >= (tournament.max_teams || 16)) {
        setTournamentFull(true);
      }

      setCheckingStatus(false);
    };

    checkStatus();
  }, [player, tournamentId]);

  // Loading state
  if (isLoading || checkingStatus) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4" />
            <p className="text-muted-foreground">Chargement...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  
  // Registration closed (15h before start)
  if (registrationClosed && registrationDeadline) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Inscriptions fermées
          </CardTitle>
          <CardDescription>
            Les inscriptions sont clôturées 15h avant le début du tournoi.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-lg border bg-muted/30 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="font-medium">Clôture des inscriptions</p>
              <p className="text-sm text-muted-foreground">
                Date limite : {format(registrationDeadline, "d MMMM yyyy 'à' HH:mm", { locale: fr })}
              </p>
            </div>
          </div>
          <Button variant="outline" asChild className="w-full">
            <Link to="/tournaments">Retour aux tournois</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

// Already registered state
  if (alreadyRegistered) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Vous êtes déjà inscrit !</h3>
            <p className="text-muted-foreground mb-6">
              Vous êtes déjà inscrit à ce tournoi. Retrouvez vos inscriptions dans votre espace joueur.
            </p>
            <Button asChild>
              <Link to="/player/dashboard">Voir mes tournois</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Not logged in state
  if (!isAuthenticated || !player) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Inscription
          </CardTitle>
          <CardDescription>
            Connectez-vous pour vous inscrire à ce tournoi
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-6 text-center bg-muted/50 rounded-lg">
            <LogIn className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-semibold mb-2">Connexion requise</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Vous devez être connecté en tant que joueur pour vous inscrire à ce tournoi.
            </p>
            <div className="flex flex-col sm:flex-row gap-2 justify-center">
              <Button asChild>
                <Link to="/player/login">Se connecter</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/player/register">Créer un compte</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Registration complete state
  if (isComplete) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
            <h3 className="text-xl font-bold mb-2">Inscription confirmée !</h3>
            <p className="text-muted-foreground mb-6">
              Votre équipe est inscrite au tournoi <strong>{tournamentTitle}</strong>.
            </p>
            <div className="p-4 bg-muted/50 rounded-lg w-full max-w-sm">
              <div className="flex items-center gap-3 mb-3">
                <Trophy className="h-5 w-5 text-primary" />
                <span className="font-medium">Récapitulatif</span>
              </div>
              <div className="text-sm text-left space-y-1">
                <p><strong>Joueur 1:</strong> {player.first_name} {player.last_name}</p>
                {teammate && (
                  <p><strong>Joueur 2:</strong> {teammate.first_name} {teammate.last_name}</p>
                )}
              </div>
            </div>
            <Button className="mt-6" asChild>
              <Link to="/player/dashboard">Voir mes tournois</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const saveRegistration = async (paymentType: 'half' | 'full', isWaitlist: boolean = false) => {
    if (!player) return null;
    if (teammateMode === 'account' && !teammate) return null;

    // Manual teammate: organiser pays 100% (no split payment)
    if (teammateMode === 'manual' && paymentType === 'half') {
      toast({
        variant: 'destructive',
        title: 'Paiement partagé indisponible',
        description: "En renseignant les informations du coéquipier (sans compte), vous devez payer la totalité.",
      });
      return null;
    }

    // Duplicate protection is handled below:
    // - if an existing team is found for this player in this tournament, we UPDATE it
    // - if a conflicting team exists (different pairing), DB UNIQUE constraints will block and we surface a clear message

    const p2First = teammateMode === 'account' ? teammate!.first_name : manualTeammateFirstName;
    const p2Last = teammateMode === 'account' ? teammate!.last_name : manualTeammateLastName;
    const p2Email = teammateMode === 'account' ? teammate!.email : null;
    const teamName = `${player.first_name} ${player.last_name} / ${p2First} ${p2Last}`;
    
    // Set status: waiting = no slot yet, pending = slot reserved but not fully paid, confirmed = fully paid
    if (teammateMode === 'manual' && paymentType === 'half') {
      toast({ variant: 'destructive', title: 'Paiement', description: "En mode 'Renseigner ses infos', vous devez payer en totalité." });
      return null;
    }

    // DB uses team_status enum: confirmed | waiting
    // A team is only confirmed when BOTH players have paid.
    const status = (paymentType === 'full' && !isWaitlist) ? 'confirmed' : 'waiting';

    // Determine license status based on profile data and user answers
    const p1License = player.license_number ? true : player1HasLicense;
    const p2License = teammateMode === 'account'
      ? (!!teammate!.license_number || player2HasLicense)
      : (isValidFftLicenseNumber(manualTeammateLicense) || player2HasLicense);

    if (registrationClosed) {
      toast({
        variant: 'destructive',
        title: 'Inscriptions fermées',
        description: "Les inscriptions sont clôturées 15h avant le début du tournoi.",
      });
      return;
    }

    // 1) Create OR update the team in tournament_teams
    // If a team already exists for this player in this tournament, we must UPDATE (payment, license, names)
    // and never INSERT again (otherwise you hit UNIQUE constraints and 400 errors).

    const { data: existingTeam, error: existingTeamError } = await supabase
      .from('tournament_teams')
      .select('*')
      .eq('tournament_id', tournamentId)
      .or(`player1_email.ilike.${player.email},player2_email.ilike.${player.email}`)
      .maybeSingle();

    if (existingTeamError) {
      console.error('Error checking existing team:', existingTeamError);
    }

    // If a team exists for this player, ensure the pairing matches the teammate currently selected.
    // This avoids accidentally paying/updating a different pairing.
    if (existingTeam && teammateMode === 'account' && p2Email) {
      const otherEmail = ((existingTeam.player1_email || '').toLowerCase() === (player.email || '').toLowerCase())
        ? (existingTeam.player2_email || '')
        : (existingTeam.player1_email || '');

      if (otherEmail && otherEmail.toLowerCase() !== p2Email.toLowerCase()) {
        toast({
          variant: 'destructive',
          title: 'Inscription impossible',
          description: `Vous êtes déjà inscrit à ce tournoi avec un autre partenaire (${otherEmail}).`,
        });
        return null;
      }
    }

    const computeStatusFromPayments = (p1: string, p2: string) => {
      return (p1 === 'paid' && p2 === 'paid') ? 'confirmed' : 'waiting';
    };

    let teamData: any | null = null;
    let createdNewTeam = false;

    if (existingTeam) {
      const isCurrentPlayer1 = (existingTeam.player1_email || '').toLowerCase() === (player.email || '').toLowerCase();

      const nextP1Payment = paymentType === 'full'
        ? 'paid'
        : (isCurrentPlayer1 ? 'paid' : (existingTeam.player1_payment_status || 'pending'));

      const nextP2Payment = paymentType === 'full'
        ? 'paid'
        : (!isCurrentPlayer1 ? 'paid' : (existingTeam.player2_payment_status || 'pending'));

      const nextStatus = computeStatusFromPayments(nextP1Payment, nextP2Payment);

      const updatePayload: any = {
        // keep tournament_id the same
        name: existingTeam.name || teamName,
        // keep the stored pairing, but update license flags and payment statuses
        player1_has_license: existingTeam.player1_has_license ?? p1License,
        player2_has_license: existingTeam.player2_has_license ?? p2License,
        player1_payment_status: nextP1Payment,
        player2_payment_status: nextP2Payment,
        status: nextStatus,
        updated_at: new Date().toISOString(),
      };

      // If teammate is selected now and missing on existing team (rare), fill in.
      if (!existingTeam.player2_email && p2Email) {
        updatePayload.player2_email = p2Email;
        updatePayload.player2_name = `${p2First} ${p2Last}`;
      }

      const { data: updatedTeam, error: updateError } = await supabase
        .from('tournament_teams')
        .update(updatePayload)
        .eq('id', existingTeam.id)
        .select()
        .single();

      if (updateError) {
        console.error('Error updating team:', updateError);
        toast({
          variant: 'destructive',
          title: 'Erreur',
          description: "Impossible de mettre à jour l'inscription. Veuillez réessayer.",
        });
        return null;
      }

      teamData = updatedTeam;
    } else {
      // When paying half: only the current player is marked as paid
      // When paying full: both are marked as paid
      const { data: createdTeam, error: teamError } = await supabase
        .from('tournament_teams')
        .insert({
          tournament_id: tournamentId,
          name: teamName,
          player1_name: `${player.first_name} ${player.last_name}`,
          player1_email: player.email,
          player2_name: `${p2First} ${p2Last}`,
          player2_email: p2Email,
          status: status,
          player1_has_license: p1License,
          player2_has_license: p2License,
          player1_payment_status: isWaitlist ? 'pending' : 'paid', // current player pays when registering
          player2_payment_status: paymentType === 'full' ? 'paid' : 'pending',
        })
        .select()
        .single();

      if (teamError) {
        console.error('Error creating team:', teamError);
        const code = (teamError as any)?.code as string | undefined;
        if (code === '23505') {
          toast({
            variant: 'destructive',
            title: 'Inscription impossible',
            description: "Une inscription existe déjà pour ce tournoi (vous ou votre partenaire).",
          });
          return null;
        }
        toast({
          variant: 'destructive',
          title: 'Erreur',
          description: "Impossible de créer l'inscription. Veuillez réessayer.",
        });
        return null;
      }

      teamData = createdTeam;
      createdNewTeam = true;
    }

    return teamData;
};

  const handlePayHalf = async () => {
    const team = await saveRegistration('half', tournamentFull);
    
    if (team) {
      setRegisteredTeamId(team.id);
      
      if (tournamentFull) {
        toast({
          title: 'Inscription en liste d\'attente',
          description: `Vous serez contacté si une place se libère.`,
        });
      } else {
        toast({
          title: 'Inscription enregistrée',
          description: `Un lien de paiement sera envoyé à ${teammate?.email}`,
        });
      }
      
      setIsComplete(true);
      onSuccess?.();
    }
  };

  const handlePayFull = async () => {
    const team = await saveRegistration('full', tournamentFull);
    
    if (team) {
      setRegisteredTeamId(team.id);
      
      if (tournamentFull) {
        toast({
          title: 'Inscription en liste d\'attente',
          description: `Vous serez contacté si une place se libère.`,
        });
      } else {
        toast({
          title: 'Inscription confirmée',
          description: `${teammate?.first_name} recevra une invitation au tournoi.`,
        });
      }
      
      setIsComplete(true);
      onSuccess?.();
    }
  };

  const handleJoinWaitlist = async () => {
    const team = await saveRegistration('full', true);
    
    if (team) {
      setRegisteredTeamId(team.id);
      
      toast({
        title: 'Ajouté à la liste d\'attente',
        description: 'Vous serez contacté si une place se libère.',
      });
      
      setIsComplete(true);
      onSuccess?.();
    }
  };

  return (
    <div className="space-y-6">
      {/* Tournament full warning */}
      {tournamentFull && (
        <Card className="border-warning bg-warning/5">
          <CardContent className="py-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-warning shrink-0" />
              <div>
                <p className="font-medium text-warning">Tournoi complet</p>
                <p className="text-sm text-muted-foreground">
                  Ce tournoi est complet ({currentTeams}/{maxTeams} équipes). 
                  Vous pouvez vous inscrire sur liste d'attente.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <RegistrationStepper currentStep={currentStep} steps={REGISTRATION_STEPS} />

      {currentStep === 1 && (
        <RegistrationStep1
          player={player}
          hasLicense={player1HasLicense}
          setHasLicense={setPlayer1HasLicense}
          licenseRequired={!allowOnSiteLicense}
          onNext={() => setCurrentStep(2)}
        />
      )}

      {currentStep === 2 && (
        <RegistrationStep2
          currentPlayer={player}
          teammateMode={teammateMode}
          setTeammateMode={setTeammateMode}
          teammateEmail={teammateEmail}
          setTeammateEmail={setTeammateEmail}
          teammate={teammate}
          setTeammate={setTeammate}
          manualTeammateFirstName={manualTeammateFirstName}
          setManualTeammateFirstName={setManualTeammateFirstName}
          manualTeammateLastName={manualTeammateLastName}
          setManualTeammateLastName={setManualTeammateLastName}
          manualTeammateLicense={manualTeammateLicense}
          setManualTeammateLicense={setManualTeammateLicense}
          teammateHasLicense={player2HasLicense}
          setTeammateHasLicense={setPlayer2HasLicense}
          licenseRequired={!allowOnSiteLicense}
          onNext={() => setCurrentStep(3)}
          onBack={() => setCurrentStep(1)}
        />
      )}

      {currentStep === 3 && (teammateMode === 'manual' || !!teammate) && (
        <RegistrationStep3
          player={player}
          teammate={
            teammateMode === 'account'
              ? teammate!
              : ({
                  id: 'manual',
                  first_name: manualTeammateFirstName || 'Coéquipier',
                  last_name: manualTeammateLastName || '',
                  email: '',
                  license_number: manualTeammateLicense || null,
                } as any)
          }
          teammateMode={teammateMode}
          tournamentTitle={tournamentTitle}
          tournamentPrice={tournamentPrice}
          onBack={() => setCurrentStep(2)}
          onPayHalf={tournamentFull ? handleJoinWaitlist : handlePayHalf}
          onPayFull={tournamentFull ? handleJoinWaitlist : handlePayFull}
          isWaitlist={tournamentFull}
        />
      )}
    </div>
  );
}