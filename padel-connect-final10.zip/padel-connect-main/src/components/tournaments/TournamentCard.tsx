import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tournament } from '@/types';
import { Calendar, MapPin, Users, Trophy } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface TournamentCardProps {
  tournament: Tournament;
}

export function TournamentCard({ tournament }: TournamentCardProps) {
  const isExternal = tournament.club_id === null;
  const isPlatformManaged = tournament.is_managed_by_platform;

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'P25': 'bg-success/10 text-success',
      'P50': 'bg-secondary/10 text-secondary-foreground',
      'P100': 'bg-primary/10 text-primary',
      'P250': 'bg-accent/10 text-accent',
    };
    return colors[category] || 'bg-muted text-muted-foreground';
  };

  const getGenderLabel = (gender: string) => {
    const labels: Record<string, string> = {
      'H': 'Hommes',
      'F': 'Femmes',
      'Mixte': 'Mixte',
    };
    return labels[gender] || gender;
  };

  return (
    <Link to={`/tournaments/${tournament.id}`}>
      <Card hover className="h-full overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex flex-wrap gap-2">
              <Badge className={getCategoryColor(tournament.category_code)}>
                {tournament.category_code}
              </Badge>
              <Badge variant="outline" className="text-xs">
                {getGenderLabel(tournament.gender)}
              </Badge>
            </div>
            {isExternal ? (
              <Badge variant="external" className="text-xs shrink-0">
                Externe
              </Badge>
            ) : isPlatformManaged ? (
              <Badge variant="platform" className="text-xs shrink-0">
                Plateforme
              </Badge>
            ) : null}
          </div>
          <CardTitle className="line-clamp-2">{tournament.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0" />
            <span className="truncate">{tournament.city}, {tournament.region}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4 shrink-0" />
            <span>
              {format(new Date(tournament.start_date), 'd MMM', { locale: fr })}
              {tournament.start_date !== tournament.end_date && (
                <> - {format(new Date(tournament.end_date), 'd MMM yyyy', { locale: fr })}</>
              )}
              {tournament.start_date === tournament.end_date && (
                <> {format(new Date(tournament.start_date), 'yyyy', { locale: fr })}</>
              )}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4 shrink-0" />
            <span>
              {tournament.registrations_count !== undefined ? (
                <>{tournament.registrations_count} / {tournament.max_teams} équipes</>
              ) : (
                <>{tournament.max_teams} équipes max</>
              )}
            </span>
          </div>
          {tournament.club && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2 border-t">
              <Trophy className="h-4 w-4 shrink-0" />
              <span className="truncate">{tournament.club.name}</span>
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
