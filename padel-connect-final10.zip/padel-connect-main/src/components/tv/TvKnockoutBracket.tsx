import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Trophy } from 'lucide-react';
import { TournamentTeam, GeneratedMatch } from '@/types/tournament';
import { cn } from '@/lib/utils';

type Line = { x1: number; y1: number; x2: number; y2: number };

export function TvKnockoutBracket({
  matches,
  teams,
  className,
}: {
  matches: GeneratedMatch[];
  teams: TournamentTeam[];
  className?: string;
}) {
  const rounds = useMemo(() => {
    const byRound = new Map<number, GeneratedMatch[]>();
    matches
      .filter((m) => !m.is_bye)
      .forEach((m) => {
        const r = m.round_order ?? 0;
        byRound.set(r, [...(byRound.get(r) ?? []), m]);
      });
    return Array.from(byRound.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([r, ms]) => ({
        round: r,
        matches: ms.sort((a, b) => (a.match_order ?? 0) - (b.match_order ?? 0)),
      }));
  }, [matches]);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const elMapRef = useRef<Map<string, HTMLElement>>(new Map());
  const [lines, setLines] = useState<Line[]>([]);

  const setEl = (key: string) => (el: HTMLElement | null) => {
    if (!el) {
      elMapRef.current.delete(key);
      return;
    }
    elMapRef.current.set(key, el);
  };

  const recompute = () => {
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const newLines: Line[] = [];

    for (const col of rounds) {
      const next = rounds.find((r) => r.round === col.round + 1);
      if (!next) continue;

      col.matches.forEach((m, idx) => {
        const fromKey = `r${col.round}-m${idx}`;
        const toKey = `r${col.round + 1}-m${Math.floor(idx / 2)}`;
        const fromEl = elMapRef.current.get(fromKey);
        const toEl = elMapRef.current.get(toKey);
        if (!fromEl || !toEl) return;

        const a = fromEl.getBoundingClientRect();
        const b = toEl.getBoundingClientRect();
        const x1 = a.right - rect.left;
        const y1 = a.top - rect.top + a.height / 2;
        const x2 = b.left - rect.left;
        const y2 = b.top - rect.top + b.height / 2;
        newLines.push({ x1, y1, x2, y2 });
      });
    }

    setLines(newLines);
  };

  useLayoutEffect(() => {
    recompute();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rounds]);

  useEffect(() => {
    const onResize = () => recompute();
    window.addEventListener('resize', onResize);
    const id = window.setInterval(recompute, 1500); // keep stable on TV (font swap / zoom / fullscreen)
    return () => {
      window.removeEventListener('resize', onResize);
      window.clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rounds]);

  const getTeam = (id?: string) => (id ? teams.find((t) => t.id === id) : undefined);

  return (
    <div ref={containerRef} className={cn('relative w-full overflow-x-auto', className)}>
      <svg className="pointer-events-none absolute inset-0" width="100%" height="100%">
        {lines.map((l, i) => (
          <path
            key={i}
            d={`M ${l.x1} ${l.y1} L ${l.x1 + 20} ${l.y1} L ${l.x1 + 20} ${l.y2} L ${l.x2} ${l.y2}`}
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            opacity={0.25}
          />
        ))}
      </svg>

      <div className="flex gap-10 p-6 min-w-[900px]">
        {rounds.map((col) => {
          const gap = 20 * Math.pow(2, col.round);
          const padTop = col.round === 0 ? 0 : gap / 2;
          return (
            <div key={col.round} className="flex flex-col" style={{ gap, paddingTop: padTop }}>
              {col.matches.map((m, idx) => {
                const a = getTeam(m.team_a_id);
                const b = getTeam(m.team_b_id);
                const winnerA = !!m.winner_id && m.winner_id === m.team_a_id;
                const winnerB = !!m.winner_id && m.winner_id === m.team_b_id;
                return (
                  <div
                    key={m.id || `${col.round}-${idx}`}
                    ref={setEl(`r${col.round}-m${idx}`)}
                    className="w-[280px] rounded-xl border bg-background/80 backdrop-blur px-4 py-3 shadow-sm"
                  >
                    <div className="text-xs text-muted-foreground mb-2">{m.round_name || (col.round === rounds.length - 1 ? 'Finale' : `Tour ${col.round + 1}`)}</div>

                    <div className={cn('flex items-center justify-between gap-2 rounded-lg px-2 py-1.5', winnerA ? 'bg-primary/15' : 'bg-muted/40')}>
                      <div className="min-w-0">
                        <div className="truncate font-semibold text-sm">{a?.name ?? 'TBD'}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        {winnerA && <Trophy className="h-4 w-4 text-primary" />}
                        <div className="text-xs font-mono text-muted-foreground">{m.score_a ?? ''}</div>
                      </div>
                    </div>

                    <div className={cn('mt-2 flex items-center justify-between gap-2 rounded-lg px-2 py-1.5', winnerB ? 'bg-primary/15' : 'bg-muted/40')}>
                      <div className="min-w-0">
                        <div className="truncate font-semibold text-sm">{b?.name ?? 'TBD'}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        {winnerB && <Trophy className="h-4 w-4 text-primary" />}
                        <div className="text-xs font-mono text-muted-foreground">{m.score_b ?? ''}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}
