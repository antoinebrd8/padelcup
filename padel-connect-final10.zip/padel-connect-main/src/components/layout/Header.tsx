import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { usePlayerAuth } from '@/contexts/PlayerAuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Menu, X, LogOut, Plus } from 'lucide-react';
import { useState } from 'react';
import { ChampionsPadelLogo } from '@/components/home/ChampionsPadelLogo';

export function Header() {
  const navigate = useNavigate();
  const { isAuthenticated: isClubAuthenticated, logout: clubLogout } = useAuth();
  const { isAuthenticated: isPlayerAuthenticated, player } = usePlayerAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const isAuthenticated = isClubAuthenticated || isPlayerAuthenticated;

  const handleLogout = async () => {
    if (isClubAuthenticated) {
      await clubLogout();
    } else if (isPlayerAuthenticated) {
      await supabase.auth.signOut();
    }
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background border-b">
      <div className="container flex h-20 items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <ChampionsPadelLogo size={56} />
        </Link>

        {/* Desktop Navigation - Only show when authenticated */}
        {isAuthenticated && (
          <nav className="hidden lg:flex items-center gap-4">
            <Link to="/tournaments">
              <Button variant="outline" size="lg" className="font-medium">
                Tous les tournois
              </Button>
            </Link>
            
            {/* Show "Créer un tournoi" only for club */}
            {isClubAuthenticated && (
              <Link to="/club/tournaments/create">
                <Button size="lg" className="bg-primary hover:bg-primary/90 font-medium">
                  <Plus className="h-4 w-4 mr-2" />
                  Créer un tournoi
                </Button>
              </Link>
            )}
          </nav>
        )}

        {/* Right side */}
        <div className="hidden lg:flex items-center gap-3">
          {isClubAuthenticated ? (
            <>
              <Link to="/club/dashboard">
                <Button size="lg" className="bg-primary hover:bg-primary/90 font-medium">
                  Mon espace
                </Button>
              </Link>
              <Button variant="outline" size="lg" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Déconnexion
              </Button>
            </>
          ) : isPlayerAuthenticated ? (
            <>
              <Link to="/player/dashboard">
                <Button size="lg" className="bg-primary hover:bg-primary/90 font-medium">
                  Mon espace
                </Button>
              </Link>
              <Button variant="outline" size="lg" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Déconnexion
              </Button>
            </>
          ) : (
            /* When not authenticated, show login buttons with emphasis */
            <div className="flex items-center gap-3">
              <Link to="/player/login">
                <Button variant="outline" size="lg" className="font-medium">
                  Connexion Joueur
                </Button>
              </Link>
              <Link to="/club/login">
                <Button size="lg" className="bg-primary hover:bg-primary/90 font-medium">
                  Espace Organisateur
                </Button>
              </Link>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden p-2 hover:bg-muted rounded-lg transition-colors"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label={isMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="lg:hidden border-t bg-background animate-slide-up">
          <nav className="container py-6 flex flex-col gap-2">
            {isAuthenticated && (
              <Link
                to="/tournaments"
                className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Tous les tournois
              </Link>
            )}
            
            {/* Show player dashboard if logged in as player */}
            {isPlayerAuthenticated && (
              <>
                <Link
                  to="/player/dashboard"
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Mon espace joueur
                </Link>
                <button
                  onClick={() => {
                    handleLogout();
                    setIsMenuOpen(false);
                  }}
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors text-left w-full text-destructive"
                >
                  Déconnexion
                </button>
              </>
            )}
            
            {/* Show club options if logged in as club */}
            {isClubAuthenticated && (
              <>
                <Link
                  to="/club/tournaments/create"
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Créer un tournoi
                </Link>
                <Link
                  to="/club/dashboard"
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Mon espace club
                </Link>
                <button
                  onClick={() => {
                    handleLogout();
                    setIsMenuOpen(false);
                  }}
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors text-left w-full text-destructive"
                >
                  Déconnexion
                </button>
              </>
            )}
            
            {/* Show login options when not authenticated */}
            {!isAuthenticated && (
              <>
                <Link
                  to="/player/login"
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Connexion Joueur
                </Link>
                <Link
                  to="/club/login"
                  className="px-4 py-3 text-sm font-medium hover:bg-muted rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Espace Organisateur
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
