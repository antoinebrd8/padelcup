import { ReactNode } from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { MobileBottomNav } from './MobileBottomNav';

interface LayoutProps {
  children: ReactNode;
  hideFooter?: boolean;
}

export function Layout({ children, hideFooter = false }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      {/* On mobile we keep space for the fixed bottom navigation */}
      <main className="flex-1 pb-28 md:pb-0">{children}</main>
      <MobileBottomNav />
      {/* Keep the classic footer on desktop only */}
      {!hideFooter && <Footer className="hidden md:block" />}
    </div>
  );
}
