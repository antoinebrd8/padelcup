import { Link } from 'react-router-dom';

interface FooterProps {
  className?: string;
}

export function Footer({ className }: FooterProps) {
  return (
    <footer className={`border-t bg-muted/30 ${className || ''}`.trim()}>
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <span className="font-display text-xl">Padel France</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              La plateforme de référence pour tous les tournois de padel en France.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Navigation</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/tournaments" className="hover:text-foreground transition-colors">
                  Tous les tournois
                </Link>
              </li>
              <li>
                <Link to="/club/register" className="hover:text-foreground transition-colors">
                  Devenir club partenaire
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Pour les clubs</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/club/login" className="hover:text-foreground transition-colors">
                  Espace club
                </Link>
              </li>
              <li>
                <Link to="/club/register" className="hover:text-foreground transition-colors">
                  Créer un compte
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>contact@padel-france.fr</li>
              <li>Paris, France</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Padel France. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}
