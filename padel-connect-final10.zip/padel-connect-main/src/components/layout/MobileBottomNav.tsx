import { NavLink, useLocation } from 'react-router-dom';
import { CalendarDays, Home, User, Building2 } from 'lucide-react';

const items = [
  { to: '/', label: 'Accueil', icon: Home },
  { to: '/tournaments', label: 'Tournois', icon: CalendarDays },
  { to: '/player/dashboard', label: 'Joueur', icon: User },
  { to: '/club/dashboard', label: 'Club', icon: Building2 },
];

export function MobileBottomNav() {
  const location = useLocation();

  // Hide on admin & live TV routes
  const hide =
    location.pathname.startsWith('/admin') ||
    location.pathname.startsWith('/live');

  if (hide) return null;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/75 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-screen-sm px-2">
        <div className="grid grid-cols-4">
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                [
                  'flex flex-col items-center justify-center gap-1 py-2 text-xs',
                  isActive ? 'text-primary' : 'text-muted-foreground',
                ].join(' ')
              }
            >
              <Icon className="h-5 w-5" />
              <span className="leading-none">{label}</span>
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}
