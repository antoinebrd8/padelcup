import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Calendar, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function HeroSearchBar() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (location) params.set('city', location);
    navigate(`/tournaments?${params.toString()}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="bg-background rounded-full shadow-lg border flex items-center overflow-hidden">
      {/* Search input */}
      <div className="flex items-center gap-3 px-6 py-4 flex-1 border-r border-border">
        <Search className="h-5 w-5 text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="Rechercher un tournoi"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          className="bg-transparent outline-none w-full text-sm placeholder:text-muted-foreground"
        />
      </div>

      {/* Date input */}
      <div className="hidden md:flex items-center gap-3 px-6 py-4 flex-1 border-r border-border cursor-pointer hover:bg-muted/50 transition-colors">
        <Calendar className="h-5 w-5 text-muted-foreground shrink-0" />
        <span className="text-sm text-muted-foreground">Ajouter des dates</span>
      </div>

      {/* Location input */}
      <div className="hidden sm:flex items-center gap-3 px-6 py-4 flex-1">
        <MapPin className="h-5 w-5 text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="Ajouter un lieu"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          onKeyDown={handleKeyDown}
          className="bg-transparent outline-none w-full text-sm placeholder:text-muted-foreground"
        />
      </div>

      {/* Search button */}
      <div className="p-2">
        <Button 
          onClick={handleSearch}
          className="rounded-full px-6 h-12"
        >
          Rechercher
        </Button>
      </div>
    </div>
  );
}
