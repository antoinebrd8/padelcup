import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TournamentFilters as FiltersType } from '@/types';
import { TournamentFilters } from '@/components/tournaments/TournamentFilters';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { SlidersHorizontal } from 'lucide-react';

export function HomeFilters() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState<FiltersType>({});
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [open, setOpen] = useState(false);

  // Handle search button click - navigate to tournaments with filters
  const handleSearch = () => {
    const params = new URLSearchParams();
    
    if (filters.region) params.set('region', filters.region);    if (filters.category) params.set('category', filters.category);
    if (filters.gender) params.set('gender', filters.gender);
    if (filters.start_date) params.set('start_date', filters.start_date);
    if (filters.end_date) params.set('end_date', filters.end_date);
    if (userLocation) {
      params.set('lat', userLocation.lat.toString());
      params.set('lng', userLocation.lng.toString());
      if (filters.max_distance) {
        params.set('max_distance', filters.max_distance.toString());
      }
    }
    
    navigate(`/tournaments?${params.toString()}`);
  };

  return (
    <>
      {/* Mobile: compact bar + drawer */}
      <div className="md:hidden">
        <div className="flex items-center gap-2 bg-background rounded-2xl border shadow-sm p-2">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="gap-2 h-11">
                <SlidersHorizontal className="h-4 w-4" />
                Filtres
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>Recherche</SheetTitle>
              </SheetHeader>
              <div className="mt-4">
                <TournamentFilters
                  filters={filters}
                  onFiltersChange={setFilters}
                  userLocation={userLocation}
                  onUserLocationChange={setUserLocation}
                  showSearchButton={true}
                  onSearch={() => {
                    setOpen(false);
                    handleSearch();
                  }}
                />
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex-1 text-sm text-muted-foreground truncate">
            {filters.region || 'Toutes régions'} · {filters.category || 'Tous niveaux'} · {filters.gender || 'Tous genres'}
          </div>

          <Button className="h-11" onClick={handleSearch}>
            Chercher
          </Button>
        </div>
      </div>

      {/* Desktop: full bar */}
      <div className="hidden md:block">
        <TournamentFilters
          filters={filters}
          onFiltersChange={setFilters}
          userLocation={userLocation}
          onUserLocationChange={setUserLocation}
          showSearchButton={true}
          onSearch={handleSearch}
        />
      </div>
    </>
  );
}
