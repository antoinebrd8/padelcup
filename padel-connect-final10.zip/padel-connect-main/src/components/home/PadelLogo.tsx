export function PadelLogo({ className = '' }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 280 100" 
      className={className}
      fill="currentColor"
    >
      {/* Modern padel racket with dynamic styling */}
      <defs>
        <linearGradient id="racketGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="currentColor" stopOpacity="1"/>
          <stop offset="100%" stopColor="currentColor" stopOpacity="0.7"/>
        </linearGradient>
        <linearGradient id="ballGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#84cc16"/>
          <stop offset="100%" stopColor="#65a30d"/>
        </linearGradient>
      </defs>
      
      <g>
        {/* Racket head - more elegant oval shape */}
        <ellipse 
          cx="70" 
          cy="42" 
          rx="42" 
          ry="32" 
          fill="none" 
          stroke="url(#racketGradient)" 
          strokeWidth="4"
        />
        
        {/* Inner frame */}
        <ellipse 
          cx="70" 
          cy="42" 
          rx="35" 
          ry="26" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="1.5"
          opacity="0.4"
        />
        
        {/* Racket grid pattern - horizontal */}
        <line x1="35" y1="32" x2="105" y2="32" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        <line x1="30" y1="42" x2="110" y2="42" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        <line x1="35" y1="52" x2="105" y2="52" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        
        {/* Racket grid pattern - vertical */}
        <line x1="50" y1="12" x2="50" y2="72" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        <line x1="70" y1="10" x2="70" y2="74" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        <line x1="90" y1="12" x2="90" y2="72" stroke="currentColor" strokeWidth="1.2" opacity="0.6"/>
        
        {/* Handle */}
        <rect x="63" y="72" width="14" height="22" rx="3" fill="currentColor"/>
        <rect x="65" y="74" width="10" height="4" rx="1" fill="hsl(var(--background))" opacity="0.3"/>
        <rect x="65" y="80" width="10" height="4" rx="1" fill="hsl(var(--background))" opacity="0.3"/>
        <rect x="65" y="86" width="10" height="4" rx="1" fill="hsl(var(--background))" opacity="0.3"/>
        
        {/* Main ball - lime green with dynamic effect */}
        <circle cx="140" cy="35" r="18" fill="url(#ballGradient)"/>
        <path 
          d="M128 25 Q140 35 128 45" 
          fill="none" 
          stroke="white" 
          strokeWidth="2.5"
          opacity="0.8"
        />
        <circle cx="134" cy="28" r="3" fill="white" opacity="0.5"/>
        
        {/* Secondary ball - smaller, in motion */}
        <circle cx="165" cy="58" r="10" fill="url(#ballGradient)" opacity="0.6"/>
        <path 
          d="M159 52 Q165 58 159 64" 
          fill="none" 
          stroke="white" 
          strokeWidth="1.5"
          opacity="0.6"
        />
        
        {/* Motion trails */}
        <path 
          d="M158 35 L175 35" 
          stroke="currentColor" 
          strokeWidth="3" 
          strokeLinecap="round"
          opacity="0.4"
        />
        <path 
          d="M160 42 L180 42" 
          stroke="currentColor" 
          strokeWidth="2.5" 
          strokeLinecap="round"
          opacity="0.3"
        />
        <path 
          d="M158 28 L172 28" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round"
          opacity="0.2"
        />
        
        {/* Text: PTF stylized */}
        <text 
          x="195" 
          y="55" 
          fontFamily="'Playfair Display', serif" 
          fontSize="36" 
          fontWeight="700"
          fontStyle="italic"
          fill="currentColor"
        >
          PTF
        </text>
      </g>
    </svg>
  );
}

export function PadelBallMarker({ className = '', size = 24 }: { className?: string; size?: number }) {
  return (
    <svg 
      viewBox="0 0 40 40" 
      className={className}
      width={size}
      height={size}
    >
      <defs>
        <linearGradient id="ballMarkerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#84cc16"/>
          <stop offset="100%" stopColor="#65a30d"/>
        </linearGradient>
        <filter id="ballShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.3"/>
        </filter>
      </defs>
      
      {/* Ball */}
      <circle 
        cx="20" 
        cy="18" 
        r="14" 
        fill="url(#ballMarkerGradient)"
        filter="url(#ballShadow)"
      />
      
      {/* Ball curve */}
      <path 
        d="M12 10 Q20 18 12 26" 
        fill="none" 
        stroke="white" 
        strokeWidth="2"
        opacity="0.8"
      />
      
      {/* Highlight */}
      <circle cx="14" cy="12" r="3" fill="white" opacity="0.4"/>
      
      {/* Pin point */}
      <path 
        d="M20 32 L20 38" 
        stroke="#65a30d" 
        strokeWidth="3" 
        strokeLinecap="round"
      />
      <circle cx="20" cy="38" r="2" fill="#65a30d"/>
    </svg>
  );
}
