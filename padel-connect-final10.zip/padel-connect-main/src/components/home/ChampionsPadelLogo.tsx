export function ChampionsPadelLogo({ className = '', size = 48 }: { className?: string; size?: number }) {
  return (
    <svg 
      viewBox="0 0 200 200" 
      className={className}
      width={size}
      height={size}
    >
      {/* Outer blue circle */}
      <circle cx="100" cy="100" r="98" fill="#1e3a5f" />
      
      {/* Inner red circle */}
      <circle cx="100" cy="100" r="68" fill="#dc2626" />
      
      {/* White border between circles */}
      <circle cx="100" cy="100" r="68" fill="none" stroke="white" strokeWidth="2" />
      
      {/* Left racket */}
      <g transform="translate(100, 95) rotate(-25)">
        {/* Racket head */}
        <ellipse cx="0" cy="-25" rx="22" ry="28" fill="white" />
        {/* Holes pattern - simplified grid */}
        <circle cx="-12" cy="-35" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-35" r="2" fill="#dc2626" />
        <circle cx="0" cy="-35" r="2" fill="#dc2626" />
        <circle cx="6" cy="-35" r="2" fill="#dc2626" />
        <circle cx="12" cy="-35" r="2" fill="#dc2626" />
        <circle cx="-12" cy="-28" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-28" r="2" fill="#dc2626" />
        <circle cx="0" cy="-28" r="2" fill="#dc2626" />
        <circle cx="6" cy="-28" r="2" fill="#dc2626" />
        <circle cx="12" cy="-28" r="2" fill="#dc2626" />
        <circle cx="-12" cy="-21" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-21" r="2" fill="#dc2626" />
        <circle cx="0" cy="-21" r="2" fill="#dc2626" />
        <circle cx="6" cy="-21" r="2" fill="#dc2626" />
        <circle cx="12" cy="-21" r="2" fill="#dc2626" />
        <circle cx="-9" cy="-14" r="2" fill="#dc2626" />
        <circle cx="-3" cy="-14" r="2" fill="#dc2626" />
        <circle cx="3" cy="-14" r="2" fill="#dc2626" />
        <circle cx="9" cy="-14" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-7" r="2" fill="#dc2626" />
        <circle cx="0" cy="-7" r="2" fill="#dc2626" />
        <circle cx="6" cy="-7" r="2" fill="#dc2626" />
        {/* Handle */}
        <rect x="-5" y="2" width="10" height="28" rx="3" fill="white" />
      </g>
      
      {/* Right racket */}
      <g transform="translate(100, 95) rotate(25)">
        {/* Racket head */}
        <ellipse cx="0" cy="-25" rx="22" ry="28" fill="white" />
        {/* Holes pattern */}
        <circle cx="-12" cy="-35" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-35" r="2" fill="#dc2626" />
        <circle cx="0" cy="-35" r="2" fill="#dc2626" />
        <circle cx="6" cy="-35" r="2" fill="#dc2626" />
        <circle cx="12" cy="-35" r="2" fill="#dc2626" />
        <circle cx="-12" cy="-28" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-28" r="2" fill="#dc2626" />
        <circle cx="0" cy="-28" r="2" fill="#dc2626" />
        <circle cx="6" cy="-28" r="2" fill="#dc2626" />
        <circle cx="12" cy="-28" r="2" fill="#dc2626" />
        <circle cx="-12" cy="-21" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-21" r="2" fill="#dc2626" />
        <circle cx="0" cy="-21" r="2" fill="#dc2626" />
        <circle cx="6" cy="-21" r="2" fill="#dc2626" />
        <circle cx="12" cy="-21" r="2" fill="#dc2626" />
        <circle cx="-9" cy="-14" r="2" fill="#dc2626" />
        <circle cx="-3" cy="-14" r="2" fill="#dc2626" />
        <circle cx="3" cy="-14" r="2" fill="#dc2626" />
        <circle cx="9" cy="-14" r="2" fill="#dc2626" />
        <circle cx="-6" cy="-7" r="2" fill="#dc2626" />
        <circle cx="0" cy="-7" r="2" fill="#dc2626" />
        <circle cx="6" cy="-7" r="2" fill="#dc2626" />
        {/* Handle */}
        <rect x="-5" y="2" width="10" height="28" rx="3" fill="white" />
      </g>
      
      {/* Ball */}
      <circle cx="100" cy="140" r="10" fill="white" />
      <path d="M94 135 Q100 140 94 145" fill="none" stroke="#dc2626" strokeWidth="1.5" />
      <path d="M106 135 Q100 140 106 145" fill="none" stroke="#dc2626" strokeWidth="1.5" />
      
      {/* Text - CHAMPIONS PADEL curved on top */}
      <defs>
        <path id="topArc" d="M 30 100 A 70 70 0 0 1 170 100" fill="none" />
        <path id="bottomArc" d="M 35 115 A 65 65 0 0 0 165 115" fill="none" />
      </defs>
      
      <text fill="white" fontSize="18" fontWeight="bold" fontFamily="Arial, sans-serif" letterSpacing="3">
        <textPath href="#topArc" startOffset="50%" textAnchor="middle">
          CHAMPIONS PADEL
        </textPath>
      </text>
      
      <text fill="white" fontSize="22" fontWeight="bold" fontFamily="Arial, sans-serif" letterSpacing="4">
        <textPath href="#bottomArc" startOffset="50%" textAnchor="middle">
          FRANCE
        </textPath>
      </text>
    </svg>
  );
}
