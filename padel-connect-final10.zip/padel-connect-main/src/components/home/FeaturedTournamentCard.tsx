import { Link } from 'react-router-dom';
import { Heart, Calendar, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tournament } from '@/types';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

// Import tournament images
import tournament1 from '@/assets/tournament-1.jpg';
import tournament2 from '@/assets/tournament-2.jpg';
import tournament3 from '@/assets/tournament-3.jpg';
import tournament4 from '@/assets/tournament-4.jpg';

interface FeaturedTournamentCardProps {
  tournament: Tournament;
  index?: number;
}

const tournamentImages = [tournament1, tournament2, tournament3, tournament4];

export function FeaturedTournamentCard({ tournament, index = 0 }: FeaturedTournamentCardProps) {
  const isPlatformManaged = tournament.is_managed_by_platform;
  const imageIndex = index % tournamentImages.length;
  const displayImage = tournament.image_url || tournamentImages[imageIndex];

  return (
    <Link to={`/tournaments/${tournament.id}`} className="group block">
      <div className="tournament-card relative">
        {/* Image container */}
        <div className="relative aspect-[4/3] rounded-xl overflow-hidden mb-4">
          <img
            src={displayImage}
            alt={tournament.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          {/* Platform badge - Purple like Miles Republic */}
          {isPlatformManaged && (
            <Badge className="absolute top-3 left-3 bg-primary/90 text-primary-foreground text-xs font-medium px-3 py-1">
              Achat instantané
            </Badge>
          )}

          {/* Favorite button */}
          <button 
            className="absolute top-3 right-3 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center transition-all duration-200 hover:bg-background hover:scale-110"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Add to favorites
            }}
          >
            <Heart className="h-5 w-5 text-foreground" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-1">
          {/* Title - Italic display font */}
          <h3 className="font-display text-lg leading-tight group-hover:text-primary transition-colors uppercase">
            {tournament.title}
          </h3>

          {/* Club name */}
          {tournament.club?.name && (
            <div className="text-sm text-muted-foreground">
              {tournament.club.name}
            </div>
          )}

          {/* Date */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>
              {format(new Date(tournament.start_date), 'd MMMM yyyy', { locale: fr })}
            </span>
          </div>

          {/* Location */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{tournament.city}</span>
            {tournament.region && (
              <>
                <span>•</span>
                <span>{tournament.region}</span>
              </>
            )}
          </div>

          {/* Category badges */}
          <div className="flex items-center gap-2 pt-2">
            <span className="text-xs text-muted-foreground">
              {tournament.category_code}
            </span>
            <span className="text-xs text-muted-foreground">•</span>
            <span className="text-xs text-muted-foreground">
              {tournament.gender === 'H' ? 'Hommes' : tournament.gender === 'F' ? 'Femmes' : 'Mixte'}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
