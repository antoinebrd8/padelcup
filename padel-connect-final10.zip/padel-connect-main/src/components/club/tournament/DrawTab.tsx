import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ClubTournament, TournamentTeam, DrawResult, GroupResult, GeneratedMatch } from '@/types/tournament';
import { Settings, Users, RefreshCw, Lock, Unlock, Download, Printer } from 'lucide-react';

interface DrawTabProps {
  tournament: ClubTournament;
  teams: TournamentTeam[];
  confirmedTeams: TournamentTeam[];
  localDraw: {
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  } | null;
  onGenerateDraw: () => void;
  onRegenerateDraw: () => void;
  onToggleLock: () => void;
  onExportCSV: () => void;
  onPrintGroupsPDF: () => void;
  onUpdateTournament: (updates: Partial<ClubTournament>) => void;
  onUpdateTeamSeedRank: (teamId: string, seedRank: number | null) => void;
  onUpdateLocalDraw?: (next: {
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  } | null) => void;
}

// Bracket visualization
const BracketMatch = ({ match, teams }: { match: GeneratedMatch; teams: TournamentTeam[] }) => {
  const teamA = match.team_a_id ? teams.find(t => t.id === match.team_a_id) : null;
  const teamB = match.team_b_id ? teams.find(t => t.id === match.team_b_id) : null;
  
  return (
    <div className="border rounded-lg bg-card p-3 min-w-[180px]">
      <div className="text-xs text-muted-foreground mb-2">Match {match.match_order + 1}</div>
      <div className="space-y-1">
        <div className={`flex items-center gap-2 p-2 rounded ${match.winner_id === match.team_a_id ? 'bg-primary/10 border border-primary' : 'bg-muted/50'}`}>
          {teamA?.seed_rank && <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">{teamA.seed_rank}</Badge>}
          <span className="text-sm truncate flex-1">{match.is_bye && !teamA ? 'BYE' : teamA?.name || 'TBD'}</span>
        </div>
        <div className={`flex items-center gap-2 p-2 rounded ${match.winner_id === match.team_b_id ? 'bg-primary/10 border border-primary' : 'bg-muted/50'}`}>
          {teamB?.seed_rank && <Badge variant="outline" className="h-5 w-5 p-0 justify-center text-xs font-mono">{teamB.seed_rank}</Badge>}
          <span className="text-sm truncate flex-1">{match.is_bye && !teamB ? 'BYE' : teamB?.name || 'TBD'}</span>
        </div>
      </div>
    </div>
  );
};

const KnockoutBracket = ({ drawResult, teams }: { drawResult: DrawResult; teams: TournamentTeam[] }) => {
  const roundsWithMatches = useMemo(() => {
    const grouped: Record<number, GeneratedMatch[]> = {};
    drawResult.matches.forEach(match => {
      if (!grouped[match.round_order]) grouped[match.round_order] = [];
      grouped[match.round_order].push(match);
    });
    return Object.entries(grouped).sort(([a], [b]) => parseInt(a) - parseInt(b)).map(([, matches]) => matches);
  }, [drawResult.matches]);

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-8 min-w-max">
        {roundsWithMatches.map((matches, roundIndex) => (
          <div key={roundIndex} className="flex flex-col">
            <div className="text-sm font-semibold text-center mb-4 text-muted-foreground">{matches[0]?.round_name}</div>
            <div className="flex flex-col justify-around flex-1 gap-4" style={{ paddingTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 20}px` : 0, gap: `${Math.pow(2, roundIndex + 1) * 10}px` }}>
              {matches.map((match) => <BracketMatch key={`${match.round_order}-${match.match_order}`} match={match} teams={teams} />)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const GroupStage = ({
  groupResult,
  teams,
  tournament,
  editable,
  onMoveTeam,
}: {
  groupResult: GroupResult;
  teams: TournamentTeam[];
  tournament: ClubTournament;
  editable: boolean;
  onMoveTeam?: (teamId: string, targetGroupOrder: number) => void;
}) => {
  const exemptSeeds = groupResult.exemptSeeds || [];
  const exemptTeams = teams.filter(t => exemptSeeds.includes(t.id)).sort((a, b) => (a.seed_rank ?? 999) - (b.seed_rank ?? 999));
  
  return (
    <div className="space-y-8">
      {exemptTeams.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><Badge variant="default">Tableau Final</Badge>TdS exemptées de poules</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {exemptTeams.map((team) => (
              <Card key={team.id} className="border-primary/50 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2"><Badge variant="outline" className="font-mono">TdS {team.seed_rank}</Badge><span className="font-medium truncate">{team.name}</span></div>
                  <p className="text-xs text-muted-foreground mt-2">Qualifié directement au tableau final</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><Badge variant="secondary">Phase de Poules</Badge>{groupResult.groups.length} poules</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groupResult.groups.map((group) => (
            <Card key={group.order}>
              <CardHeader className="pb-3"><CardTitle className="text-lg">{group.name}</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {group.team_ids.map((teamId, index) => {
                    const team = teams.find(t => t.id === teamId);
                    const isQualifying = index < (tournament.qualifiers_per_group || 2);
                    return (
                      <div key={teamId} className={`flex items-center gap-3 p-2 rounded ${isQualifying ? 'bg-primary/10 border border-primary/20' : 'bg-muted/50'}`}>
                        <span className="text-sm font-mono text-muted-foreground w-4">{index + 1}</span>
                        {team?.seed_rank && <Badge variant="secondary" className="text-xs">TdS {team.seed_rank}</Badge>}
                        <span className="text-sm font-medium truncate flex-1">{team?.name || 'TBD'}</span>
                        {editable && onMoveTeam && (
                          <Select
                            value={String(group.order)}
                            onValueChange={(v) => {
                              const target = parseInt(v, 10);
                              if (!Number.isFinite(target)) return;
                              if (target === group.order) return;
                              onMoveTeam(teamId, target);
                            }}
                          >
                            <SelectTrigger className="h-8 w-[120px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {groupResult.groups.map((g) => (
                                <SelectItem key={g.order} value={String(g.order)}>{g.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        {editable && (
          <p className="text-xs text-muted-foreground mt-3">
            Astuce : vous pouvez déplacer une équipe d'une poule à une autre avant de valider le tirage.
          </p>
        )}
      </div>
    </div>
  );
};

const RoundRobinMatches = ({ matches, teams }: { matches: GeneratedMatch[]; teams: TournamentTeam[] }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    {matches.map((match, idx) => <BracketMatch key={idx} match={match} teams={teams} />)}
  </div>
);

export const DrawTab = ({
  tournament,
  teams,
  confirmedTeams,
  localDraw,
  onGenerateDraw,
  onRegenerateDraw,
  onToggleLock,
  onExportCSV,
  onPrintGroupsPDF,
  onUpdateTournament,
  onUpdateTeamSeedRank,
  onUpdateLocalDraw,
}: DrawTabProps) => {
  const getFormatLabel = (format: string) => {
    switch (format) {
      case 'knockout': return 'Élimination directe';
      case 'groups_knockout': return 'Poules + Élimination';
      case 'round_robin': return 'Championnat';
      case 'direct_entry': return 'Entrée directe';
      default: return format;
    }
  };

  // Allow draw generation even if the tournament is not full.
  // We also allow generating the draw at any time (organisers often want to prepare in advance).
  const canGenerateDraw = true;

  // Custom group sizes (e.g. "4,4,3" for 11 teams). Used to constrain qualifiers per group.
  const customGroupSizes = useMemo(() => {
    const enabled = (tournament as any).use_custom_groups;
    const csv = ((tournament as any).group_sizes_csv as string | null | undefined) || '';
    if (!enabled || !csv.trim()) return [] as number[];
    return csv
      .split(',')
      .map(s => parseInt(s.trim(), 10))
      // Minimum 3 équipes par poule (évite les poules de 2)
      .filter(n => Number.isFinite(n) && n >= 3);
  }, [(tournament as any).use_custom_groups, (tournament as any).group_sizes_csv]);

  const recommendedGroupSizes = useMemo(() => {
    if (tournament.format !== 'groups_knockout') return [] as number[];
    const target = tournament.group_size || 4;
    const minSize = 3;
    const directSeeds = tournament.seeds_direct_count || 0;
    const exempt = confirmedTeams
      .filter(t => t.seed_rank !== null && t.seed_rank !== undefined && t.seed_rank <= directSeeds)
      .map(t => t.id);
    const teamsForGroupsCount = confirmedTeams.filter(t => !exempt.includes(t.id)).length;

    const computeAuto = (teamsCount: number, targetSize: number, minGroup: number): number[] => {
      if (teamsCount <= 0) return [];
      if (teamsCount <= targetSize) return [Math.max(minGroup, Math.min(targetSize, teamsCount))];
      const full = Math.floor(teamsCount / targetSize);
      const remainder = teamsCount % targetSize;
      const sizes = Array.from({ length: full }, () => targetSize);
      if (remainder === 0) return sizes;
      if (remainder >= minGroup) return [...sizes, remainder];
      const needed = minGroup - remainder;
      const adj = [...sizes];
      for (let i = 0; i < needed; i++) {
        const idx = adj.length - 1 - i;
        if (idx < 0) break;
        if (adj[idx] - 1 < minGroup) {
          const alt = adj.findIndex(s => s - 1 >= minGroup);
          if (alt === -1) break;
          adj[alt] -= 1;
        } else {
          adj[idx] -= 1;
        }
      }
      adj.push(minGroup);
      return adj;
    };

    return computeAuto(teamsForGroupsCount, target, minSize);
  }, [tournament.format, tournament.group_size, tournament.seeds_direct_count, confirmedTeams]);

  const qualifierMax = useMemo(() => {
    if (customGroupSizes.length) {
      const minSize = Math.min(...customGroupSizes);
      return Math.max(1, minSize - 1);
    }
    return Math.max(1, (tournament.group_size || 4) - 1);
  }, [customGroupSizes, tournament.group_size]);

  const rebuildGroupMatches = (groups: { name: string; order: number; team_ids: string[] }[]): GeneratedMatch[] => {
    const matches: GeneratedMatch[] = [];
    for (const g of groups) {
      const ids = [...g.team_ids];
      let matchOrder = 0;
      for (let i = 0; i < ids.length; i++) {
        for (let j = i + 1; j < ids.length; j++) {
          matches.push({
            id: `local-${g.order}-${matchOrder}-${ids[i]}-${ids[j]}`,
            round_name: g.name,
            round_order: g.order,
            match_order: matchOrder,
            slot_a: 0,
            slot_b: 0,
            team_a_id: ids[i],
            team_b_id: ids[j],
            is_bye: false,
            score_a: '',
            score_b: '',
            winner_id: '',
          });
          matchOrder++;
        }
      }
    }
    return matches;
  };

  const handleMoveTeamBetweenGroups = (teamId: string, targetGroupOrder: number) => {
    if (!localDraw?.groupDraw) return;
    const currentGroups = localDraw.groupDraw.groups.map(g => ({ ...g, team_ids: [...g.team_ids] }));
    const fromIdx = currentGroups.findIndex(g => g.team_ids.includes(teamId));
    const toIdx = currentGroups.findIndex(g => g.order === targetGroupOrder);
    if (fromIdx === -1 || toIdx === -1) return;
    if (fromIdx === toIdx) return;

    currentGroups[fromIdx].team_ids = currentGroups[fromIdx].team_ids.filter(id => id !== teamId);
    currentGroups[toIdx].team_ids.push(teamId);

    const nextGroupDraw: GroupResult = {
      ...localDraw.groupDraw,
      groups: currentGroups,
      matches: rebuildGroupMatches(currentGroups),
    };

    onUpdateLocalDraw?.({
      ...localDraw,
      // KO bracket depends on pool qualifiers; reset it until pools are completed.
      knockoutDraw: tournament.format === 'groups_knockout' ? undefined : localDraw.knockoutDraw,
      groupDraw: nextGroupDraw,
    });
  };

  if (!localDraw) {
    return (
      <div className="space-y-6">
        {/* Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Settings className="h-5 w-5" />Configuration du tirage</CardTitle>
            <CardDescription>Définissez les paramètres avant de générer</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="format">Format du tournoi</Label>
                <Select value={tournament.format} onValueChange={(value) => onUpdateTournament({ format: value as any })}>
                  <SelectTrigger id="format"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="knockout">Élimination directe</SelectItem>
                    <SelectItem value="direct_entry">Entrée directe (TdS)</SelectItem>
                    <SelectItem value="groups_knockout">Poules + Élimination</SelectItem>
                    <SelectItem value="round_robin">Championnat</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {tournament.format === 'direct_entry' && (
                <div className="space-y-2">
                  <Label>TdS en entrée directe</Label>
                  <Input type="number" min={1} max={confirmedTeams.length} value={tournament.seeds_direct_count || 0} onChange={(e) => onUpdateTournament({ seeds_direct_count: parseInt(e.target.value) || 0 })} />
                </div>
              )}

              <div className="space-y-2">
                <Label>Priorité BYE pour TdS</Label>
                <div className="flex items-center gap-2 pt-2">
                  <Switch checked={tournament.byes_priority_for_seeds} onCheckedChange={(checked) => onUpdateTournament({ byes_priority_for_seeds: checked })} />
                  <Label className="font-normal cursor-pointer">{tournament.byes_priority_for_seeds ? 'Activé' : 'Désactivé'}</Label>
                </div>
              </div>

              {tournament.format === 'groups_knockout' && (
                <>
                  <div className="space-y-2">
                    <Label>TdS exemptées de poules</Label>
                    <Input type="number" min={0} value={tournament.seeds_direct_count || 0} onChange={(e) => onUpdateTournament({ seeds_direct_count: parseInt(e.target.value) || 0 })} />
                  </div>

                  <div className="space-y-2">
                    <Label>Poules personnalisées</Label>
                    <div className="flex items-center gap-2 pt-2">
                      <Switch
                        checked={(tournament as any).use_custom_groups || false}
                        onCheckedChange={(checked) => onUpdateTournament({ use_custom_groups: checked } as any)}
                      />
                      <Label className="font-normal cursor-pointer">
                        {(tournament as any).use_custom_groups ? 'Activé' : 'Désactivé'}
                      </Label>
                    </div>
                    {(tournament as any).use_custom_groups && (
                      <div className="space-y-2 pt-2">
                        <Label className="text-sm text-muted-foreground">
                          Répartition des poules (ex: 4,4,3 pour 11 équipes)
                        </Label>
                        {recommendedGroupSizes.length > 0 && (
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-xs text-muted-foreground">
                              Recommandé : <span className="font-medium">{recommendedGroupSizes.join(',')}</span>
                            </p>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => onUpdateTournament({ group_sizes_csv: recommendedGroupSizes.join(',') } as any)}
                            >
                              Utiliser
                            </Button>
                          </div>
                        )}
                        <Input
                          placeholder="4,4,3"
                          value={(tournament as any).group_sizes_csv || ''}
                          onChange={(e) => onUpdateTournament({ group_sizes_csv: e.target.value } as any)}
                        />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Taille des poules</Label>
                    <Input
                      type="number"
                      min={3}
                      max={8}
                      disabled={(tournament as any).use_custom_groups || false}
                      value={tournament.group_size || 4}
                      onChange={(e) => onUpdateTournament({ group_size: parseInt(e.target.value) || 4 })}
                    />
                    {!(tournament as any).use_custom_groups && recommendedGroupSizes.length > 0 && (
                      <p className="text-xs text-muted-foreground">
                        Répartition auto : <span className="font-medium">{recommendedGroupSizes.join(' / ')}</span>
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label>Qualifiés par poule</Label>
                    <Input type="number" min={1} max={qualifierMax} value={tournament.qualifiers_per_group || 2} onChange={(e) => onUpdateTournament({ qualifiers_per_group: parseInt(e.target.value) || 2 })} />
                  </div>

                  <div className="space-y-2">
                    <Label>Qualifiés supplémentaires (optionnel)</Label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      <Select
                        value={(tournament as any).extra_qualifiers_position ? String((tournament as any).extra_qualifiers_position) : undefined}
                        onValueChange={(v) => onUpdateTournament({ extra_qualifiers_position: v === "none" ? null : parseInt(v) } as any)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Aucun" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Aucun</SelectItem>
                          <SelectItem value="2">Meilleur 2e</SelectItem>
                          <SelectItem value="3">Meilleur 3e</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        min={0}
                        placeholder="Nombre"
                        value={(tournament as any).extra_qualifiers_count ?? 0}
                        onChange={(e) => onUpdateTournament({ extra_qualifiers_count: parseInt(e.target.value) || 0 } as any)}
                        disabled={!((tournament as any).extra_qualifiers_position)}
                      />
                      <div className="text-xs text-muted-foreground flex items-center">
                        Comparaison FFT : points → diff sets → diff jeux. Si poules de tailles différentes, on ignore le match contre le dernier pour comparer équitablement.
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>



{/* Participants / Têtes de série */}
<Card>
  <CardHeader>
    <CardTitle className="flex items-center gap-2"><Users className="h-5 w-5" />Participants</CardTitle>
    <CardDescription>Attribuez les têtes de série avant de générer le tirage (laisser vide = non tête de série)</CardDescription>
  </CardHeader>
  <CardContent className="space-y-3">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {confirmedTeams.map((team) => (
        <div key={team.id} className="flex items-center justify-between gap-3 p-3 rounded border bg-card">
          <div className="min-w-0">
            <div className="font-medium truncate">{team.name}</div>
            <div className="text-xs text-muted-foreground truncate">{team.player1_name} / {team.player2_name}</div>
          </div>
          <div className="flex items-center gap-2">
            <Input
              type="number"
              className="w-20"
              min={1}
              placeholder="TdS"
              value={team.seed_rank ?? ''}
              onChange={(e) => {
                const v = e.target.value.trim();
                onUpdateTeamSeedRank(team.id, v === '' ? null : Math.max(1, parseInt(v) || 1));
              }}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => onUpdateTeamSeedRank(team.id, null)}
              disabled={team.seed_rank === null || team.seed_rank === undefined}
            >
              Effacer
            </Button>
          </div>
        </div>
      ))}
    </div>

    <p className="text-xs text-muted-foreground">
      Astuce : mettez 1,2,3,4... pour vos TdS. Elles seront réparties dans les poules et/ou protégées selon le format choisi.
    </p>
  </CardContent>
</Card>
        {/* Generate button */}
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <Users className="h-16 w-16 text-muted-foreground/50 mx-auto mb-6" />
              <h2 className="text-xl font-semibold mb-2">Prêt pour le tirage</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                {confirmedTeams.length < 2
                  ? `Il faut au moins 2 équipes. Actuellement: ${confirmedTeams.length}`
                  : `${confirmedTeams.length} équipes chargées pour le format "${getFormatLabel(tournament.format)}".`}
              </p>
              <Button variant="accent" size="lg" onClick={onGenerateDraw} disabled={confirmedTeams.length < 2 || !canGenerateDraw}>
                Générer le tirage
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={onPrintGroupsPDF}><Printer className="mr-2 h-4 w-4" />Imprimer poules (PDF)</Button>
        <Button variant="outline" onClick={onExportCSV}><Download className="mr-2 h-4 w-4" />Export CSV</Button>
        {tournament.draw_locked ? (
          <Button variant="outline" onClick={onToggleLock}><Unlock className="mr-2 h-4 w-4" />Modifier le tirage</Button>
        ) : (
          <>
            <Button variant="outline" onClick={onRegenerateDraw}><RefreshCw className="mr-2 h-4 w-4" />Régénérer</Button>
            <Button variant="success" onClick={onToggleLock}><Lock className="mr-2 h-4 w-4" />Valider le tirage</Button>
          </>
        )}
      </div>

      {/* Draw visualization */}
      <Card>
        <CardHeader>
          <CardTitle>Tableau du tournoi</CardTitle>
          <CardDescription>
            {tournament.format === 'knockout' && localDraw?.knockoutDraw && `${localDraw?.knockoutDraw.rounds.length} tours`}
            {tournament.format === 'groups_knockout' && localDraw?.groupDraw && `${localDraw?.groupDraw.groups.length} poules`}
            {tournament.format === 'round_robin' && localDraw?.roundRobinMatches && `${localDraw?.roundRobinMatches.length} matchs`}
            {tournament.format === 'direct_entry' && localDraw?.knockoutDraw && `Entrée directe • ${localDraw?.knockoutDraw.rounds.length} tours`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(tournament.format === 'knockout' || tournament.format === 'direct_entry') && localDraw?.knockoutDraw && (
            <KnockoutBracket drawResult={localDraw?.knockoutDraw} teams={teams} />
          )}
          {tournament.format === 'groups_knockout' && localDraw?.groupDraw && (
            <GroupStage
              groupResult={localDraw?.groupDraw}
              teams={teams}
              tournament={tournament}
              editable={!tournament.draw_locked}
              onMoveTeam={!tournament.draw_locked ? handleMoveTeamBetweenGroups : undefined}
            />
          )}
          {tournament.format === 'round_robin' && localDraw?.roundRobinMatches && (
            <RoundRobinMatches matches={localDraw?.roundRobinMatches} teams={teams} />
          )}
        </CardContent>
      </Card>
    </div>
  );
};
