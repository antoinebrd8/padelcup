import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import type { ClubTournament, TournamentTeam, GeneratedMatch, DrawResult, GroupResult } from '@/types/tournament';
import { getFftPointsPerPlayer, type FftCategory } from '@/lib/fftPoints';
import { calculateFftGroupStandings } from '@/lib/fftStandings';
import { Download, Save, RefreshCcw } from 'lucide-react';

type FinalRow = {
  team: TournamentTeam;
  computedRank: number;
  finalRank: number;
  pointsPerPlayer: number;
  reason?: string;
  warning?: string;
  player1License?: string | null;
  player2License?: string | null;
  player1Ranking?: string | null;
  player2Ranking?: string | null;
};

function safeCategory(code: string | null | undefined): FftCategory {
  const c = (code || 'P25').toUpperCase();
  if (c === 'P25' || c === 'P50' || c === 'P100' || c === 'P250' || c === 'P500') return c;
  return 'P25';
}

function computeKnockoutRanks(matches: GeneratedMatch[], teamIds: string[]): Map<string, number> {
  const ranks = new Map<string, number>();
  const played = matches.filter(m => !m.is_bye && m.team_a_id && m.team_b_id);
  if (played.length === 0) return ranks;

  const maxRound = Math.max(...played.map(m => m.round_order ?? 0));
  const finals = played.filter(m => (m.round_order ?? 0) === maxRound);
  const finalMatch = finals.sort((a, b) => (a.match_order ?? 0) - (b.match_order ?? 0))[0];

  // Third place match detection (best-effort)
  const thirdPlaceMatch = played.find(m => /3|petite|classement/i.test(m.round_name || ''));

  if (finalMatch?.winner_id && finalMatch.team_a_id && finalMatch.team_b_id) {
    ranks.set(finalMatch.winner_id, 1);
    const loser = finalMatch.winner_id === finalMatch.team_a_id ? finalMatch.team_b_id : finalMatch.team_a_id;
    ranks.set(loser, 2);
  }

  if (thirdPlaceMatch?.winner_id && thirdPlaceMatch.team_a_id && thirdPlaceMatch.team_b_id) {
    ranks.set(thirdPlaceMatch.winner_id, 3);
    const loser = thirdPlaceMatch.winner_id === thirdPlaceMatch.team_a_id ? thirdPlaceMatch.team_b_id : thirdPlaceMatch.team_a_id;
    ranks.set(loser, 4);
  }

  // For everyone else: find the round they lost (highest round_order where they appear and are not winner)
  for (const id of teamIds) {
    if (ranks.has(id)) continue;
    let lostRound: number | null = null;
    for (const m of played) {
      const r = m.round_order ?? 0;
      if (!m.winner_id) continue;
      if (m.team_a_id !== id && m.team_b_id !== id) continue;
      if (m.winner_id !== id) {
        if (lostRound === null || r > lostRound) lostRound = r;
      }
    }
    if (lostRound !== null) {
      const sharedRank = Math.pow(2, (maxRound - lostRound + 1));
      ranks.set(id, sharedRank);
    }
  }

  return ranks;
}

function computeNonQualifiedPoolRanks(args: {
  groupDraw: GroupResult;
  teams: TournamentTeam[];
  qualifiersPerGroup: number;
}): Map<string, number> {
  const { groupDraw, teams, qualifiersPerGroup } = args;
  const groupCount = groupDraw.groups.length;
  const map = new Map<string, number>();

  for (const g of groupDraw.groups) {
    const standings = calculateFftGroupStandings(g.team_ids, teams, groupDraw.matches);
    standings.forEach((row, idx) => {
      const position = idx + 1;
      if (position > qualifiersPerGroup) {
        // Ex: 4 pools of 4 -> 3rd = 12e, 4th = 16e
        map.set(row.team.id, position * groupCount);
      }
    });
  }
  return map;
}

async function downloadCsv(filename: string, rows: Record<string, any>[]) {
  const escape = (v: any) => {
    const s = (v ?? '').toString();
    if (/[\n",;]/.test(s)) return `"${s.replaceAll('"', '""')}"`;
    return s;
  };
  const headers = Object.keys(rows[0] || {});
  const content = [headers.join(';'), ...rows.map(r => headers.map(h => escape(r[h])).join(';'))].join('\n');
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function FinalResultsTab(props: {
  tournament: ClubTournament;
  teams: TournamentTeam[];
  localDraw: { knockoutDraw?: DrawResult; groupDraw?: GroupResult; roundRobinMatches?: GeneratedMatch[] };
}) {
  const { tournament, teams, localDraw } = props;
  const category = safeCategory((tournament as any).category_code);
  const qualifiersPerGroup = tournament.qualifiers_per_group || 2;

  const [overrides, setOverrides] = useState<Record<string, { final_rank: number; points_per_player: number; reason?: string }>>({});
  const [playerInfoByEmail, setPlayerInfoByEmail] = useState<Record<string, { license_number: string | null; ranking: string | null }>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const loadOverrides = useCallback(async () => {
    if (!tournament?.id) return;
    setIsLoading(true);
    const { data } = await supabase
      .from('tournament_final_rankings')
      .select('team_id, final_rank, points_per_player, reason')
      .eq('tournament_id', tournament.id);
    const map: Record<string, any> = {};
    for (const r of (data as any[]) ?? []) {
      map[r.team_id] = { final_rank: r.final_rank, points_per_player: r.points_per_player, reason: r.reason };
    }
    setOverrides(map);
    setIsLoading(false);
  }, [tournament?.id]);

  const loadPlayerInfos = useCallback(async () => {
    const emails = Array.from(
      new Set(
        teams
          .flatMap(t => [t.player1_email, t.player2_email])
          .filter(Boolean) as string[]
      )
    );
    if (emails.length === 0) return;
    const { data } = await supabase
      .from('players')
      .select('email, license_number, ranking')
      .in('email', emails);
    const map: Record<string, { license_number: string | null; ranking: string | null }> = {};
    for (const p of (data as any[]) ?? []) {
      map[p.email] = { license_number: p.license_number ?? null, ranking: p.ranking ?? null };
    }
    setPlayerInfoByEmail(map);
  }, [teams]);

  useEffect(() => {
    loadOverrides();
    loadPlayerInfos();
  }, [loadOverrides, loadPlayerInfos]);

  const computed = useMemo(() => {
    const totalPairs = teams.length;
    const teamIds = teams.map(t => t.id);

    const koMatches = localDraw.knockoutDraw?.matches ?? [];
    const koRanks = computeKnockoutRanks(koMatches, teamIds);

    const nonQualified = localDraw.groupDraw
      ? computeNonQualifiedPoolRanks({ groupDraw: localDraw.groupDraw, teams, qualifiersPerGroup })
      : new Map<string, number>();

    // Default: if team has a KO rank -> use it; else if nonQualified rank -> use it; else last.
    const rows: FinalRow[] = teams.map(team => {
      const computedRank = koRanks.get(team.id) ?? nonQualified.get(team.id) ?? totalPairs;
      const base = getFftPointsPerPlayer({ category, totalPairs, rank: computedRank });
      return {
        team,
        computedRank,
        finalRank: computedRank,
        pointsPerPlayer: base.points,
        warning: base.warning,
        player1License: team.player1_email ? (playerInfoByEmail[team.player1_email]?.license_number ?? null) : null,
        player2License: team.player2_email ? (playerInfoByEmail[team.player2_email]?.license_number ?? null) : null,
        player1Ranking: team.player1_email ? (playerInfoByEmail[team.player1_email]?.ranking ?? null) : null,
        player2Ranking: team.player2_email ? (playerInfoByEmail[team.player2_email]?.ranking ?? null) : null,
      };
    });

    // Apply overrides
    for (const r of rows) {
      const o = overrides[r.team.id];
      if (o) {
        r.finalRank = o.final_rank;
        r.pointsPerPlayer = o.points_per_player;
        r.reason = o.reason;
      } else {
        const base = getFftPointsPerPlayer({ category, totalPairs, rank: r.finalRank });
        r.pointsPerPlayer = base.points;
        r.warning = base.warning;
      }
    }

    rows.sort((a, b) => a.finalRank - b.finalRank || a.team.name.localeCompare(b.team.name));
    return rows;
  }, [teams, localDraw.knockoutDraw, localDraw.groupDraw, qualifiersPerGroup, category, overrides, playerInfoByEmail]);

  const setRank = (teamId: string, rank: number) => {
    const totalPairs = teams.length;
    const base = getFftPointsPerPlayer({ category, totalPairs, rank });
    setOverrides(prev => ({
      ...prev,
      [teamId]: {
        final_rank: rank,
        points_per_player: base.points,
        reason: prev[teamId]?.reason,
      }
    }));
  };

  const setReason = (teamId: string, reason: string) => {
    setOverrides(prev => ({
      ...prev,
      [teamId]: {
        final_rank: prev[teamId]?.final_rank ?? computed.find(r => r.team.id === teamId)?.finalRank ?? teams.length,
        points_per_player: prev[teamId]?.points_per_player ?? 0,
        reason,
      }
    }));
  };

  const saveAll = useCallback(async () => {
    if (!tournament?.id) return;
    setIsSaving(true);
    const payload = computed.map(r => ({
      tournament_id: tournament.id,
      team_id: r.team.id,
      final_rank: r.finalRank,
      points_per_player: r.pointsPerPlayer,
      reason: r.reason ?? null,
    }));
    await supabase
      .from('tournament_final_rankings')
      .upsert(payload as any, { onConflict: 'tournament_id,team_id' } as any);
    await loadOverrides();
    setIsSaving(false);
  }, [tournament?.id, computed, loadOverrides]);

  const resetOverrides = useCallback(async () => {
    if (!tournament?.id) return;
    setIsSaving(true);
    await supabase
      .from('tournament_final_rankings')
      .delete()
      .eq('tournament_id', tournament.id);
    await loadOverrides();
    setIsSaving(false);
  }, [tournament?.id, loadOverrides]);

  const exportCsv = useCallback(async () => {
    const rows = computed.map(r => ({
      Rang: r.finalRank,
      Equipe: r.team.name,
      Joueur1: r.team.player1_name,
      Licence1: r.player1License ?? '',
      Classement1: r.player1Ranking ?? '',
      Joueur2: r.team.player2_name ?? '',
      Licence2: r.player2License ?? '',
      Classement2: r.player2Ranking ?? '',
      Points_par_joueur: r.pointsPerPlayer,
      Motif: r.reason ?? '',
    }));
    await downloadCsv(`classement_${tournament.id}.csv`, rows);
  }, [computed, tournament?.id]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline">{category}</Badge>
          <span className="text-sm text-muted-foreground">{teams.length} paires</span>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCsv}>
            <Download className="h-4 w-4 mr-2" /> Exporter CSV
          </Button>
          <Button variant="outline" onClick={resetOverrides} disabled={isSaving}>
            <RefreshCcw className="h-4 w-4 mr-2" /> Réinitialiser
          </Button>
          <Button onClick={saveAll} disabled={isSaving}>
            <Save className="h-4 w-4 mr-2" /> {isSaving ? 'Enregistrement…' : 'Enregistrer'}
          </Button>
        </div>
      </div>

      {computed.some(r => r.warning) && (
        <Card className="border-amber-500/40">
          <CardContent className="py-4 text-sm text-muted-foreground">
            {Array.from(new Set(computed.map(r => r.warning).filter(Boolean))).map((w, idx) => (
              <p key={idx}>⚠️ {w}</p>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Classement final & points FFT</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Rang</th>
                  <th className="text-left py-2">Équipe</th>
                  <th className="text-left py-2">Licences / Classement</th>
                  <th className="text-center py-2">Pts / joueur</th>
                  <th className="text-left py-2">Motif (optionnel)</th>
                </tr>
              </thead>
              <tbody>
                {computed.map((r) => (
                  <tr key={r.team.id} className="border-b align-top">
                    <td className="py-2 pr-3 w-28">
                      <Input
                        type="number"
                        min={1}
                        value={r.finalRank}
                        onChange={(e) => setRank(r.team.id, Math.max(1, parseInt(e.target.value || '1', 10)))}
                        className="h-8"
                      />
                      {r.computedRank !== r.finalRank && (
                        <div className="text-[11px] text-muted-foreground mt-1">auto: {r.computedRank}</div>
                      )}
                    </td>
                    <td className="py-2">
                      <div className="font-medium">{r.team.name}</div>
                      <div className="text-muted-foreground text-xs">{r.team.player1_name}{r.team.player2_name ? ` / ${r.team.player2_name}` : ''}</div>
                    </td>
                    <td className="py-2 text-xs text-muted-foreground">
                      <div className="space-y-1">
                        <div>
                          <span className="font-medium">{r.player1License || '—'}</span>
                          <span className="ml-2">{r.player1Ranking || ''}</span>
                        </div>
                        {r.team.player2_name && (
                          <div>
                            <span className="font-medium">{r.player2License || '—'}</span>
                            <span className="ml-2">{r.player2Ranking || ''}</span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-2 text-center font-semibold">
                      {r.pointsPerPlayer}
                    </td>
                    <td className="py-2">
                      <Input
                        value={r.reason ?? ''}
                        onChange={(e) => setReason(r.team.id, e.target.value)}
                        placeholder="ex: pas de match de classement"
                        className="h-8"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {isLoading && <p className="text-sm text-muted-foreground mt-3">Chargement…</p>}
        </CardContent>
      </Card>
    </div>
  );
}
