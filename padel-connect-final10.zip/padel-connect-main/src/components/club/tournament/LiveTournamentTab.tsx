import { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ClubTournament, TournamentTeam, DrawResult, GroupResult, GeneratedMatch } from '@/types/tournament';
import { Database } from '@/integrations/supabase/types';
import { cn } from '@/lib/utils';
import { detectUnresolvedTieGroups, type FftTieBreakOrders } from '@/lib/fftStandings';
import { calculateFftGroupStandingsExplained } from '@/lib/standingExplanations';
import { supabase } from '@/integrations/supabase/client';
import { Maximize2, Minimize2, Trophy, Users, Check, Info } from 'lucide-react';
import { GAME_FORMAT_CONFIG, getNumScoreInputs, getSetsNeededToWin } from '@/lib/gameFormatConfig';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

type GameFormat = Database['public']['Enums']['game_format'];



// Parse scores and calculate sets/games for standings.
// Important: in formats with deciding Super Tie-Break (A2/B2/C2/D2), the deciding ST must NOT count as a "set" in standings.
const parseScores = (
  scoreA: string,
  scoreB: string,
  gameFormat: GameFormat
): { setsA: number; setsB: number; gamesA: number; gamesB: number } => {
  const partsA = scoreA ? scoreA.split('/').map(s => parseInt(s) || 0) : [];
  const partsB = scoreB ? scoreB.split('/').map(s => parseInt(s) || 0) : [];

  let setsA = 0, setsB = 0, gamesA = 0, gamesB = 0;
  const maxLen = Math.max(partsA.length, partsB.length);
  const config = GAME_FORMAT_CONFIG[gameFormat];

  for (let i = 0; i < maxLen; i++) {
    const a = partsA[i] || 0;
    const b = partsB[i] || 0;

    // Formats where scores are ONLY Super Tie-Break points (no games concept)
    if (config.isSuperTBOnly) {
      if (a > b) setsA++;
      else if (b > a) setsB++;
      continue;
    }

    // Deciding ST (3rd entry) in 2-set formats: do not count as set or games for standings
    const isDecidingSuperTB = (i === 2) && (config.sets === 2) && config.hasDecidingSuperTB;
    if (!isDecidingSuperTB) {
      gamesA += a;
      gamesB += b;
      if (a > b) setsA++;
      else if (b > a) setsB++;
    }
  }

  return { setsA, setsB, gamesA, gamesB };
};


const calculateGroupStandings = (
  groupTeamIds: string[],
  teams: TournamentTeam[],
  matches: GeneratedMatch[],
  _gameFormat: GameFormat,
  tieBreakOrders?: FftTieBreakOrders
) => {
  // FFT P25 -> P500 standings
  return calculateFftGroupStandingsExplained(groupTeamIds, teams, matches, { tieBreakOrders });
};

// Calculate number of sets needed based on format and current score
const getNumSetsForMatch = (setsA: number[], setsB: number[], gameFormat: GameFormat): number => {
  return getNumScoreInputs(setsA, setsB, gameFormat);
};

const calculateWinner = (setsA: number[], setsB: number[], gameFormat: GameFormat): 'A' | 'B' | null => {
  let winsA = 0, winsB = 0;
  for (let i = 0; i < setsA.length; i++) {
    const a = setsA[i] || 0;
    const b = setsB[i] || 0;
    if (a > 0 || b > 0) {
      if (a > b) winsA++;
      else if (b > a) winsB++;
    }
  }
  const needed = getSetsNeededToWin(gameFormat);
  if (winsA >= needed) return 'A';
  if (winsB >= needed) return 'B';
  return null;
};

interface LiveMatchCardProps {
  match: GeneratedMatch;
  teams: TournamentTeam[];
  // Organizer request: for manual correction, allow selecting ANY participating team.
  /**
   * KO only: team ids already used in OTHER matches of the same round.
   * Prevents assigning the same team twice in a given round when manually editing bracket.
   */
  roundUsedTeamIds?: Set<string>;
  gameFormat: GameFormat;
  onScoreSubmit: (matchId: string, scoreA: string, scoreB: string, winnerId: string, resultType?: GeneratedMatch['result_type']) => void;
  enableTeamEdit?: boolean;
  onTeamsSubmit?: (matchId: string, teamAId: string | null, teamBId: string | null) => Promise<void> | void;
}

const LiveMatchCard = ({ match, teams, roundUsedTeamIds, gameFormat, onScoreSubmit, enableTeamEdit, onTeamsSubmit }: LiveMatchCardProps) => {
  const teamA = match.team_a_id ? teams.find(t => t.id === match.team_a_id) : null;
  const teamB = match.team_b_id ? teams.find(t => t.id === match.team_b_id) : null;
  
  if (match.is_bye) return null;

  const config = GAME_FORMAT_CONFIG[gameFormat];
  
  // Parse initial scores from match data
  const getInitialSets = (score: string | undefined): number[] => {
    if (!score) return [0, 0, 0]; // Always allocate 3 slots max
    const parts = score.split('/').map(s => parseInt(s) || 0);
    while (parts.length < 3) parts.push(0);
    return parts.slice(0, 3);
  };

  const [setsA, setSetsA] = useState<number[]>(() => getInitialSets(match.score_a));
  const [setsB, setSetsB] = useState<number[]>(() => getInitialSets(match.score_b));
  const [isSaving, setIsSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingTeams, setIsEditingTeams] = useState(false);
  const [editTeamAId, setEditTeamAId] = useState<string | null>(match.team_a_id || null);
  const [editTeamBId, setEditTeamBId] = useState<string | null>(match.team_b_id || null);

  type ResultMode = 'normal' | 'wo_a' | 'wo_b' | 'dq_a' | 'dq_b';
  const deriveInitialResultMode = (): ResultMode => {
    const rt = match.result_type ?? 'normal';
    if (rt === 'wo') {
      if (match.winner_id && match.team_a_id && match.winner_id === match.team_b_id) return 'wo_a';
      if (match.winner_id && match.team_b_id && match.winner_id === match.team_a_id) return 'wo_b';
      return 'wo_a';
    }
    if (rt === 'dq') {
      if (match.winner_id && match.team_a_id && match.winner_id === match.team_b_id) return 'dq_a';
      if (match.winner_id && match.team_b_id && match.winner_id === match.team_a_id) return 'dq_b';
      return 'dq_a';
    }
    return 'normal';
  };

  const [resultMode, setResultMode] = useState<ResultMode>(() => deriveInitialResultMode());

  // Sync with external data when match changes
  useEffect(() => {
    setSetsA(getInitialSets(match.score_a));
    setSetsB(getInitialSets(match.score_b));
    setEditTeamAId(match.team_a_id || null);
    setEditTeamBId(match.team_b_id || null);
    setResultMode(deriveInitialResultMode());
  }, [match.id, match.score_a, match.score_b, match.winner_id, match.result_type]);

  const isCompleted = !!match.winner_id;
  const hasNoId = !match.id;
  const winner = calculateWinner(setsA, setsB, gameFormat);
  const isSpecialResult = resultMode !== 'normal';
  
  // Dynamically calculate how many set inputs to show
  const numSets = getNumSetsForMatch(setsA, setsB, gameFormat);
  const isDecidingSet = numSets === 3 && config.sets === 2; // 1-1 situation
  const isSuperTBOnly = config.isSuperTBOnly;
  const showST = (i: number) => isSuperTBOnly || (i === 2 && isDecidingSet);
  const maxForInput = (i: number) => {
    if (isSuperTBOnly) return 30;
    if (gameFormat === 'D1' || gameFormat === 'D2') return 9;
    if (gameFormat === 'F') return 5;
    if (i === 2 && isDecidingSet) return 30;
    return 7;
  };

  const handleSetChange = (isTeamA: boolean, setIndex: number, value: string) => {
    const numValue = Math.max(0, parseInt(value) || 0);
    if (isTeamA) {
      const newSets = [...setsA];
      newSets[setIndex] = numValue;
      setSetsA(newSets);
    } else {
      const newSets = [...setsB];
      newSets[setIndex] = numValue;
      setSetsB(newSets);
    }
  };

  const handleSubmitScore = async () => {
    if (hasNoId || !teamA || !teamB) return;

    setIsSaving(true);

    if (resultMode === 'normal') {
      if (!winner) {
        setIsSaving(false);
        return;
      }
      const usedSets = numSets;
      const scoreA = setsA.slice(0, usedSets).join('/');
      const scoreB = setsB.slice(0, usedSets).join('/');
      const winnerId = winner === 'A' ? teamA.id : teamB.id;
      await onScoreSubmit(match.id!, scoreA, scoreB, winnerId, 'normal');
    } else {
      const isAForfeit = resultMode.endsWith('_a');
      const isWo = resultMode.startsWith('wo');
      const winnerId = isAForfeit ? teamB.id : teamA.id;
      await onScoreSubmit(match.id!, '', '', winnerId, isWo ? 'wo' : 'dq');
    }

    setIsSaving(false);
    setIsEditing(false);
  };

  const handleClearScore = async () => {
    if (hasNoId) return;
    setIsSaving(true);
    await onScoreSubmit(match.id!, '', '', '', 'normal');
    setIsSaving(false);
    setIsEditing(false);
  };

  const handleSubmitTeams = async () => {
    if (!enableTeamEdit || !onTeamsSubmit || hasNoId) return;
    // Organizer override: allow selecting ANY team (even if it creates a same-round conflict).
    // Conflicts are resolved by the parent handler (it will clear the other match slots).
    if (editTeamAId && editTeamBId && editTeamAId === editTeamBId) return;
    setIsSaving(true);
    await onTeamsSubmit(match.id!, editTeamAId, editTeamBId);
    setIsSaving(false);
    setIsEditingTeams(false);
    setIsEditing(false);
  };

  // Check if score can be submitted
  const canSubmit = !hasNoId && !!teamA && !!teamB && (isEditing || !isCompleted) && (isSpecialResult || !!winner);
  const winnerName = useMemo(() => {
    if (!teamA || !teamB) return '';
    if (isSpecialResult) return resultMode.endsWith('_a') ? teamB.name : teamA.name;
    return winner === 'A' ? teamA.name : teamB.name;
  }, [isSpecialResult, resultMode, teamA, teamB, winner]);

  return (
    <Card className={cn(
      'transition-all',
      isCompleted ? 'border-green-500/50 bg-green-500/5' : 'border-blue-500/50 bg-blue-500/5',
      hasNoId && 'opacity-60'
    )}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{match.round_name} • Match {match.match_order + 1}</span>
          {hasNoId && <Badge variant="outline" className="bg-amber-500/10 text-amber-600 text-xs">Non sauvegardé</Badge>}
          {isCompleted && <Badge variant="outline" className="bg-green-500/10 text-green-600">Terminé</Badge>}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {enableTeamEdit && isEditingTeams && !hasNoId && (
          <div className="space-y-3 rounded-lg border bg-background p-3">
            <div className="text-xs font-medium text-muted-foreground">Modifier les équipes (correction manuelle)</div>
            <div className="grid grid-cols-1 gap-3">
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">Équipe A</div>
                <Select value={editTeamAId ?? '__none__'} onValueChange={(v) => setEditTeamAId(v === '__none__' ? null : v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="TBD" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">TBD</SelectItem>
                    {teams.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">Équipe B</div>
                <Select value={editTeamBId ?? '__none__'} onValueChange={(v) => setEditTeamBId(v === '__none__' ? null : v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="TBD" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">TBD</SelectItem>
                    {teams.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" size="sm" className="flex-1" disabled={isSaving} onClick={() => { setIsEditingTeams(false); setEditTeamAId(match.team_a_id || null); setEditTeamBId(match.team_b_id || null); }}>
                Annuler
              </Button>
              <Button type="button" size="sm" className="flex-1" disabled={isSaving} onClick={handleSubmitTeams}>
                Enregistrer
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Note : enregistrer efface le score de ce match et les tours suivants (pour éviter les incohérences).</p>
          </div>
        )}

        {isCompleted && !hasNoId && !isEditing && (
          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" className="flex-1" onClick={() => setIsEditing(true)}
            >
              Modifier
            </Button>
            <Button type="button" variant="outline" size="sm" className="flex-1" onClick={handleClearScore}
            >
              Effacer
            </Button>
          </div>
        )}

        {enableTeamEdit && !hasNoId && !isEditingTeams && (
          <Button type="button" variant="outline" size="sm" onClick={() => setIsEditingTeams(true)}>
            Modifier les équipes
          </Button>
        )}
        {hasNoId && (
          <p className="text-xs text-amber-600 bg-amber-500/10 p-2 rounded">
            ⚠️ Validez le tirage pour pouvoir enregistrer les scores
          </p>
        )}

        {/* FFT P25->P500: special results impacting standings points */}
        {!hasNoId && teamA && teamB && (isEditing || !isCompleted) && (
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Résultat (FFT)</div>
            <Select value={resultMode} onValueChange={(v) => setResultMode(v as any)}>
              <SelectTrigger>
                <SelectValue placeholder="Normal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="wo_a">WO / Forfait : équipe A perd</SelectItem>
                <SelectItem value="wo_b">WO / Forfait : équipe B perd</SelectItem>
                <SelectItem value="dq_a">Disqualification : équipe A perd</SelectItem>
                <SelectItem value="dq_b">Disqualification : équipe B perd</SelectItem>
              </SelectContent>
            </Select>
            {isSpecialResult && (
              <p className="text-xs text-muted-foreground">
                ⚠️ En WO, l'équipe perdante prend -2 pts en poule. En DQ, -1 pt. Le vainqueur prend 2 pts.
              </p>
            )}
          </div>
        )}
        
        {/* Team A */}
        <div className={cn('p-3 rounded-lg', teamA?.id && match.winner_id === teamA.id ? 'bg-green-500/20 border border-green-500' : 'bg-muted/50')}>
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              {teamA?.seed_rank && <Badge variant="outline" className="shrink-0">{teamA.seed_rank}</Badge>}
              <span className="font-medium truncate">{teamA?.name || 'TBD'}</span>
            </div>
            {teamA?.id && match.winner_id === teamA.id && <Trophy className="h-4 w-4 text-green-600 shrink-0" />}
          </div>
          <div className="flex gap-1 items-center">
            {Array.from({ length: numSets }).map((_, i) => (
              <div key={i} className="flex flex-col items-center">
                {showST(i) && <span className="text-[10px] text-muted-foreground mb-0.5">ST</span>}
                <Input
                  type="number"
                  min={0}
                  max={maxForInput(i)}
                  value={setsA[i] || 0}
                  onChange={(e) => handleSetChange(true, i, e.target.value)}
                  className={cn("w-12 h-8 text-center text-sm", showST(i) && "border-primary")}
                  disabled={hasNoId || !teamA || !teamB || isSpecialResult || (isCompleted && !isEditing)}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="text-center text-xs text-muted-foreground">VS</div>

        {/* Team B */}
        <div className={cn('p-3 rounded-lg', teamB?.id && match.winner_id === teamB.id ? 'bg-green-500/20 border border-green-500' : 'bg-muted/50')}>
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              {teamB?.seed_rank && <Badge variant="outline" className="shrink-0">{teamB.seed_rank}</Badge>}
              <span className="font-medium truncate">{teamB?.name || 'TBD'}</span>
            </div>
            {teamB?.id && match.winner_id === teamB.id && <Trophy className="h-4 w-4 text-green-600 shrink-0" />}
          </div>
          <div className="flex gap-1 items-center">
            {Array.from({ length: numSets }).map((_, i) => (
              <div key={i} className="flex flex-col items-center">
                {showST(i) && <span className="text-[10px] text-muted-foreground mb-0.5">ST</span>}
                <Input
                  type="number"
                  min={0}
                  max={maxForInput(i)}
                  value={setsB[i] || 0}
                  onChange={(e) => handleSetChange(false, i, e.target.value)}
                  className={cn("w-12 h-8 text-center text-sm", showST(i) && "border-primary")}
                  disabled={hasNoId || !teamA || !teamB || isSpecialResult || (isCompleted && !isEditing)}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Submit button */}
        {canSubmit && (
          <Button 
            onClick={handleSubmitScore} 
            className="w-full" 
            size="sm"
            disabled={isSaving}
          >
            <Check className="h-4 w-4 mr-2" />
            {isSaving ? 'Enregistrement...' : `${isEditing || isCompleted ? 'Mettre à jour' : 'Valider'} - ${winnerName} gagne`}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

const GroupStandingsTable = ({ groupName, standings, qualifiersCount }: { groupName: string; standings: ReturnType<typeof calculateGroupStandings>; qualifiersCount: number }) => (
  <Card>
    <CardHeader className="pb-2">
      <CardTitle className="text-lg">{groupName}</CardTitle>
    </CardHeader>
    <CardContent>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="text-left py-2">#</th>
            <th className="text-left py-2">Équipe</th>
            <th className="text-center py-2">V/D</th>
            <th className="text-center py-2">Sets</th>
            <th className="text-center py-2">Pts</th>
            <th className="text-right py-2">Pourquoi ?</th>
          </tr>
        </thead>
        <tbody>
          {standings.map((row, idx) => (
            <tr key={row.team?.id} className={cn('border-b', idx === 0 ? 'bg-amber-500/10' : idx < qualifiersCount ? 'bg-green-500/10' : '')}>
              <td className="py-2 font-mono">{idx + 1}</td>
              <td className="py-2 font-medium">
                <div>{row.team?.name || 'TBD'}</div>
                {row.tie_break_explanation && (
                  <div className="text-xs text-muted-foreground mt-0.5">{row.tie_break_explanation}</div>
                )}
              </td>
              <td className="py-2 text-center"><span className="text-green-600">{row.wins}</span>/<span className="text-red-600">{row.losses}</span></td>
              <td className="py-2 text-center">{row.setsWon - row.setsLost > 0 ? '+' : ''}{row.setsWon - row.setsLost}</td>
              <td className="py-2 text-center font-bold">{row.points}</td>
              <td className="py-2 text-right">
                {row.tie_break_explanation ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                        <Info className="h-4 w-4" />
                        détails
                      </button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      {row.tie_break_explanation}
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </CardContent>
  </Card>
);

interface LiveTournamentTabProps {
  tournament: ClubTournament;
  teams: TournamentTeam[];
  localDraw: {
    knockoutDraw?: DrawResult;
    groupDraw?: GroupResult;
    roundRobinMatches?: GeneratedMatch[];
  };
  onScoreUpdate: (matchId: string, scoreA: string, scoreB: string, winnerId: string, resultType?: GeneratedMatch['result_type']) => void;
  onUpdateMatchTeams?: (matchId: string, teamAId: string | null, teamBId: string | null) => Promise<void> | void;
  onPersistDrawMatches?: () => Promise<boolean>;
}

export const LiveTournamentTab = ({ tournament, teams, localDraw, onScoreUpdate, onUpdateMatchTeams, onPersistDrawMatches }: LiveTournamentTabProps) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const gameFormat: GameFormat = tournament.game_format || 'B1';
  const qualifiersPerGroup = tournament.qualifiers_per_group || 2;

  // Tirage au sort (tie-break draw) persistence for unresolved ties in pools
  const [tieBreakOrdersByGroup, setTieBreakOrdersByGroup] = useState<Record<string, FftTieBreakOrders>>({});
  const [isDrawing, setIsDrawing] = useState(false);

  const loadTieBreakOrders = useCallback(async () => {
    if (!tournament?.id) return;
    const { data, error } = await supabase
      .from('tournament_tiebreak_draws')
      .select('group_label, tie_key, order_team_ids')
      .eq('tournament_id', tournament.id);
    if (error) return;

    const byGroup: Record<string, FftTieBreakOrders> = {};
    for (const row of (data as any[]) ?? []) {
      const groupLabel = row.group_label || 'GLOBAL';
      if (!byGroup[groupLabel]) byGroup[groupLabel] = {};
      byGroup[groupLabel][row.tie_key] = row.order_team_ids;
    }
    setTieBreakOrdersByGroup(byGroup);
  }, [tournament?.id]);

  useEffect(() => {
    loadTieBreakOrders();
  }, [loadTieBreakOrders]);

  const doDrawForGroup = useCallback(async (groupLabel: string, teamIds: string[]) => {
    if (!tournament?.id) return;
    setIsDrawing(true);
    const tieKey = [...teamIds].sort().join(',');
    const shuffled = [...teamIds]
      .map(v => ({ v, s: Math.random() }))
      .sort((a, b) => a.s - b.s)
      .map(({ v }) => v);

    await supabase
      .from('tournament_tiebreak_draws')
      .upsert({
        tournament_id: tournament.id,
        group_label: groupLabel,
        tie_key: tieKey,
        order_team_ids: shuffled,
      } as any, { onConflict: 'tournament_id,group_label,tie_key' } as any);

    await loadTieBreakOrders();
    setIsDrawing(false);
  }, [tournament?.id, loadTieBreakOrders]);

  const hasUnsavedMatches = useMemo(() => {
    const all = [
      ...(localDraw.knockoutDraw?.matches ?? []),
      ...(localDraw.groupDraw?.matches ?? []),
      ...(localDraw.roundRobinMatches ?? []),
    ];
    return all.some((m) => !m.id);
  }, [localDraw]);

  const handlePersist = async () => {
    if (!onPersistDrawMatches) return;
    await onPersistDrawMatches();
  };

  // NOTE: Keep full list of teams for manual corrections.

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  // Compute all matches from any format
  const allMatches = useMemo(() => {
    if (localDraw.knockoutDraw) return localDraw.knockoutDraw.matches.filter(m => !m.is_bye);
    if (localDraw.groupDraw) return localDraw.groupDraw.matches;
    if (localDraw.roundRobinMatches) return localDraw.roundRobinMatches;
    return [];
  }, [localDraw.knockoutDraw, localDraw.groupDraw, localDraw.roundRobinMatches]);

  // Create a reactive key based on match results to force recalculation
  const matchResultsKey = useMemo(() => 
    allMatches.map(m => `${m.id}:${m.winner_id || ''}:${m.score_a || ''}:${m.score_b || ''}:${m.result_type || 'normal'}`).join('|'),
    [allMatches]
  );

  const completedMatches = allMatches.filter(m => m.winner_id);
  const formatInfo = GAME_FORMAT_CONFIG[gameFormat];

  // KO only: for each round, keep track of teams already placed in matches.
  const koTeamsUsedByRound = useMemo(() => {
    const map = new Map<number, Set<string>>();
    if (!localDraw.knockoutDraw) return map;

    for (const m of localDraw.knockoutDraw.matches) {
      if (m.is_bye) continue;
      const r = m.round_order ?? 0;
      if (!map.has(r)) map.set(r, new Set<string>());
      const set = map.get(r)!;
      if (m.team_a_id) set.add(m.team_a_id);
      if (m.team_b_id) set.add(m.team_b_id);
    }
    return map;
  }, [localDraw.knockoutDraw]);

  // Groups with standings - recalculates when matchResultsKey changes
  const groupsWithStandings = useMemo(() => {
    if (!localDraw.groupDraw) return [];
    return localDraw.groupDraw.groups.map(group => ({
      ...group,
      standings: calculateGroupStandings(group.team_ids, teams, localDraw.groupDraw!.matches, gameFormat, tieBreakOrdersByGroup[group.name]),
      unresolvedTieGroups: detectUnresolvedTieGroups(group.team_ids, teams, localDraw.groupDraw!.matches, { tieBreakOrders: tieBreakOrdersByGroup[group.name] }),
      matches: localDraw.groupDraw!.matches.filter(m => 
        group.team_ids.includes(m.team_a_id || '') && group.team_ids.includes(m.team_b_id || '')
      )
    }));
  }, [localDraw.groupDraw, teams, matchResultsKey, gameFormat, tieBreakOrdersByGroup]);

  // Round robin standings (all teams compete against each other)
  const roundRobinStandings = useMemo(() => {
    if (!localDraw.roundRobinMatches) return null;
    const teamIds = [...new Set(localDraw.roundRobinMatches.flatMap(m => [m.team_a_id, m.team_b_id].filter(Boolean) as string[]))];
    return calculateGroupStandings(teamIds, teams, localDraw.roundRobinMatches, gameFormat, tieBreakOrdersByGroup['GLOBAL']);
  }, [localDraw.roundRobinMatches, teams, matchResultsKey, gameFormat, tieBreakOrdersByGroup]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Badge variant="default" className="animate-pulse">🔴 LIVE</Badge>
          <div>
            <span className="text-muted-foreground">Format: </span>
            <span className="font-medium">{formatInfo.label}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Matchs: </span>
            <span className="font-medium">{completedMatches.length}/{allMatches.length}</span>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={toggleFullscreen}>
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </div>

      {hasUnsavedMatches && (
        <Card className="border-amber-500/40">
          <CardContent className="py-4 flex items-center justify-between gap-4">
            <div className="text-sm">
              <p className="font-medium text-amber-700">⚠️ Le tableau n’est pas encore sauvegardé</p>
              <p className="text-muted-foreground">Clique sur “Valider le tirage” pour pouvoir saisir les scores en mode Live.</p>
            </div>
            <Button onClick={handlePersist} disabled={!onPersistDrawMatches} className="shrink-0">
              <Check className="mr-2 h-4 w-4" />
              Valider le tirage
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Knockout */}
      {localDraw.knockoutDraw && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Tableau</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {localDraw.knockoutDraw.matches.filter(m => !m.is_bye).map((match) => (
              <LiveMatchCard
                key={match.id || `${match.round_name}-${match.round_order}-${match.match_order}`}
                match={match}
                teams={teams}
                roundUsedTeamIds={(() => {
                  const r = match.round_order ?? 0;
                  const used = new Set<string>(koTeamsUsedByRound.get(r) ?? []);
                  if (match.team_a_id) used.delete(match.team_a_id);
                  if (match.team_b_id) used.delete(match.team_b_id);
                  return used;
                })()}
                gameFormat={gameFormat}
                onScoreSubmit={onScoreUpdate}
                enableTeamEdit={true}
                onTeamsSubmit={onUpdateMatchTeams}
              />
            ))}
          </div>
        </div>
      )}

      {/* Groups */}
      {localDraw.groupDraw && (
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">Toutes les poules</TabsTrigger>
            {groupsWithStandings.map((group) => (
              <TabsTrigger key={group.order} value={`group-${group.order}`}>{group.name}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupsWithStandings.map((group) => (
                <GroupStandingsTable key={group.order} groupName={group.name} standings={group.standings} qualifiersCount={qualifiersPerGroup} />
              ))}
            </div>
          </TabsContent>

          {groupsWithStandings.map((group) => (
            <TabsContent key={group.order} value={`group-${group.order}`} className="space-y-6">
              {group.unresolvedTieGroups?.length > 0 && (
                <Card className="border-amber-500/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Trophy className="h-4 w-4" /> Tirage au sort nécessaire (FFT)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Des équipes sont encore ex æquo après l’application des critères FFT. Tu peux générer un tirage au sort officiel.
                    </p>
                    <div className="space-y-2">
                      {group.unresolvedTieGroups.map((ids: string[], idx: number) => (
                        <div key={idx} className="flex items-center justify-between gap-3">
                          <div className="text-sm">
                            <span className="font-medium">Ex æquo :</span>{' '}
                            {ids
                              .map((id) => teams.find(t => t.id === id)?.name || 'TBD')
                              .join(' • ')}
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={isDrawing}
                            onClick={() => doDrawForGroup(group.name, ids)}
                          >
                            {isDrawing ? 'Tirage…' : 'Tirer au sort'}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
              <GroupStandingsTable groupName={group.name} standings={group.standings} qualifiersCount={qualifiersPerGroup} />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {group.matches.map((match, idx) => (
                  <LiveMatchCard key={match.id || `${group.name}-${match.match_order}-${match.team_a_id}-${match.team_b_id}`} match={match} teams={teams} gameFormat={gameFormat} onScoreSubmit={onScoreUpdate} />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      )}

      {/* Round Robin */}
      {localDraw.roundRobinMatches && (
        <div className="space-y-6">
          <h3 className="text-lg font-semibold">Championnat</h3>
          
          {/* Standings table */}
          {roundRobinStandings && (
            <GroupStandingsTable 
              groupName="Classement général" 
              standings={roundRobinStandings} 
              qualifiersCount={0} 
            />
          )}

          {/* Matches grid */}
          <h4 className="text-md font-medium text-muted-foreground">Matchs</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {localDraw.roundRobinMatches.map((match, idx) => (
              <LiveMatchCard key={match.id || `${match.round_name}-${match.match_order}`} match={match} teams={teams} gameFormat={gameFormat} onScoreSubmit={onScoreUpdate} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
