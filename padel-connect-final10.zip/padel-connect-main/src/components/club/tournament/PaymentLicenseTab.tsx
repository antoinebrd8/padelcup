import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { CheckCircle, CreditCard, FileText, Clock, AlertTriangle, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Copy } from 'lucide-react';

interface PaymentLicenseTabProps {
  tournament: {
    id: string;
    price?: number | null;
    start_date?: string | null;
    start_time?: string | null;
    refund_deadline_hours?: number | null;
    refund_policy_text?: string | null;
  };
  teams: Array<{
    id: string;
    name: string;
    player1_name?: string | null;
    player1_email?: string | null;
    player1_payment_status?: string | null;
    player1_has_license?: boolean | null;
    player2_name?: string | null;
    player2_email?: string | null;
    player2_payment_status?: string | null;
    player2_has_license?: boolean | null;
    status?: string | null;
    seed_rank?: number | null;
  }>;
  players: Array<{
    email: string;
    license_number?: string | null;
  }>;
  onTeamUpdate: () => void;
  }

const fmt = (d: Date) => {
  try {
    return d.toLocaleString('fr-FR', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch {
    return d.toISOString();
  }
};

interface TeamWithLicenses {
  id: string;
  name: string;
  player1_name?: string | null;
  player1_email?: string | null;
  player1_payment_status?: string | null;
  player1_has_license?: boolean | null;
  player2_name?: string | null;
  player2_email?: string | null;
  player2_payment_status?: string | null;
  player2_has_license?: boolean | null;
  status?: string | null;
  seed_rank?: number | null;
  player1_license?: string | null;
  player2_license?: string | null;
}

export const PaymentLicenseTab = ({ tournament, teams, players, onTeamUpdate }: PaymentLicenseTabProps) => {
  const { toast } = useToast();
  const [teamToDelete, setTeamToDelete] = useState<TeamWithLicenses | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedPlayerEmail, setSelectedPlayerEmail] = useState<string | null>(null);
  const [selectedPlayerName, setSelectedPlayerName] = useState<string | null>(null);
  const [playerLookup, setPlayerLookup] = useState<{ id?: string; first_name?: string; last_name?: string; email?: string; license_number?: string | null } | null>(null);
  const [loadingLookup, setLoadingLookup] = useState(false);

  // Merge teams with license info
  const playerByEmail = useMemo(() => {
    const map = new Map<string, { license_number?: string | null }>();
    for (const p of players) {
      // Normalise emails to avoid missing licence numbers because of casing/spaces
      const key = (p.email || '').trim().toLowerCase();
      if (!key) continue;
      map.set(key, { license_number: p.license_number });
    }
    return map;
  }, [players]);

  const teamsWithLicenses: TeamWithLicenses[] = useMemo(() => {
    return teams.map((team) => {
      const p1Key = (team.player1_email || '').trim().toLowerCase();
      const p2Key = (team.player2_email || '').trim().toLowerCase();
      const p1 = p1Key ? playerByEmail.get(p1Key) : undefined;
      const p2 = p2Key ? playerByEmail.get(p2Key) : undefined;
      return {
        ...team,
        player1_license: p1?.license_number,
        player2_license: p2?.license_number,
      };
    });
  }, [teams, playerByEmail]);

  // Stats
  const totalPlayers = teams.length * 2;
  const paidPlayers = teams.reduce((acc, t) => {
    let count = 0;
    if (t.player1_payment_status === 'paid') count++;
    if (t.player2_payment_status === 'paid') count++;
    return acc + count;
  }, 0);
  const licensedPlayers = teams.reduce((acc, t) => {
    // Prefer the actual licence number when available (more reliable than booleans)
    let count = 0;
    const p1 = players.find(p => p.email === t.player1_email);
    const p2 = players.find(p => p.email === t.player2_email);
    if (p1?.license_number) count++;
    if (p2?.license_number) count++;
    return acc + count;
  }, 0);

  const getPaymentBadge = (status: string) => {
    if (status === 'paid') {
      return <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20"><CheckCircle className="h-3 w-3 mr-1" />Payé</Badge>;
    }
    return <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20"><Clock className="h-3 w-3 mr-1" />En attente</Badge>;
  };

  const getLicenseBadge = (licenseNumber?: string | null) => {
    if (licenseNumber && String(licenseNumber).trim().length > 0) {
      return (
        <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
          <FileText className="h-3 w-3 mr-1" />
          {licenseNumber}
        </Badge>
      );
    }

    // If no licence number, show "Non" in red as requested
    return (
      <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
        <AlertTriangle className="h-3 w-3 mr-1" />
        Non
      </Badge>
    );
  };

  const openPlayerDetails = async (email?: string | null, fallbackName?: string | null) => {
    const e = (email || '').trim();
    if (!e) return;
    setSelectedPlayerEmail(e);
    setSelectedPlayerName(fallbackName || e);
    setPlayerLookup(null);
    setLoadingLookup(true);
    try {
      const { data, error } = await supabase.rpc('find_player_by_email', { p_email: e });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      if (row?.id) setPlayerLookup(row);
      else setPlayerLookup(null);
    } catch (err) {
      console.warn('player lookup failed', err);
      setPlayerLookup(null);
    } finally {
      setLoadingLookup(false);
    }
  };

  const copyToClipboard = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast({ title: 'Copié', description: value });
    } catch {
      toast({ title: 'Impossible de copier', description: value, variant: 'destructive' });
    }
  };

  const handleDeleteTeam = async () => {
    if (!teamToDelete) return;
    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('tournament_teams')
        .delete()
        .eq('id', teamToDelete.id)
        .eq('tournament_id', tournament.id);

      if (error) throw error;

      // If the tournament was full, promote the oldest waitlist team into "confirmed".
      // We do it in the app (no dependency on DB triggers / enums).
      try {
        const { data: tInfo } = await supabase
          .from('club_tournaments')
          .select('max_teams')
          .eq('id', tournament.id)
          .maybeSingle();

        const maxTeams = Number((tInfo as any)?.max_teams || 0);
        if (maxTeams > 0) {
          const { data: activeTeams } = await supabase
            .from('tournament_teams')
            .select('id')
            .eq('tournament_id', tournament.id)
            .eq('status', 'confirmed');

          const activeCount = activeTeams?.length || 0;
          if (activeCount < maxTeams) {
            const { data: nextWait } = await supabase
              .from('tournament_teams')
              .select('id')
              .eq('tournament_id', tournament.id)
              .eq('status', 'waiting')
              .order('created_at', { ascending: true })
              .limit(1)
              .maybeSingle();

            if ((nextWait as any)?.id) {
              await supabase
                .from('tournament_teams')
                .update({ status: 'confirmed' })
                .eq('id', (nextWait as any).id);
            }
          }
        }
      } catch (e) {
        // best effort
        console.warn('Waitlist promotion (best effort) failed:', e);
      }

      toast({
        title: 'Équipe supprimée',
        description: `${teamToDelete.name} a été retirée du tournoi.`,
      });
      setTeamToDelete(null);
      onTeamUpdate();
    } catch (e: any) {
      toast({
        title: "Impossible de supprimer l'équipe",
        description: e?.message || 'Erreur inconnue',
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
{/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Équipes inscrites</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teams.length}</div>
            <p className="text-xs text-muted-foreground">{teams.filter(t => t.status === 'confirmed').length} confirmées</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Paiements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{paidPlayers} / {totalPlayers}</div>
            <p className="text-xs text-muted-foreground">joueurs ont payé</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Licences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{licensedPlayers} / {totalPlayers}</div>
            <p className="text-xs text-muted-foreground">joueurs licenciés</p>
          </CardContent>
        </Card>
      </div>

      {/* Player details dialog (on-demand) */}
      <Dialog open={!!selectedPlayerEmail} onOpenChange={(open) => { if (!open) setSelectedPlayerEmail(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Détails joueur</DialogTitle>
            <DialogDescription>
              {selectedPlayerName || selectedPlayerEmail}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm text-muted-foreground">Email</div>
                <div className="font-medium break-all">{selectedPlayerEmail}</div>
              </div>
              {selectedPlayerEmail && (
                <Button variant="outline" size="sm" onClick={() => copyToClipboard(selectedPlayerEmail)}>
                  <Copy className="h-4 w-4 mr-2" />Copier
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="rounded-md border p-3">
                <div className="text-sm text-muted-foreground">Compte Padel Cup</div>
                <div className="font-medium">
                  {loadingLookup ? 'Recherche…' : (playerLookup?.id ? 'Oui' : 'Non')}
                </div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-sm text-muted-foreground">N° licence</div>
                <div className="font-medium">
                  {loadingLookup ? '—' : (playerLookup?.license_number || '—')}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setSelectedPlayerEmail(null)}>Fermer</Button>
            {selectedPlayerEmail && (
              <Button asChild>
                <a href={`mailto:${encodeURIComponent(selectedPlayerEmail)}`}>Envoyer un email</a>
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Teams Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Gestion des paiements et licences
          </CardTitle>
          <CardDescription>
            Suivez les paiements et vérifiez les licences de chaque joueur
          </CardDescription>
        </CardHeader>
        <CardContent>
          {teams.length === 0 ? (
            <div className="text-center py-12">
              <CreditCard className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Aucune équipe inscrite</h3>
              <p className="text-muted-foreground">Les équipes apparaîtront ici une fois inscrites.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Équipe</TableHead>
                    <TableHead>Joueur 1</TableHead>
                    <TableHead>Paiement J1</TableHead>
                    <TableHead>Licence J1</TableHead>
                    <TableHead>Joueur 2</TableHead>
                    <TableHead>Paiement J2</TableHead>
                    <TableHead>Licence J2</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teamsWithLicenses.map((team) => (
                    <TableRow key={team.id}>
                      <TableCell>
                        <div className="font-medium">{team.name}</div>
                        {team.seed_rank && (
                          <Badge variant="secondary" className="mt-1">TdS {team.seed_rank}</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <button
                          type="button"
                          className="text-left font-medium hover:underline"
                          onClick={() => openPlayerDetails(team.player1_email, team.player1_name || null)}
                        >
                          {team.player1_name}
                        </button>
                        <div className="text-xs text-muted-foreground">{team.player1_email}</div>
                      </TableCell>
                      <TableCell>
                        {getPaymentBadge(team.player1_payment_status || 'pending')}
                      </TableCell>
                      <TableCell>
                        {getLicenseBadge(team.player1_license)}
                      </TableCell>
                      <TableCell>
                        {team.player2_name ? (
                          <>
                            <button
                              type="button"
                              className="text-left font-medium hover:underline"
                              onClick={() => openPlayerDetails(team.player2_email, team.player2_name || null)}
                            >
                              {team.player2_name}
                            </button>
                            <div className="text-xs text-muted-foreground">{team.player2_email}</div>
                          </>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {team.player2_name && getPaymentBadge(team.player2_payment_status || 'pending')}
                      </TableCell>
                      <TableCell>
                        {team.player2_name && getLicenseBadge(team.player2_license)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setTeamToDelete(team)}
                          title="Supprimer l'équipe"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!teamToDelete} onOpenChange={(open) => !open && setTeamToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cette équipe ?</AlertDialogTitle>
            <AlertDialogDescription>
              Cette action retire l'équipe du tournoi (utile en cas d'absence signalée par téléphone ou email).
              Les données liées (inscription, paiements, etc.) pourront être perdues.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleDeleteTeam();
              }}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Suppression…' : 'Supprimer'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
