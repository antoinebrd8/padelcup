import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Calendar, Copy, CreditCard, ExternalLink, Users } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { playerTotalPrice } from '@/lib/fees';

type TeamStatus = 'confirmed' | 'pending' | 'waiting';

interface ActiveTeamRow {
  id: string;
  tournament_id: string;
  name: string;
  player1_email: string | null;
  player2_email: string | null;
  player1_name: string;
  player2_name: string | null;
  player1_payment_status: string | null;
  player2_payment_status: string | null;
  status: TeamStatus;
  tournament: {
    title: string;
    start_date: string;
    city: string | null;
    price: number | null;
  } | null;
}

function statusBadge(status: TeamStatus) {
  switch (status) {
    case 'confirmed':
      return <Badge className="bg-success/10 text-success">Confirmée</Badge>;
    case 'pending':
      return <Badge className="bg-warning/10 text-warning">En attente de paiement</Badge>;
    case 'waiting':
      return <Badge variant="secondary">Liste d'attente</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function paymentChip(label: string, status: string | null) {
  const paid = status === 'paid';
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${paid ? 'bg-success/10 text-success border-success/20' : 'bg-muted text-muted-foreground'}`}>
      <CreditCard className="h-3 w-3" />
      {label}: {paid ? 'Payé' : 'À payer'}
    </span>
  );
}

interface ActiveTeamsCardProps {
  playerEmail: string;
}

export function ActiveTeamsCard({ playerEmail }: ActiveTeamsCardProps) {
  const { toast } = useToast();
  const [teams, setTeams] = useState<ActiveTeamRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingTeamId, setProcessingTeamId] = useState<string | null>(null);

  const fetchTeams = async () => {
    setLoading(true);

    const baseSelect = `
      id,
      tournament_id,
      name,
      player1_email,
      player2_email,
      player1_name,
      player2_name,
      player1_payment_status,
      player2_payment_status,
      status,
      tournament:club_tournaments (
        title,
        start_date,
        city,
        price
      )
    `;

    const [{ data: t1, error: e1 }, { data: t2, error: e2 }] = await Promise.all([
      supabase
        .from('tournament_teams')
        .select(baseSelect)
        .eq('player1_email', playerEmail),
      supabase
        .from('tournament_teams')
        .select(baseSelect)
        .eq('player2_email', playerEmail),
    ]);

    if (e1 || e2) {
      console.error('Error fetching active teams:', e1 || e2);
      setTeams([]);
      setLoading(false);
      return;
    }

    const merged = [...(t1 ?? []), ...(t2 ?? [])] as any[];
    // Deduplicate by team id
    const byId = new Map<string, ActiveTeamRow>();
    merged.forEach((row) => byId.set(row.id, row as ActiveTeamRow));

    // Sort: upcoming first
    const sorted = Array.from(byId.values()).sort((a, b) => {
      const da = a.tournament?.start_date ? new Date(a.tournament.start_date).getTime() : 0;
      const db = b.tournament?.start_date ? new Date(b.tournament.start_date).getTime() : 0;
      return da - db;
    });

    setTeams(sorted);
    setLoading(false);
  };

  useEffect(() => {
    fetchTeams();
    // Realtime refresh: player1 + player2 channels
    const ch1 = supabase
      .channel(`player-teams-p1-${playerEmail}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tournament_teams', filter: `player1_email=eq.${playerEmail}` },
        () => fetchTeams()
      )
      .subscribe();

    const ch2 = supabase
      .channel(`player-teams-p2-${playerEmail}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tournament_teams', filter: `player2_email=eq.${playerEmail}` },
        () => fetchTeams()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(ch1);
      supabase.removeChannel(ch2);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playerEmail]);

  const upcomingTeams = useMemo(() => {
    const now = new Date();
    return teams.filter((t) => {
      const end = t.tournament?.start_date ? new Date(t.tournament.start_date) : null;
      return !end || end >= now;
    });
  }, [teams]);

  const handleCopyLink = async (team: ActiveTeamRow) => {
    const url = `${window.location.origin}/tournaments/${team.tournament_id}`;
    await navigator.clipboard.writeText(url);
    toast({ title: 'Lien copié', description: 'Vous pouvez l’envoyer à votre partenaire.' });
  };

  const handlePayMyShare = async (team: ActiveTeamRow) => {
    const isP1 = team.player1_email?.toLowerCase() === playerEmail.toLowerCase();
    const field = isP1 ? 'player1_payment_status' : 'player2_payment_status';

    setProcessingTeamId(team.id);
    try {
      const { error } = await supabase
        .from('tournament_teams')
        .update({ [field]: 'paid' } as any)
        .eq('id', team.id);
      if (error) throw error;

      // Try to confirm if both paid
      const { data: refreshed, error: rErr } = await supabase
        .from('tournament_teams')
        .select('player1_payment_status, player2_payment_status')
        .eq('id', team.id)
        .single();

      if (!rErr && refreshed?.player1_payment_status === 'paid' && refreshed?.player2_payment_status === 'paid') {
        await supabase.from('tournament_teams').update({ status: 'confirmed' }).eq('id', team.id);
      }

      toast({ title: 'Paiement enregistré', description: 'Votre part est marquée comme payée.' });
      await fetchTeams();
    } catch (e) {
      console.error(e);
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible d’enregistrer le paiement.' });
    } finally {
      setProcessingTeamId(null);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Mes inscriptions actives</CardTitle>
          <CardDescription>Vos équipes (statut + paiements)</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Chargement…</p>
        </CardContent>
      </Card>
    );
  }

  if (upcomingTeams.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Mes inscriptions actives</CardTitle>
        <CardDescription>Statut et paiements en temps réel</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {upcomingTeams.map((team) => {
          const isP1 = team.player1_email?.toLowerCase() === playerEmail.toLowerCase();
          const myPaid = (isP1 ? team.player1_payment_status : team.player2_payment_status) === 'paid';
          const partnerPaid = (isP1 ? team.player2_payment_status : team.player1_payment_status) === 'paid';
          const partnerName = isP1 ? team.player2_name : team.player1_name;
          const basePerPlayer = team.tournament?.price ?? 40;
          const myShare = playerTotalPrice(basePerPlayer);

          return (
            <div key={team.id} className="rounded-lg border p-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link to={`/tournaments/${team.tournament_id}`} className="font-medium hover:text-primary truncate">
                      {team.tournament?.title ?? 'Tournoi'}
                    </Link>
                    {statusBadge(team.status)}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                    {team.tournament?.start_date && (
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(team.tournament.start_date), 'd MMM yyyy', { locale: fr })}
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      Partenaire : {partnerName ?? '—'}
                    </span>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {paymentChip('Vous', isP1 ? team.player1_payment_status : team.player2_payment_status)}
                    {paymentChip('Partenaire', isP1 ? team.player2_payment_status : team.player1_payment_status)}
                  </div>
                </div>

                <div className="flex flex-col sm:items-end gap-2">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleCopyLink(team)}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copier le lien
                    </Button>
                    <Button variant="ghost" size="sm" asChild>
                      <Link to={`/tournaments/${team.tournament_id}`}>
                        Voir
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </div>

                  {team.status !== 'waiting' && !myPaid && (
                    <Button
                      size="sm"
                      onClick={() => handlePayMyShare(team)}
                      disabled={processingTeamId === team.id}
                      className="w-full sm:w-auto"
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Payer mon inscription ({myShare}€)
                    </Button>
                  )}

                  {team.status !== 'waiting' && myPaid && !partnerPaid && (
                    <p className="text-xs text-muted-foreground">En attente du paiement de votre partenaire</p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
