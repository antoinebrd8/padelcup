import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CreditCard, Euro, Calendar, MapPin, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { playerTotalPrice, PADEL_CUP_FEE_PER_PLAYER_EUR } from '@/lib/fees';

interface PendingPayment {
  id: string;
  tournament_id: string;
  team_name: string;
  partner_name: string;
  tournament_title: string;
  tournament_date: string;
  tournament_city: string | null;
  price: number;
  isPlayer1: boolean;
}

interface PendingPaymentsCardProps {
  playerEmail: string;
  onPaymentComplete?: () => void;
}

export function PendingPaymentsCard({ playerEmail, onPaymentComplete }: PendingPaymentsCardProps) {
  const { toast } = useToast();
  const [pendingPayments, setPendingPayments] = useState<PendingPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    const fetchPendingPayments = async () => {
      // Find teams where the player has a pending payment
      const normalizedEmail = playerEmail.toLowerCase();
      const { data: teamsAsPlayer1, error: error1 } = await supabase
        .from('tournament_teams')
        .select(`
          id,
          tournament_id,
          name,
          player1_name,
          player2_name,
          player1_payment_status,
          player2_payment_status,
          tournament:club_tournaments (
            title,
            start_date,
            city,
            price
          )
        `)
        .ilike('player1_email', normalizedEmail)
        .eq('player1_payment_status', 'pending');

      const { data: teamsAsPlayer2, error: error2 } = await supabase
        .from('tournament_teams')
        .select(`
          id,
          tournament_id,
          name,
          player1_name,
          player2_name,
          player1_payment_status,
          player2_payment_status,
          tournament:club_tournaments (
            title,
            start_date,
            city,
            price
          )
        `)
        .ilike('player2_email', normalizedEmail)
        .eq('player2_payment_status', 'pending');

      if (error1 || error2) {
        console.error('Error fetching pending payments:', error1 || error2);
        setLoading(false);
        return;
      }

      const payments: PendingPayment[] = [];

      // Process teams where user is player1 with pending payment
      teamsAsPlayer1?.forEach((team: any) => {
        if (team.tournament) {
          payments.push({
            id: team.id,
            tournament_id: team.tournament_id,
            team_name: team.name,
            partner_name: team.player2_name,
            tournament_title: team.tournament.title,
            tournament_date: team.tournament.start_date,
            tournament_city: team.tournament.city,
            // Organizer sets a base price PER PLAYER.
            // Player pays base + Padel Cup fee.
            price: playerTotalPrice(team.tournament.price || 40),
            isPlayer1: true,
          });
        }
      });

      // Process teams where user is player2 with pending payment
      teamsAsPlayer2?.forEach((team: any) => {
        if (team.tournament) {
          payments.push({
            id: team.id,
            tournament_id: team.tournament_id,
            team_name: team.name,
            partner_name: team.player1_name,
            tournament_title: team.tournament.title,
            tournament_date: team.tournament.start_date,
            tournament_city: team.tournament.city,
            price: playerTotalPrice(team.tournament.price || 40),
            isPlayer1: false,
          });
        }
      });

      setPendingPayments(payments);
      setLoading(false);
    };

    fetchPendingPayments();
  }, [playerEmail]);

  const handlePayment = async (payment: PendingPayment) => {
    setProcessingId(payment.id);
    
    try {
      // Update the payment status
      const updateField = payment.isPlayer1 
        ? { player1_payment_status: 'paid' } 
        : { player2_payment_status: 'paid' };

      const { error } = await supabase
        .from('tournament_teams')
        .update(updateField)
        .eq('id', payment.id);

      if (error) throw error;

      // Check if both players have now paid - if so, confirm the team
      const { data: team } = await supabase
        .from('tournament_teams')
        .select('player1_payment_status, player2_payment_status, status')
        .eq('id', payment.id)
        .single();

      if (team && team.player1_payment_status === 'paid' && team.player2_payment_status === 'paid') {
        // Both paid - update status to confirmed
        await supabase
          .from('tournament_teams')
          .update({ status: 'confirmed' })
          .eq('id', payment.id);
      }

      toast({
        title: 'Paiement effectué',
        description: `Votre paiement pour ${payment.tournament_title} a été enregistré.`,
      });

      // Remove from list
      setPendingPayments(prev => prev.filter(p => p.id !== payment.id));
      onPaymentComplete?.();

    } catch (error) {
      console.error('Payment error:', error);
      toast({
        variant: 'destructive',
        title: 'Erreur',
        description: error instanceof Error
          ? `Impossible d'effectuer le paiement. (${error.message})`
          : "Impossible d'effectuer le paiement.",
      });
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return null;
  }

  if (pendingPayments.length === 0) {
    return null;
  }

  return (
    <Card className="border-warning bg-warning/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-warning">
          <AlertCircle className="h-5 w-5" />
          Paiements en attente
        </CardTitle>
        <CardDescription>
          Votre coéquipier vous a inscrit à un tournoi. Réglez votre part pour confirmer l'inscription.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pendingPayments.map((payment) => (
            <div 
              key={payment.id} 
              className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-lg border bg-background"
            >
              <div className="flex-1">
                <Link 
                  to={`/tournaments/${payment.tournament_id}`}
                  className="font-medium hover:text-primary transition-colors"
                >
                  {payment.tournament_title}
                </Link>
                <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {format(new Date(payment.tournament_date), 'd MMM yyyy', { locale: fr })}
                  </span>
                  {payment.tournament_city && (
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {payment.tournament_city}
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Inscrit par {payment.partner_name}
                </p>
              </div>
              
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="flex flex-col items-end">
                  <Badge variant="secondary" className="text-lg px-3 py-1">
                    <Euro className="h-4 w-4 mr-1" />
                    {payment.price}€
                  </Badge>
                  <span className="text-[11px] text-muted-foreground mt-1">Inclut +{PADEL_CUP_FEE_PER_PLAYER_EUR}€ frais Padel Cup</span>
                </div>
                <Button 
                  onClick={() => handlePayment(payment)}
                  disabled={processingId === payment.id}
                  className="flex-1 sm:flex-none"
                >
                  {processingId === payment.id ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <CreditCard className="h-4 w-4 mr-2" />
                  )}
                  Payer ma part
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
