import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Trophy, Calendar, MapPin, Users, ChevronRight, History, XCircle, AlertTriangle } from 'lucide-react';
import { format, differenceInHours, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface TournamentParticipation {
  id: string;
  tournament_id: string;
  partner_name: string | null;
  result: string | null;
  ranking_position: number | null;
  created_at: string;
  tournament?: {
    id: string;
    title: string;
    start_date: string;    start_date?: string | null;
    end_date: string;
    city: string | null;
    category_code: string | null;
  };
}

interface TournamentHistoryCardProps {
  participations: TournamentParticipation[];
  playerId: string;
  playerEmail: string;
  onParticipationCancelled: (participationId: string, tournamentId: string) => void;
}

export function TournamentHistoryCard({ 
  participations, 
  playerId, 
  playerEmail,
  onParticipationCancelled 
}: TournamentHistoryCardProps) {
  const { toast } = useToast();
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [selectedParticipation, setSelectedParticipation] = useState<TournamentParticipation | null>(null);

  const canCancel = (participation: TournamentParticipation): boolean => {
    if (!participation.tournament?.start_date) return false;
    const startIso = participation.tournament.start_date ? `${participation.tournament.start_date}T09:00:00` : null;
    const startDate = parseISO(startIso);
    const hoursUntilStart = differenceInHours(startDate, new Date());
    return hoursUntilStart >= 48;
  };

  const getHoursUntilStart = (participation: TournamentParticipation): number => {
    if (!participation.tournament?.start_date) return 0;
    const startIso = participation.tournament.start_date ? `${participation.tournament.start_date}T09:00:00` : null;
    const startDate = parseISO(startIso);
    return differenceInHours(startDate, new Date());
  };

  const handleCancelClick = (participation: TournamentParticipation) => {
    setSelectedParticipation(participation);
    setShowCancelDialog(true);
  };

  const handleConfirmCancel = async () => {
    if (!selectedParticipation) return;

    setCancellingId(selectedParticipation.id);
    try {
      const tournamentId = selectedParticipation.tournament_id;

      // Find the team linked to this player for this tournament (schema uses tournament_teams emails)
const normalizedEmail = (playerEmail || '').trim().toLowerCase();
const { data: teamRow, error: teamError } = await supabase
  .from('tournament_teams')
  .select('id, status')
  .eq('tournament_id', tournamentId)
  .or(`player1_email.ilike.${normalizedEmail},player2_email.ilike.${normalizedEmail}`)
  .maybeSingle();

if (teamError || !teamRow?.id) {
  console.error('Team fetch error:', teamError);
  throw teamError ?? new Error('Team not found');
}

// Cancel = remove registration (DB triggers can promote waitlist)
const { error: cancelError } = await supabase
  .from('tournament_teams')
  .delete()
  .eq('id', teamRow.id);

if (cancelError) throw cancelError;

toast({
  title: 'Inscription annulée',
  description: "L'inscription de votre équipe a été annulée avec succès.",
});

onParticipationCancelled(selectedParticipation.id, selectedParticipation.tournament_id);
} catch (error) {
      console.error('Cancel error:', error);
      toast({
        variant: 'destructive',
        title: 'Erreur',
        description: "Impossible d'annuler l'inscription.",
      });
    } finally {
      setCancellingId(null);
      setShowCancelDialog(false);
      setSelectedParticipation(null);
    }
  };

  const isPastTournament = (participation: TournamentParticipation): boolean => {
    if (!participation.tournament?.end_date) return false;
    return new Date(participation.tournament.end_date) < new Date();
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Mes tournois
          </CardTitle>
          <CardDescription>Gérez vos inscriptions aux tournois</CardDescription>
        </CardHeader>
        <CardContent>
          {participations.length === 0 ? (
            <div className="text-center py-8">
              <Trophy className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">Aucun tournoi inscrit</p>
              <Button className="mt-4" asChild>
                <Link to="/tournaments">Trouver un tournoi</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {participations.map((participation) => {
                const past = isPastTournament(participation);
                const cancellable = canCancel(participation);
                const hoursLeft = getHoursUntilStart(participation);
                
                return (
                  <div 
                    key={participation.id} 
                    className="flex items-center justify-between p-4 rounded-lg border hover:border-primary hover:bg-muted/50 transition-colors"
                  >
                    <Link 
                      to={`/tournaments/${participation.tournament_id}`}
                      className="flex items-center gap-4 flex-1"
                    >
                      <div className={`p-2 rounded-full ${past ? 'bg-muted' : 'bg-primary/10'}`}>
                        <Trophy className={`h-5 w-5 ${past ? 'text-muted-foreground' : 'text-primary'}`} />
                      </div>
                      <div>
                        <p className={`font-medium ${past ? 'text-muted-foreground' : ''}`}>
                          {participation.tournament?.title || 'Tournoi'}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          {participation.tournament?.start_date && (
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(participation.tournament.start_date), 'd MMM yyyy', { locale: fr })}
                            </span>
                          )}
                          {participation.tournament?.city && (
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {participation.tournament.city}
                            </span>
                          )}
                        </div>
                        {participation.partner_name && (
                          <p className="text-xs text-muted-foreground mt-1">
                            <Users className="h-3 w-3 inline mr-1" />
                            Partenaire: {participation.partner_name}
                          </p>
                        )}
                      </div>
                    </Link>
                    
                    <div className="flex items-center gap-2">
                      {participation.tournament?.category_code && (
                        <Badge variant="outline">{participation.tournament.category_code}</Badge>
                      )}
                      {participation.ranking_position && (
                        <Badge variant="secondary">#{participation.ranking_position}</Badge>
                      )}
                      
                      {!past && (
                        cancellable ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={(e) => {
                              e.preventDefault();
                              handleCancelClick(participation);
                            }}
                            disabled={cancellingId === participation.id}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Annuler
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground flex items-center gap-1" title="Annulation possible jusqu'à 48h avant">
                            <AlertTriangle className="h-3 w-3" />
                            {hoursLeft > 0 ? `${hoursLeft}h` : 'Imminent'}
                          </span>
                        )
                      )}
                      
                      <Link to={`/tournaments/${participation.tournament_id}`}>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Annuler l'inscription de votre équipe ?</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir annuler l'inscription au tournoi 
              "{selectedParticipation?.tournament?.title}" ? 
              <strong className="block mt-2">Cette action annulera également l'inscription de votre partenaire.</strong>
              Cette action est irréversible et votre place sera libérée.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Non, garder</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleConfirmCancel}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Oui, annuler
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
