import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { usePlayerAuth } from '@/contexts/PlayerAuthContext';
import { Calendar, Copy, CreditCard, Mail, Users, XCircle } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { playerTotalPrice } from '@/lib/fees';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

type TeamStatus = 'confirmed' | 'pending' | 'waiting';

interface TeamRow {
  id: string;
  tournament_id: string;
  name: string;
  player1_email: string | null;
  player2_email: string | null;
  player1_name: string;
  player2_name: string | null;
  player1_payment_status: string | null;
  player2_payment_status: string | null;
  status: TeamStatus;
  tournament: {
    title: string;
    start_date: string;
    city: string | null;
    price: number | null;
    draw_locked: boolean;
    club: {
      name: string;
      email: string;
    } | null;
  } | null;
}

export interface PlayerTeamCardProps {
  tournamentId: string;
  onTeamLoaded?: (team: TeamRow | null) => void;
}

function statusBadge(status: TeamStatus) {
  switch (status) {
    case 'confirmed':
      return <Badge className="bg-success/10 text-success">Confirmée</Badge>;
    case 'pending':
      return <Badge className="bg-warning/10 text-warning">En attente de paiement</Badge>;
    case 'waiting':
      return <Badge variant="secondary">Liste d'attente</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function paymentChip(label: string, status: string | null) {
  const paid = status === 'paid';
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${paid ? 'bg-success/10 text-success border-success/20' : 'bg-muted text-muted-foreground'}`}>
      <CreditCard className="h-3 w-3" />
      {label}: {paid ? 'Payé' : 'À payer'}
    </span>
  );
}

export function PlayerTeamCard({ tournamentId, onTeamLoaded }: PlayerTeamCardProps) {
  const { toast } = useToast();
  const { player, isAuthenticated } = usePlayerAuth();
  const [team, setTeam] = useState<TeamRow | null>(null);
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [showCancel, setShowCancel] = useState(false);

  const playerEmail = player?.email ?? '';

  const fetchTeam = async () => {
    if (!isAuthenticated || !playerEmail) return;
    setLoading(true);

    const baseSelect = `
      id,
      tournament_id,
      name,
      player1_email,
      player2_email,
      player1_name,
      player2_name,
      player1_payment_status,
      player2_payment_status,
      status,
      tournament:club_tournaments (
        title,
        start_date,
        city,
        price,
        draw_locked,
        club:clubs (
          name,
          email
        )
      )
    `;

    // Try player1 then player2 (RLS-friendly and deterministic)
    const { data: asP1 } = await supabase
      .from('tournament_teams')
      .select(baseSelect)
      .eq('tournament_id', tournamentId)
      .eq('player1_email', playerEmail)
      .maybeSingle();

    if (asP1?.id) {
      setTeam(asP1 as any);
      onTeamLoaded?.(asP1 as any);
      setLoading(false);
      return;
    }

    const { data: asP2 } = await supabase
      .from('tournament_teams')
      .select(baseSelect)
      .eq('tournament_id', tournamentId)
      .eq('player2_email', playerEmail)
      .maybeSingle();

    setTeam((asP2 as any) ?? null);
    onTeamLoaded?.(((asP2 as any) ?? null) as any);
    setLoading(false);
  };

  useEffect(() => {
    fetchTeam();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tournamentId, isAuthenticated, playerEmail]);

  useEffect(() => {
    if (!team?.id) return;
    const ch = supabase
      .channel(`player-team-${team.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tournament_teams', filter: `id=eq.${team.id}` }, () => {
        fetchTeam();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [team?.id]);

  const isP1 = useMemo(() => {
    return (team?.player1_email ?? '').toLowerCase() === playerEmail.toLowerCase();
  }, [team?.player1_email, playerEmail, team]);

  const myPaid = (isP1 ? team?.player1_payment_status : team?.player2_payment_status) === 'paid';
  const partnerPaid = (isP1 ? team?.player2_payment_status : team?.player1_payment_status) === 'paid';
  const partnerName = isP1 ? team?.player2_name : team?.player1_name;
  const basePerPlayer = team?.tournament?.price ?? 40;
  const myShare = playerTotalPrice(basePerPlayer);

  const copyLink = async () => {
    const url = `${window.location.origin}/tournaments/${tournamentId}`;
    await navigator.clipboard.writeText(url);
    toast({ title: 'Lien copié', description: 'Envoyez-le à votre partenaire pour qu’il puisse payer.' });
  };

  const payMyShare = async () => {
    if (!team) return;
    const field = isP1 ? 'player1_payment_status' : 'player2_payment_status';
    setProcessing(true);
    try {
      const { error } = await supabase.from('tournament_teams').update({ [field]: 'paid' } as any).eq('id', team.id);
      if (error) throw error;

      const { data: refreshed } = await supabase
        .from('tournament_teams')
        .select('player1_payment_status, player2_payment_status')
        .eq('id', team.id)
        .single();

      if (refreshed?.player1_payment_status === 'paid' && refreshed?.player2_payment_status === 'paid') {
        await supabase.from('tournament_teams').update({ status: 'confirmed' }).eq('id', team.id);
      }

      toast({ title: 'Paiement enregistré', description: 'Votre part est marquée comme payée.' });
      await fetchTeam();
    } catch (e) {
      console.error(e);
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible d’enregistrer le paiement.' });
    } finally {
      setProcessing(false);
    }
  };

  const requestCancel = () => setShowCancel(true);

  const confirmCancel = async () => {
    if (!team || !player?.id) return;
    setProcessing(true);
    try {
      const { error: rpcError } = await supabase.rpc('cancel_team_and_promote_waitlist', {
        p_team_id: team.id,
        p_player_id: player.id,
      });

      if (rpcError) {
        const msg = rpcError.message ?? '';
        if (msg.includes('draw_locked')) {
          toast({
            variant: 'destructive',
            title: 'Annulation impossible',
            description: "Le tirage a été validé. Contactez l'organisateur pour déclarer un forfait.",
          });
          return;
        }

if (msg.includes('draw_locked_no_waitlist')) {
  toast({
    variant: 'destructive',
    title: 'Annulation impossible',
    description: "Le tirage est validé et il n'y a personne en liste d'attente pour remplacer l'équipe.",
  });
  return;
}

        if (msg.includes('too_late_to_cancel')) {
          toast({
            variant: 'destructive',
            title: 'Annulation impossible',
            description: "L'annulation est possible uniquement jusqu'à 48h avant le début du tournoi.",
          });
          return;
        }
        throw rpcError;
      }

      toast({ title: 'Désinscription effectuée', description: 'Votre équipe a été retirée de ce tournoi.' });
      setTeam(null);
      onTeamLoaded?.(null);
    } catch (e) {
      console.error(e);
      toast({ variant: 'destructive', title: 'Erreur', description: "Impossible d'annuler l'inscription." });
    } finally {
      setProcessing(false);
      setShowCancel(false);
    }
  };

  if (!isAuthenticated) return null;
  if (loading) return null;
  if (!team) return null;

  const drawLocked = !!team.tournament?.draw_locked;
  const orgEmail = team.tournament?.club?.email ?? '';
  const orgName = team.tournament?.club?.name ?? 'le club';

  return (
    <Card>
      <CardHeader>
        <CardTitle>Mon équipe</CardTitle>
        <CardDescription>Statut, paiements et actions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {drawLocked && (
          <div className="rounded-lg border bg-muted/40 p-3 text-sm">
            <p className="font-medium">Tirage validé</p>
            <p className="text-muted-foreground">En cas de forfait, contactez {orgName}{orgEmail ? ` (${orgEmail})` : ''}.</p>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{team.name}</span>
              {statusBadge(team.status)}
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              {team.tournament?.start_date && (
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {format(new Date(team.tournament.start_date), 'd MMM yyyy', { locale: fr })}
                </span>
              )}
              <span className="inline-flex items-center gap-1">
                <Users className="h-3 w-3" />
                Partenaire : {partnerName ?? '—'}
              </span>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {paymentChip('Vous', isP1 ? team.player1_payment_status : team.player2_payment_status)}
              {paymentChip('Partenaire', isP1 ? team.player2_payment_status : team.player1_payment_status)}
            </div>
          </div>

          <div className="flex flex-col sm:items-end gap-2">
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyLink}>
                <Copy className="h-4 w-4 mr-2" />
                Copier le lien
              </Button>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/player/dashboard">Mon espace</Link>
              </Button>
            </div>

            {team.status !== 'waiting' && !myPaid && (
              <Button size="sm" onClick={payMyShare} disabled={processing} className="w-full sm:w-auto">
                <CreditCard className="h-4 w-4 mr-2" />
                Payer mon inscription ({myShare}€)
              </Button>
            )}

            {team.status !== 'waiting' && myPaid && !partnerPaid && (
              <p className="text-xs text-muted-foreground">En attente du paiement de votre partenaire</p>
            )}
            {team.status === 'confirmed' && (
              <p className="text-xs text-success">✅ Équipe confirmée</p>
            )}

            {/* Cancellation */}
            <div className="pt-1">
              <Button
                variant="destructive"
                size="sm"
                onClick={requestCancel}
                disabled={processing || drawLocked}
                className="w-full sm:w-auto"
              >
                <XCircle className="h-4 w-4 mr-2" />
                Se désinscrire
              </Button>
              {drawLocked && orgEmail && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full sm:w-auto mt-2"
                  asChild
                >
                  <a href={`mailto:${orgEmail}`}>
                    <Mail className="h-4 w-4 mr-2" />
                    Contacter le club
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>

        <AlertDialog open={showCancel} onOpenChange={setShowCancel}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmer la désinscription</AlertDialogTitle>
              <AlertDialogDescription>
                Votre équipe sera retirée du tournoi. Si une liste d'attente existe, une équipe pourra être promue.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={processing}>Annuler</AlertDialogCancel>
              <AlertDialogAction onClick={confirmCancel} disabled={processing}>
                Confirmer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
}
