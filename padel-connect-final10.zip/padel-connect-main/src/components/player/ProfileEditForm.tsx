import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { isValidFftLicenseNumber } from '@/lib/license';
import { User, Phone, CreditCard, Calendar, MapPin, Lock, Save, X, Edit } from 'lucide-react';
import { frenchRegions } from '@/data/mockData';
import { z } from 'zod';

const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;

interface PlayerProfile {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  license_number: string | null;
  date_of_birth: string | null;
  ranking: string | null;
  city: string | null;
  region: string | null;
}

interface ProfileEditFormProps {
  profile: PlayerProfile;
  onUpdate: (updatedProfile: PlayerProfile) => void;
}

export function ProfileEditForm({ profile, onUpdate }: ProfileEditFormProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  
  const [formData, setFormData] = useState({
    first_name: profile.first_name,
    last_name: profile.last_name,
    phone: profile.phone || '',
    license_number: profile.license_number || '',
    date_of_birth: profile.date_of_birth || '',
    city: profile.city || '',
    region: profile.region || '',
    ranking: profile.ranking || '',
  });
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  const updateField = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (errors[field]) setErrors({ ...errors, [field]: '' });
  };

  const handleSaveProfile = async () => {
    // Validate required fields
    const newErrors: Record<string, string> = {};
    if (!formData.first_name.trim()) newErrors.first_name = 'Prénom requis';
    if (!formData.last_name.trim()) newErrors.last_name = 'Nom requis';
    if (!formData.phone.trim() || formData.phone.length < 10) newErrors.phone = 'Téléphone requis (min. 10 caractères)';
    if (!formData.date_of_birth) newErrors.date_of_birth = 'Date de naissance requise';
    if (!formData.city.trim()) newErrors.city = 'Ville requise';
    if (!formData.region) newErrors.region = 'Région requise';
    if (formData.license_number && !isValidFftLicenseNumber(formData.license_number)) newErrors.license_number = "Numéro de licence FFT invalide (7 chiffres puis 1 lettre)";
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('players')
        .update({
          first_name: formData.first_name,
          last_name: formData.last_name,
          phone: formData.phone || null,
          license_number: formData.license_number || null,
          date_of_birth: formData.date_of_birth || null,
          city: formData.city || null,
          region: formData.region || null,
          ranking: formData.ranking || null,
        })
        .eq('id', profile.id);

      if (error) throw error;

      onUpdate({
        ...profile,
        first_name: formData.first_name,
        last_name: formData.last_name,
        phone: formData.phone || null,
        license_number: formData.license_number || null,
        date_of_birth: formData.date_of_birth || null,
        city: formData.city || null,
        region: formData.region || null,
        ranking: formData.ranking || null,
      });

      toast({ title: 'Profil mis à jour !', description: 'Vos informations ont été enregistrées.' });
      setIsEditing(false);
    } catch (error) {
      console.error('Update error:', error);
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de mettre à jour le profil.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async () => {
    const newErrors: Record<string, string> = {};
    
    if (!passwordData.newPassword) {
      newErrors.newPassword = 'Nouveau mot de passe requis';
    } else if (!strongPasswordRegex.test(passwordData.newPassword)) {
      newErrors.newPassword = 'Min. 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial';
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword,
      });

      if (error) throw error;

      toast({ title: 'Mot de passe modifié !', description: 'Votre nouveau mot de passe a été enregistré.' });
      setShowPasswordChange(false);
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error) {
      console.error('Password change error:', error);
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de modifier le mot de passe.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      first_name: profile.first_name,
      last_name: profile.last_name,
      phone: profile.phone || '',
      license_number: profile.license_number || '',
      date_of_birth: profile.date_of_birth || '',
      city: profile.city || '',
      region: profile.region || '',
      ranking: profile.ranking || '',
    });
    setErrors({});
    setIsEditing(false);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Mon profil
          </CardTitle>
          <CardDescription>Gérez vos informations personnelles</CardDescription>
        </div>
        {!isEditing && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            <Edit className="h-4 w-4 mr-2" />
            Modifier
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {isEditing ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Prénom *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Jean" 
                    className="pl-10" 
                    value={formData.first_name} 
                    onChange={(e) => updateField('first_name', e.target.value)} 
                  />
                </div>
                {errors.first_name && <p className="text-sm text-destructive">{errors.first_name}</p>}
              </div>
              <div className="space-y-2">
                <Label>Nom *</Label>
                <Input 
                  placeholder="Dupont" 
                  value={formData.last_name} 
                  onChange={(e) => updateField('last_name', e.target.value)} 
                />
                {errors.last_name && <p className="text-sm text-destructive">{errors.last_name}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Téléphone *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="06 12 34 56 78" 
                  className="pl-10" 
                  value={formData.phone} 
                  onChange={(e) => updateField('phone', e.target.value)} 
                />
              </div>
              {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
            </div>

            <div className="space-y-2">
              <Label>Numéro de licence FFT</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="123456789 (optionnel)" 
                  className="pl-10" 
                  value={formData.license_number} 
                  onChange={(e) => updateField('license_number', e.target.value)} 
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Date de naissance *</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  type="date" 
                  className="pl-10" 
                  value={formData.date_of_birth} 
                  onChange={(e) => updateField('date_of_birth', e.target.value)} 
                />
              </div>
              {errors.date_of_birth && <p className="text-sm text-destructive">{errors.date_of_birth}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Ville *</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Paris" 
                    className="pl-10" 
                    value={formData.city} 
                    onChange={(e) => updateField('city', e.target.value)} 
                  />
                </div>
                {errors.city && <p className="text-sm text-destructive">{errors.city}</p>}
              </div>
              <div className="space-y-2">
                <Label>Région *</Label>
                <Select value={formData.region} onValueChange={(v) => updateField('region', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner" />
                  </SelectTrigger>
                  <SelectContent>
                    {frenchRegions.map((r) => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.region && <p className="text-sm text-destructive">{errors.region}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Classement</Label>
              <Input 
                placeholder="Ex: P25, P100..." 
                value={formData.ranking} 
                onChange={(e) => updateField('ranking', e.target.value)} 
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button variant="outline" className="flex-1" onClick={handleCancel} disabled={isLoading}>
                <X className="h-4 w-4 mr-2" />
                Annuler
              </Button>
              <Button className="flex-1" onClick={handleSaveProfile} disabled={isLoading}>
                <Save className="h-4 w-4 mr-2" />
                {isLoading ? 'Enregistrement...' : 'Enregistrer'}
              </Button>
            </div>
          </>
        ) : (
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b">
              <span className="text-sm text-muted-foreground">Nom complet</span>
              <span className="text-sm font-medium">{profile.first_name} {profile.last_name}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-sm text-muted-foreground">Email</span>
              <span className="text-sm">{profile.email}</span>
            </div>
            {profile.phone && (
              <div className="flex justify-between py-2 border-b">
                <span className="text-sm text-muted-foreground">Téléphone</span>
                <span className="text-sm">{profile.phone}</span>
              </div>
            )}
            {profile.license_number && (
              <div className="flex justify-between py-2 border-b">
                <span className="text-sm text-muted-foreground">Licence FFT</span>
                <span className="text-sm">{profile.license_number}</span>
              </div>
            )}
            {profile.date_of_birth && (
              <div className="flex justify-between py-2 border-b">
                <span className="text-sm text-muted-foreground">Date de naissance</span>
                <span className="text-sm">{new Date(profile.date_of_birth).toLocaleDateString('fr-FR')}</span>
              </div>
            )}
            {profile.ranking && (
              <div className="flex justify-between py-2 border-b">
                <span className="text-sm text-muted-foreground">Classement</span>
                <span className="text-sm">{profile.ranking}</span>
              </div>
            )}
            {(profile.city || profile.region) && (
              <div className="flex justify-between py-2 border-b">
                <span className="text-sm text-muted-foreground">Localisation</span>
                <span className="text-sm">{[profile.city, profile.region].filter(Boolean).join(', ')}</span>
              </div>
            )}
          </div>
        )}

        {/* Password change section */}
        <div className="pt-4 border-t">
          {!showPasswordChange ? (
            <Button variant="outline" className="w-full" onClick={() => setShowPasswordChange(true)}>
              <Lock className="h-4 w-4 mr-2" />
              Modifier le mot de passe
            </Button>
          ) : (
            <div className="space-y-4">
              <h4 className="font-medium flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Changer le mot de passe
              </h4>
              <div className="space-y-2">
                <Label>Nouveau mot de passe *</Label>
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  value={passwordData.newPassword}
                  onChange={(e) => {
                    setPasswordData({ ...passwordData, newPassword: e.target.value });
                    if (errors.newPassword) setErrors({ ...errors, newPassword: '' });
                  }}
                />
                <p className="text-xs text-muted-foreground">
                  Min. 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial
                </p>
                {errors.newPassword && <p className="text-sm text-destructive">{errors.newPassword}</p>}
              </div>
              <div className="space-y-2">
                <Label>Confirmer le mot de passe *</Label>
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  value={passwordData.confirmPassword}
                  onChange={(e) => {
                    setPasswordData({ ...passwordData, confirmPassword: e.target.value });
                    if (errors.confirmPassword) setErrors({ ...errors, confirmPassword: '' });
                  }}
                />
                {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={() => {
                    setShowPasswordChange(false);
                    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
                    setErrors({});
                  }}
                  disabled={isLoading}
                >
                  Annuler
                </Button>
                <Button className="flex-1" onClick={handleChangePassword} disabled={isLoading}>
                  {isLoading ? 'Modification...' : 'Modifier'}
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
