-- Enable realtime for tournament_teams to sync payment status
ALTER PUBLICATION supabase_realtime ADD TABLE public.tournament_teams;