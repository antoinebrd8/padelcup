-- FFT compliance: store the judge-arbitre level on tournaments

DO $$ BEGIN
  CREATE TYPE public.referee_level AS ENUM ('JAP1', 'JAP2', 'JAT3', 'INTERNATIONAL');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

ALTER TABLE public.club_tournaments
  ADD COLUMN IF NOT EXISTS referee_level public.referee_level;

COMMENT ON COLUMN public.club_tournaments.referee_level IS 'Niveau du juge-arbitre (FFT): JAP1/JAP2/JAT3/INTERNATIONAL';
