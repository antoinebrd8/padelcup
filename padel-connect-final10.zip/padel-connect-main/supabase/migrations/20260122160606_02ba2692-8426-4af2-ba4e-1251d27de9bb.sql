-- Allow authenticated players to insert registrations (teams) for tournaments
CREATE POLICY "Players can register for tournaments"
ON public.tournament_teams
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Allow anyone to view tournament teams (for public display)
CREATE POLICY "Anyone can view tournament teams"
ON public.tournament_teams
FOR SELECT
TO authenticated, anon
USING (true);

-- Allow players to update their own tournament participations
CREATE POLICY "Players can update their participations"
ON public.player_tournaments
FOR UPDATE
TO authenticated
USING (EXISTS (
  SELECT 1 FROM players
  WHERE players.id = player_tournaments.player_id
  AND players.user_id = auth.uid()
));

-- Allow players to delete their participations
CREATE POLICY "Players can delete their participations"
ON public.player_tournaments
FOR DELETE
TO authenticated
USING (EXISTS (
  SELECT 1 FROM players
  WHERE players.id = player_tournaments.player_id
  AND players.user_id = auth.uid()
));