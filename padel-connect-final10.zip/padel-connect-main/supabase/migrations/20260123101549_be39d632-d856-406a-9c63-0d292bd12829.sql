-- Add new columns to clubs table for complete registration info
ALTER TABLE public.clubs 
ADD COLUMN IF NOT EXISTS structure_type text,
ADD COLUMN IF NOT EXISTS legal_name text,
ADD COLUMN IF NOT EXISTS commercial_name text,
ADD COLUMN IF NOT EXISTS postal_code text,
ADD COLUMN IF NOT EXISTS country text DEFAULT 'France',
ADD COLUMN IF NOT EXISTS siren_siret text,
ADD COLUMN IF NOT EXISTS rna_number text,
ADD COLUMN IF NOT EXISTS representative_first_name text,
ADD COLUMN IF NOT EXISTS representative_last_name text,
ADD COLUMN IF NOT EXISTS representative_role text,
ADD COLUMN IF NOT EXISTS representative_email text,
ADD COLUMN IF NOT EXISTS representative_phone text,
ADD COLUMN IF NOT EXISTS registration_status text DEFAULT 'pending';

-- Add comment to explain the columns
COMMENT ON COLUMN public.clubs.structure_type IS 'Type: association or company';
COMMENT ON COLUMN public.clubs.siren_siret IS 'SIREN/SIRET number for companies';
COMMENT ON COLUMN public.clubs.rna_number IS 'RNA number for associations (format: WXXXXXXXXX)';
COMMENT ON COLUMN public.clubs.registration_status IS 'Status: pending, verified, rejected';