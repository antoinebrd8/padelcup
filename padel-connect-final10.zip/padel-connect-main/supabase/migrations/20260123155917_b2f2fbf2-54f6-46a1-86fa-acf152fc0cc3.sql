-- Add payment and license tracking fields to tournament_teams
ALTER TABLE public.tournament_teams
ADD COLUMN IF NOT EXISTS player1_payment_status text DEFAULT 'pending' CHECK (player1_payment_status IN ('pending', 'paid')),
ADD COLUMN IF NOT EXISTS player2_payment_status text DEFAULT 'pending' CHECK (player2_payment_status IN ('pending', 'paid')),
ADD COLUMN IF NOT EXISTS player1_has_license boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS player2_has_license boolean DEFAULT true;