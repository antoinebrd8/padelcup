-- Drop the restrictive INSERT policy
DROP POLICY IF EXISTS "Players can add their participations" ON public.player_tournaments;

-- Create a new INSERT policy that allows authenticated players to create participation records
-- This allows a player to register both themselves and their partner
CREATE POLICY "Authenticated players can add participations"
ON public.player_tournaments
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Keep the existing SELECT policy (anyone can view)
-- Keep the existing UPDATE/DELETE policies (only own records)