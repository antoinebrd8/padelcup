-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Authenticated players can add participations" ON public.player_tournaments;

-- Create a more secure INSERT policy
-- Allow authenticated users with a player profile to insert participations
-- for any player (needed to register partners)
CREATE POLICY "Players can add tournament participations"
ON public.player_tournaments
FOR INSERT
TO authenticated
WITH CHECK (
  -- User must have a player profile to insert participations
  EXISTS (
    SELECT 1 FROM players WHERE players.user_id = auth.uid()
  )
);