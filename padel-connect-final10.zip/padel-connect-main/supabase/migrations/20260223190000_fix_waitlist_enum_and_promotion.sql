-- Fix waitlist promotion triggers for the current `team_status` enum.
--
-- Context:
-- Some databases use `team_status` values: ('unnest', 'confirmed', 'waiting')
-- instead of ('pending', 'confirmed', 'waiting'). If the triggers/functions still
-- reference 'pending' or 'cancelled', promotions fail and teams remain stuck in
-- the waitlist.

-- 1) Capacity + status enforcement (no more 'pending' status)
create or replace function public.enforce_team_status_and_capacity()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  v_max_teams integer;
  v_active_count integer;
  v_needs_two_payments boolean;
begin
  -- Lock the tournament row to avoid race conditions on capacity
  select max_teams
    into v_max_teams
  from public.club_tournaments
  where id = new.tournament_id
  for update;

  v_needs_two_payments := (new.player2_name is not null and btrim(new.player2_name) <> '');

  -- If someone tries to set confirmed without full payments, fall back to 'unnest'
  if new.status = 'confirmed'::team_status then
    if new.player1_payment_status is distinct from 'paid'
       or (v_needs_two_payments and new.player2_payment_status is distinct from 'paid') then
      new.status := 'unnest'::team_status;
    end if;
  end if;

  -- Capacity applies to active teams (confirmed + unnest)
  if v_max_teams is not null and v_max_teams > 0 then
    if new.status in ('confirmed'::team_status, 'unnest'::team_status) then
      select count(*)
        into v_active_count
      from public.tournament_teams
      where tournament_id = new.tournament_id
        and status in ('confirmed'::team_status, 'unnest'::team_status)
        and id <> new.id;

      if v_active_count >= v_max_teams then
        new.status := 'waiting'::team_status;
      end if;
    end if;
  end if;

  return new;
end;
$$;

do $$
begin
  if exists (select 1 from pg_trigger where tgname = 'trg_enforce_team_status_and_capacity') then
    drop trigger trg_enforce_team_status_and_capacity on public.tournament_teams;
  end if;
  create trigger trg_enforce_team_status_and_capacity
    before insert or update of status, player1_payment_status, player2_payment_status, tournament_id
    on public.tournament_teams
    for each row
    execute function public.enforce_team_status_and_capacity();
end $$;


-- 2) Waitlist promotion helper
create or replace function public.promote_waitlist_if_slot()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  v_tournament_id uuid;
  v_max_teams integer;
  v_active_count integer;
  v_waiting_id uuid;
begin
  v_tournament_id := coalesce(old.tournament_id, new.tournament_id);
  if v_tournament_id is null then
    return null;
  end if;

  select coalesce(max_teams, 0)
    into v_max_teams
  from public.club_tournaments
  where id = v_tournament_id;

  if v_max_teams is null or v_max_teams <= 0 then
    return null;
  end if;

  select count(*)
    into v_active_count
  from public.tournament_teams
  where tournament_id = v_tournament_id
    and status in ('confirmed'::team_status, 'unnest'::team_status);

  -- Promote only if we have a free slot
  if v_active_count < v_max_teams then
    select id
      into v_waiting_id
    from public.tournament_teams
    where tournament_id = v_tournament_id
      and status = 'waiting'::team_status
    order by created_at asc
    limit 1;

    if v_waiting_id is not null then
      update public.tournament_teams
        set status = 'unnest'::team_status,
            updated_at = now()
      where id = v_waiting_id;
    end if;
  end if;

  return null;
end;
$$;

-- Trigger after DELETE: if an active team is removed, promote next waiting team
do $$
begin
  if exists (select 1 from pg_trigger where tgname = 'trg_promote_waitlist_after_delete') then
    drop trigger trg_promote_waitlist_after_delete on public.tournament_teams;
  end if;
  create trigger trg_promote_waitlist_after_delete
    after delete on public.tournament_teams
    for each row
    execute function public.promote_waitlist_if_slot();
end $$;

-- Trigger after UPDATE(status): when a team leaves active statuses, promote next
do $$
begin
  if exists (select 1 from pg_trigger where tgname = 'trg_promote_waitlist_after_update') then
    drop trigger trg_promote_waitlist_after_update on public.tournament_teams;
  end if;
  create trigger trg_promote_waitlist_after_update
    after update of status on public.tournament_teams
    for each row
    when (
      old.status in ('confirmed'::team_status, 'unnest'::team_status)
      and new.status not in ('confirmed'::team_status, 'unnest'::team_status)
    )
    execute function public.promote_waitlist_if_slot();
end $$;
