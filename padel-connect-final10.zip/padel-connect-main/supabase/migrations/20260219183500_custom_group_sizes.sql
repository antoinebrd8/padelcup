-- Add custom group sizing configuration for organisers (uneven groups like 4,4,3)
ALTER TABLE public.club_tournaments
  ADD COLUMN IF NOT EXISTS use_custom_groups boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS group_sizes_csv text;

-- Optional: ensure default value is not null for existing rows
UPDATE public.club_tournaments
SET use_custom_groups = COALESCE(use_custom_groups, false);
