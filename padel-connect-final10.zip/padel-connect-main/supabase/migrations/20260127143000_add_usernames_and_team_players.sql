-- Add username support and prevent duplicate tournament registrations

-- 1) Players: add username
ALTER TABLE public.players
  ADD COLUMN IF NOT EXISTS username TEXT;

-- Unique index (case-insensitive) for username when not null
CREATE UNIQUE INDEX IF NOT EXISTS players_username_unique
  ON public.players (LOWER(username))
  WHERE username IS NOT NULL;

-- 2) Tournament teams: store usernames as display snapshots
ALTER TABLE public.tournament_teams
  ADD COLUMN IF NOT EXISTS player1_username TEXT,
  ADD COLUMN IF NOT EXISTS player2_username TEXT;

-- 3) Link table to guarantee a player can only be registered once per tournament
CREATE TABLE IF NOT EXISTS public.tournament_team_players (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id UUID NOT NULL REFERENCES public.club_tournaments(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES public.tournament_teams(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES public.players(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (tournament_id, player_id)
);

ALTER TABLE public.tournament_team_players ENABLE ROW LEVEL SECURITY;

-- Players can see their own link rows
CREATE POLICY IF NOT EXISTS "Players can view their own tournament_team_players"
  ON public.tournament_team_players
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.players p
    WHERE p.id = tournament_team_players.player_id
      AND p.user_id = auth.uid()
  ));

-- Club owners can view link rows for their tournaments
CREATE POLICY IF NOT EXISTS "Club owners can view tournament_team_players"
  ON public.tournament_team_players
  FOR SELECT
  USING (EXISTS (
    SELECT 1
    FROM public.club_tournaments ct
    JOIN public.clubs c ON c.id = ct.club_id
    WHERE ct.id = tournament_team_players.tournament_id
      AND c.user_id = auth.uid()
  ));

-- Allow players to insert/delete link rows for teams that include their email
CREATE POLICY IF NOT EXISTS "Players can insert tournament_team_players for their team"
  ON public.tournament_team_players
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1
    FROM public.tournament_teams tt
    WHERE tt.id = tournament_team_players.team_id
      AND tt.tournament_id = tournament_team_players.tournament_id
      AND (
        tt.player1_email = (auth.jwt() ->> 'email')
        OR tt.player2_email = (auth.jwt() ->> 'email')
      )
  ));

CREATE POLICY IF NOT EXISTS "Players can delete tournament_team_players for their team"
  ON public.tournament_team_players
  FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1
    FROM public.tournament_teams tt
    WHERE tt.id = tournament_team_players.team_id
      AND tt.tournament_id = tournament_team_players.tournament_id
      AND (
        tt.player1_email = (auth.jwt() ->> 'email')
        OR tt.player2_email = (auth.jwt() ->> 'email')
      )
  ));

-- NOTE: Inserts/Deletes should be done via server-side RPC in production.
