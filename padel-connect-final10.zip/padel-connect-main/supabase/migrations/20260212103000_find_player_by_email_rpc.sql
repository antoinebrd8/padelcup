-- Find a player by email for tournament registrations
-- Uses SECURITY DEFINER to perform a case-insensitive lookup even if the `players` table has RLS.

create or replace function public.find_player_by_email(p_email text)
returns table(
  id uuid,
  first_name text,
  last_name text,
  email text,
  license_number text
)
language sql
security definer
set search_path = public
set row_security = off
as $$
  select
    p.id,
    p.first_name,
    p.last_name,
    p.email,
    p.license_number
  from public.players p
  where lower(trim(p.email)) = lower(trim(p_email))
  limit 1;
$$;

grant execute on function public.find_player_by_email(text) to authenticated;
