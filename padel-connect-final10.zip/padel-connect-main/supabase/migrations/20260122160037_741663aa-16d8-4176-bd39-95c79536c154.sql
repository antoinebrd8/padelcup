-- Allow anyone to view all tournaments (for public listing)
CREATE POLICY "Anyone can view tournaments"
ON public.club_tournaments
FOR SELECT
TO authenticated, anon
USING (true);