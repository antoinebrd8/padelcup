-- Create enum for game formats
CREATE TYPE public.game_format AS ENUM (
  'A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'D1', 'D2', 'E', 'F'
);

-- Add game_format column to club_tournaments table
ALTER TABLE public.club_tournaments 
ADD COLUMN game_format public.game_format DEFAULT 'B1';

-- Add comment for documentation
COMMENT ON COLUMN public.club_tournaments.game_format IS 'Format de jeu normalisé: A1/A2 (3 sets), B1/B2 (2 sets + super TB), C1/C2 (2 sets courts), D1/D2 (1 set 9 jeux), E (super TB), F (1 set court)';