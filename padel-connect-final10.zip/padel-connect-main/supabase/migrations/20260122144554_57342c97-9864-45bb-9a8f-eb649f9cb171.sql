-- Create storage bucket for tournament images
INSERT INTO storage.buckets (id, name, public) VALUES ('tournament-images', 'tournament-images', true);

-- Allow anyone to view tournament images (public bucket)
CREATE POLICY "Tournament images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'tournament-images');

-- Allow club owners to upload tournament images
CREATE POLICY "Club owners can upload tournament images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'tournament-images' 
  AND auth.uid() IS NOT NULL
);

-- Allow club owners to update their tournament images
CREATE POLICY "Club owners can update tournament images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'tournament-images' 
  AND auth.uid() IS NOT NULL
);

-- Allow club owners to delete their tournament images
CREATE POLICY "Club owners can delete tournament images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'tournament-images' 
  AND auth.uid() IS NOT NULL
);

-- Add referee_name column to club_tournaments
ALTER TABLE public.club_tournaments 
ADD COLUMN IF NOT EXISTS referee_name TEXT;