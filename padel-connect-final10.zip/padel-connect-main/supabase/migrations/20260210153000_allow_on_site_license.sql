-- Allow organizer to indicate whether license can be purchased on site.
-- If true, unlicensed players may register.

ALTER TABLE public.club_tournaments
ADD COLUMN IF NOT EXISTS allow_on_site_license boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN public.club_tournaments.allow_on_site_license IS 'If true, unlicensed players may register (license can be purchased on site).';
