-- Fix email lookup to be resilient to whitespace in stored emails
-- and make cancellation RPC backward-compatible with older teams missing tournament_team_players rows.

-- 1) More robust teammate lookup by email
CREATE OR REPLACE FUNCTION public.find_player_by_email(p_email TEXT)
RETURNS TABLE(
  id UUID,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  license_number TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
  SELECT
    p.id,
    p.first_name,
    p.last_name,
    p.email,
    p.license_number
  FROM public.players p
  WHERE lower(trim(p.email)) = lower(trim(p_email))
  LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION public.find_player_by_email(TEXT) TO authenticated;

-- 2) Backward-compatible cancellation:
-- If tournament_team_players rows are missing for this team (older data),
-- derive player ids from team emails in tournament_teams.
CREATE OR REPLACE FUNCTION public.cancel_team_and_promote_waitlist(
  p_team_id UUID,
  p_player_id UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tournament_id UUID;
  v_start_at TIMESTAMPTZ;
  v_draw_locked BOOLEAN;
  v_team_player_ids UUID[];
  v_p1_email TEXT;
  v_p2_email TEXT;
BEGIN
  -- Tournament + lock + start time + snapshot emails
  SELECT tt.tournament_id, ct.start_at, ct.draw_locked, tt.player1_email, tt.player2_email
    INTO v_tournament_id, v_start_at, v_draw_locked, v_p1_email, v_p2_email
  FROM public.tournament_teams tt
  JOIN public.club_tournaments ct ON ct.id = tt.tournament_id
  WHERE tt.id = p_team_id;

  IF v_tournament_id IS NULL THEN
    RAISE EXCEPTION 'team_not_found';
  END IF;

  IF v_draw_locked IS TRUE THEN
    RAISE EXCEPTION 'draw_locked';
  END IF;

  -- All players linked to that team (new schema)
  SELECT ARRAY_AGG(player_id)
    INTO v_team_player_ids
  FROM public.tournament_team_players
  WHERE team_id = p_team_id;

  -- Fallback for older teams: derive player ids from team emails
  IF v_team_player_ids IS NULL OR ARRAY_LENGTH(v_team_player_ids, 1) IS NULL THEN
    SELECT ARRAY_AGG(p.id)
      INTO v_team_player_ids
    FROM public.players p
    WHERE (
      (v_p1_email IS NOT NULL AND lower(trim(p.email)) = lower(trim(v_p1_email)))
      OR (v_p2_email IS NOT NULL AND lower(trim(p.email)) = lower(trim(v_p2_email)))
    );
  END IF;

  IF v_team_player_ids IS NULL OR ARRAY_LENGTH(v_team_player_ids, 1) IS NULL THEN
    RAISE EXCEPTION 'team_players_not_found';
  END IF;

  -- Verify requester belongs to this team
  IF NOT (p_player_id = ANY(v_team_player_ids)) THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  -- 48h rule
  IF (v_start_at - NOW()) < INTERVAL '48 hours' THEN
    RAISE EXCEPTION 'too_late_to_cancel';
  END IF;

  -- Delete participations for all players in this team
  DELETE FROM public.player_tournaments
  WHERE tournament_id = v_tournament_id
    AND player_id = ANY(v_team_player_ids);

  -- Delete link rows if they exist (safe)
  DELETE FROM public.tournament_team_players
  WHERE team_id = p_team_id;

  -- Delete team
  DELETE FROM public.tournament_teams WHERE id = p_team_id;

  -- Promote the oldest waitlisted team
  UPDATE public.tournament_teams
     SET status = 'confirmed'
   WHERE id = (
     SELECT id
     FROM public.tournament_teams
     WHERE tournament_id = v_tournament_id
       AND status = 'waiting'
     ORDER BY created_at ASC
     LIMIT 1
   );
END;
$$;
