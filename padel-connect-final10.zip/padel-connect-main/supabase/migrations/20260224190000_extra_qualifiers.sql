-- Additional qualifiers across groups (best 2nd / best 3rd)

alter table public.club_tournaments
  add column if not exists extra_qualifiers_count integer default 0,
  add column if not exists extra_qualifiers_position integer;

-- Sanity defaults
update public.club_tournaments
set extra_qualifiers_count = coalesce(extra_qualifiers_count, 0)
where extra_qualifiers_count is null;
