-- FFT P25 -> P500: match result type impacts group standings points

alter table public.tournament_matches
  add column if not exists result_type text not null default 'normal',
  add column if not exists wo_justified boolean,
  add column if not exists admin_note text;

-- Keep it simple: allow only known values
do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'tournament_matches_result_type_check'
  ) then
    alter table public.tournament_matches
      add constraint tournament_matches_result_type_check
      check (result_type in ('normal','wo','dq','not_played'));
  end if;
end$$;
