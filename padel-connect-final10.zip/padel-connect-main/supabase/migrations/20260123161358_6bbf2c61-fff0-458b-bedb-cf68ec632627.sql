-- Allow players to delete tournament teams where they are registered
CREATE POLICY "Players can delete their own tournament teams"
ON public.tournament_teams
FOR DELETE
USING (
  player1_email IN (
    SELECT email FROM players WHERE user_id = auth.uid()
  )
  OR player2_email IN (
    SELECT email FROM players WHERE user_id = auth.uid()
  )
);