-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('club', 'player');

-- Create user_roles table for role management
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);

-- Create players table for player profiles
CREATE TABLE public.players (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    license_number TEXT,
    date_of_birth DATE,
    ranking TEXT,
    avatar_url TEXT,
    city TEXT,
    postal_code TEXT,
    region TEXT,
    latitude NUMERIC,
    longitude NUMERIC,
    bio TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on players
ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;

-- RLS policies for players
CREATE POLICY "Players can view all player profiles"
ON public.players
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Players can insert their own profile"
ON public.players
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Players can update their own profile"
ON public.players
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Players can delete their own profile"
ON public.players
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE TRIGGER update_players_updated_at
BEFORE UPDATE ON public.players
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create player_tournaments for tracking participation history
CREATE TABLE public.player_tournaments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    player_id UUID REFERENCES public.players(id) ON DELETE CASCADE NOT NULL,
    tournament_id UUID REFERENCES public.club_tournaments(id) ON DELETE CASCADE NOT NULL,
    partner_name TEXT,
    result TEXT,
    ranking_position INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (player_id, tournament_id)
);

-- Enable RLS on player_tournaments
ALTER TABLE public.player_tournaments ENABLE ROW LEVEL SECURITY;

-- RLS policies for player_tournaments
CREATE POLICY "Anyone can view tournament participations"
ON public.player_tournaments
FOR SELECT
USING (true);

CREATE POLICY "Players can add their participations"
ON public.player_tournaments
FOR INSERT
TO authenticated
WITH CHECK (EXISTS (
    SELECT 1 FROM public.players
    WHERE players.id = player_tournaments.player_id
    AND players.user_id = auth.uid()
));

-- Create favorite_partners table
CREATE TABLE public.favorite_partners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    player_id UUID REFERENCES public.players(id) ON DELETE CASCADE NOT NULL,
    partner_player_id UUID REFERENCES public.players(id) ON DELETE CASCADE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (player_id, partner_player_id)
);

-- Enable RLS on favorite_partners
ALTER TABLE public.favorite_partners ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Players can view their favorite partners"
ON public.favorite_partners
FOR SELECT
TO authenticated
USING (EXISTS (
    SELECT 1 FROM public.players
    WHERE players.id = favorite_partners.player_id
    AND players.user_id = auth.uid()
));

CREATE POLICY "Players can add favorite partners"
ON public.favorite_partners
FOR INSERT
TO authenticated
WITH CHECK (EXISTS (
    SELECT 1 FROM public.players
    WHERE players.id = favorite_partners.player_id
    AND players.user_id = auth.uid()
));

CREATE POLICY "Players can remove favorite partners"
ON public.favorite_partners
FOR DELETE
TO authenticated
USING (EXISTS (
    SELECT 1 FROM public.players
    WHERE players.id = favorite_partners.player_id
    AND players.user_id = auth.uid()
));