-- Add start_time + start_at and provide atomic cancellation that blocks when draw is locked

-- 1) Add start_time and start_at to tournaments
ALTER TABLE public.club_tournaments
  ADD COLUMN IF NOT EXISTS start_time TEXT,
  ADD COLUMN IF NOT EXISTS start_at TIMESTAMPTZ;

-- 2) Default start_time for existing rows
UPDATE public.club_tournaments
SET start_time = '09:00'
WHERE start_time IS NULL;

-- 3) Backfill start_at for existing rows (Europe/Paris)
UPDATE public.club_tournaments
SET start_at = ((start_date::timestamp + start_time::time) AT TIME ZONE 'Europe/Paris')
WHERE start_at IS NULL;

-- 4) Trigger to keep start_at in sync when start_date or start_time changes
CREATE OR REPLACE FUNCTION public.set_tournament_start_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- Ensure we always have a start_time
  IF NEW.start_time IS NULL THEN
    NEW.start_time := '09:00';
  END IF;

  NEW.start_at := ((NEW.start_date::timestamp + NEW.start_time::time) AT TIME ZONE 'Europe/Paris');
  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_set_tournament_start_at'
  ) THEN
    CREATE TRIGGER trg_set_tournament_start_at
    BEFORE INSERT OR UPDATE OF start_date, start_time
    ON public.club_tournaments
    FOR EACH ROW
    EXECUTE FUNCTION public.set_tournament_start_at();
  END IF;
END;
$$;

-- 5) Atomic cancellation RPC: cancels a whole team (pair) and promotes the first waitlisted team.
--    Blocks cancellation if draw_locked=true or if <48h before start.
CREATE OR REPLACE FUNCTION public.cancel_team_and_promote_waitlist(
  p_team_id UUID,
  p_player_id UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tournament_id UUID;
  v_start_at TIMESTAMPTZ;
  v_draw_locked BOOLEAN;
  v_team_player_ids UUID[];
BEGIN
  -- Tournament + lock + start time
  SELECT tt.tournament_id, ct.start_at, ct.draw_locked
    INTO v_tournament_id, v_start_at, v_draw_locked
  FROM public.tournament_teams tt
  JOIN public.club_tournaments ct ON ct.id = tt.tournament_id
  WHERE tt.id = p_team_id;

  IF v_tournament_id IS NULL THEN
    RAISE EXCEPTION 'team_not_found';
  END IF;

  IF v_draw_locked IS TRUE THEN
    RAISE EXCEPTION 'draw_locked';
  END IF;

  -- All players linked to that team
  SELECT ARRAY_AGG(player_id)
    INTO v_team_player_ids
  FROM public.tournament_team_players
  WHERE team_id = p_team_id;

  IF v_team_player_ids IS NULL OR ARRAY_LENGTH(v_team_player_ids, 1) IS NULL THEN
    RAISE EXCEPTION 'team_players_not_found';
  END IF;

  -- Verify requester belongs to this team
  IF NOT (p_player_id = ANY(v_team_player_ids)) THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  -- 48h rule
  IF (v_start_at - NOW()) < INTERVAL '48 hours' THEN
    RAISE EXCEPTION 'too_late_to_cancel';
  END IF;

  -- Delete participations for all players in this team
  DELETE FROM public.player_tournaments
  WHERE tournament_id = v_tournament_id
    AND player_id = ANY(v_team_player_ids);

  -- Delete team (will cascade tournament_team_players)
  DELETE FROM public.tournament_teams WHERE id = p_team_id;

  -- Promote the oldest waitlisted team (waiting = waitlist only)
  UPDATE public.tournament_teams
     SET status = 'confirmed'
   WHERE id = (
     SELECT id
     FROM public.tournament_teams
     WHERE tournament_id = v_tournament_id
       AND status = 'waiting'
     ORDER BY created_at ASC
     LIMIT 1
   );
END;
$$;
