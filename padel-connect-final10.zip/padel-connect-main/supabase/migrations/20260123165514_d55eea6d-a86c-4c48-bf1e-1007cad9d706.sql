-- Create a trigger to clean up player_tournaments when a tournament_team is deleted
CREATE OR REPLACE FUNCTION public.cleanup_player_tournaments_on_team_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete player_tournaments entries for both players of the deleted team
  DELETE FROM public.player_tournaments 
  WHERE tournament_id = OLD.tournament_id
    AND player_id IN (
      SELECT id FROM public.players WHERE email = OLD.player1_email
      UNION
      SELECT id FROM public.players WHERE email = OLD.player2_email
    );
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create the trigger
CREATE TRIGGER on_tournament_team_delete
  AFTER DELETE ON public.tournament_teams
  FOR EACH ROW
  EXECUTE FUNCTION public.cleanup_player_tournaments_on_team_delete();