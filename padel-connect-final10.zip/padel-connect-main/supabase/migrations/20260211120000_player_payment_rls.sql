-- Allow players to update their own payment status (and allow the app to confirm the team when both have paid)
-- This fixes cases where the UI "pays" but the update is blocked by RLS.

-- Ensure RLS is enabled (safe if already enabled)
alter table if exists public.tournament_teams enable row level security;

-- Drop existing policy if it exists (idempotent-ish)
drop policy if exists "Players can update own team payment" on public.tournament_teams;

create policy "Players can update own team payment"
on public.tournament_teams
for update
to authenticated
using (
  lower(coalesce(player1_email,'')) = lower(auth.jwt() ->> 'email')
  or lower(coalesce(player2_email,'')) = lower(auth.jwt() ->> 'email')
)
with check (
  lower(coalesce(player1_email,'')) = lower(auth.jwt() ->> 'email')
  or lower(coalesce(player2_email,'')) = lower(auth.jwt() ->> 'email')
);
