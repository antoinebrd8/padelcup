-- Refund policy configuration per tournament
-- Organiser can set a refund window like 24h/48h/etc before tournament start.

ALTER TABLE public.club_tournaments
  ADD COLUMN IF NOT EXISTS refund_deadline_hours integer DEFAULT 24,
  ADD COLUMN IF NOT EXISTS refund_policy_text text;

-- Backfill existing rows
UPDATE public.club_tournaments
SET refund_deadline_hours = COALESCE(refund_deadline_hours, 24);
