-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Players can register for tournaments" ON public.tournament_teams;

-- Create a more restrictive policy that validates the player exists
CREATE POLICY "Authenticated players can register for tournaments"
ON public.tournament_teams
FOR INSERT
TO authenticated
WITH CHECK (
  -- Ensure the user has a player profile
  EXISTS (
    SELECT 1 FROM players
    WHERE players.user_id = auth.uid()
  )
);