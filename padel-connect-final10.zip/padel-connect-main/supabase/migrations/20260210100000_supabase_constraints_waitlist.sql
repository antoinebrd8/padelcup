-- Constraints + triggers for production safety

-- 0) Add 'pending' to team_status enum if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_enum e
    JOIN pg_type t ON t.oid = e.enumtypid
    WHERE t.typname = 'team_status'
      AND e.enumlabel = 'pending'
  ) THEN
    ALTER TYPE public.team_status ADD VALUE 'pending';
  END IF;
END $$;

-- 1) Uniqueness inside a tournament
CREATE UNIQUE INDEX IF NOT EXISTS tournament_teams_unique_slot_position
  ON public.tournament_teams (tournament_id, slot_position)
  WHERE slot_position IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS tournament_teams_unique_seed_rank
  ON public.tournament_teams (tournament_id, seed_rank)
  WHERE seed_rank IS NOT NULL;

-- Prevent same email for both players
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tournament_teams_player_emails_distinct'
  ) THEN
    ALTER TABLE public.tournament_teams
      ADD CONSTRAINT tournament_teams_player_emails_distinct
      CHECK (
        player2_email IS NULL
        OR player1_email IS NULL
        OR lower(player1_email) <> lower(player2_email)
      );
  END IF;
END $$;

-- 2) Ensure the same player isn't linked twice to the same team
CREATE UNIQUE INDEX IF NOT EXISTS tournament_team_players_unique_team_player
  ON public.tournament_team_players (team_id, player_id);

-- 3) Enforce payment/status rules and max teams for confirmed registrations
CREATE OR REPLACE FUNCTION public.enforce_team_status_and_capacity()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  v_max_teams INTEGER;
  v_confirmed_count INTEGER;
  v_needs_two_payments BOOLEAN;
BEGIN
  -- Serialize capacity checks per tournament (avoids race conditions)
  SELECT max_teams
    INTO v_max_teams
  FROM public.club_tournaments
  WHERE id = NEW.tournament_id
  FOR UPDATE;

  v_needs_two_payments := (NEW.player2_name IS NOT NULL AND btrim(NEW.player2_name) <> '');

  -- Confirmed only if fully paid
  IF NEW.status = 'confirmed' THEN
    IF NEW.player1_payment_status IS DISTINCT FROM 'paid'
       OR (v_needs_two_payments AND NEW.player2_payment_status IS DISTINCT FROM 'paid') THEN
      NEW.status := 'pending';
    END IF;
  END IF;

  -- Max teams applies to confirmed only
  IF NEW.status = 'confirmed' AND v_max_teams IS NOT NULL THEN
    SELECT COUNT(*)
      INTO v_confirmed_count
    FROM public.tournament_teams
    WHERE tournament_id = NEW.tournament_id
      AND status = 'confirmed'
      AND id <> NEW.id;

    IF v_confirmed_count >= v_max_teams THEN
      NEW.status := 'waiting';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_enforce_team_status_and_capacity'
  ) THEN
    CREATE TRIGGER trg_enforce_team_status_and_capacity
      BEFORE INSERT OR UPDATE OF status, player1_payment_status, player2_payment_status, tournament_id
      ON public.tournament_teams
      FOR EACH ROW
      EXECUTE FUNCTION public.enforce_team_status_and_capacity();
  END IF;
END $$;

-- 4) Promote waitlist as pending after cancellation (needs payment)
CREATE OR REPLACE FUNCTION public.cancel_team_and_promote_waitlist(
  p_team_id UUID,
  p_player_id UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tournament_id UUID;
  v_start_at TIMESTAMPTZ;
  v_draw_locked BOOLEAN;
  v_team_player_ids UUID[];
  v_promote_team_id UUID;
BEGIN
  SELECT tt.tournament_id, ct.start_at, ct.draw_locked
    INTO v_tournament_id, v_start_at, v_draw_locked
  FROM public.tournament_teams tt
  JOIN public.club_tournaments ct ON ct.id = tt.tournament_id
  WHERE tt.id = p_team_id;

  IF v_tournament_id IS NULL THEN
    RAISE EXCEPTION 'team_not_found';
  END IF;

  IF v_draw_locked IS TRUE THEN
    RAISE EXCEPTION 'draw_locked';
  END IF;

  SELECT ARRAY_AGG(player_id)
    INTO v_team_player_ids
  FROM public.tournament_team_players
  WHERE team_id = p_team_id;

  IF v_team_player_ids IS NULL OR ARRAY_LENGTH(v_team_player_ids, 1) IS NULL THEN
    RAISE EXCEPTION 'team_players_not_found';
  END IF;

  IF NOT (p_player_id = ANY(v_team_player_ids)) THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  IF (v_start_at - NOW()) < INTERVAL '48 hours' THEN
    RAISE EXCEPTION 'too_late_to_cancel';
  END IF;

  DELETE FROM public.player_tournaments
  WHERE tournament_id = v_tournament_id
    AND player_id = ANY(v_team_player_ids);

  DELETE FROM public.tournament_teams WHERE id = p_team_id;

  SELECT id INTO v_promote_team_id
  FROM public.tournament_teams
  WHERE tournament_id = v_tournament_id
    AND status = 'waiting'
  ORDER BY created_at ASC
  LIMIT 1;

  IF v_promote_team_id IS NOT NULL THEN
    UPDATE public.tournament_teams
       SET status = 'pending',
           player1_payment_status = 'pending',
           player2_payment_status = 'pending'
     WHERE id = v_promote_team_id;
  END IF;
END;
$$;
