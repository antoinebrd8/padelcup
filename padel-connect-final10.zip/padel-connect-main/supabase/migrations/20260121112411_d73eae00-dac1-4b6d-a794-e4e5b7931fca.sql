-- Enum for tournament formats
CREATE TYPE public.tournament_format AS ENUM ('knockout', 'groups_knockout', 'round_robin', 'direct_entry');

-- Enum for draw size mode
CREATE TYPE public.draw_size_mode AS ENUM ('auto', 'manual');

-- Enum for team status
CREATE TYPE public.team_status AS ENUM ('confirmed', 'waiting');

-- Clubs table
CREATE TABLE public.clubs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  city TEXT,
  region TEXT,
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;

-- Clubs policies
CREATE POLICY "Users can view their own club" ON public.clubs
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own club" ON public.clubs
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own club" ON public.clubs
  FOR UPDATE USING (auth.uid() = user_id);

-- Club tournaments table
CREATE TABLE public.club_tournaments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  club_id UUID NOT NULL REFERENCES public.clubs(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  registration_deadline DATE,
  location TEXT,
  city TEXT,
  region TEXT,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  category_code TEXT,
  gender TEXT,
  max_teams INTEGER,
  price DECIMAL(10, 2),
  image_url TEXT,
  
  -- Tournament format settings
  format public.tournament_format NOT NULL DEFAULT 'knockout',
  draw_size_mode public.draw_size_mode NOT NULL DEFAULT 'auto',
  draw_size_manual INTEGER,
  
  -- Direct entry settings
  final_draw_size INTEGER,
  seeds_direct_count INTEGER DEFAULT 0,
  
  -- Groups settings
  group_size INTEGER DEFAULT 4,
  qualifiers_per_group INTEGER DEFAULT 2,
  
  -- Bye settings
  byes_priority_for_seeds BOOLEAN NOT NULL DEFAULT true,
  
  -- Draw state
  draw_generated BOOLEAN NOT NULL DEFAULT false,
  draw_locked BOOLEAN NOT NULL DEFAULT false,
  random_seed INTEGER,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.club_tournaments ENABLE ROW LEVEL SECURITY;

-- Club tournaments policies (club owners only)
CREATE POLICY "Club owners can view their tournaments" ON public.club_tournaments
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.clubs WHERE id = club_id AND user_id = auth.uid())
  );

CREATE POLICY "Club owners can create tournaments" ON public.club_tournaments
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.clubs WHERE id = club_id AND user_id = auth.uid())
  );

CREATE POLICY "Club owners can update their tournaments" ON public.club_tournaments
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.clubs WHERE id = club_id AND user_id = auth.uid())
  );

CREATE POLICY "Club owners can delete their tournaments" ON public.club_tournaments
  FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.clubs WHERE id = club_id AND user_id = auth.uid())
  );

-- Teams/participants table
CREATE TABLE public.tournament_teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.club_tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  player1_name TEXT NOT NULL,
  player1_email TEXT,
  player2_name TEXT,
  player2_email TEXT,
  seed_rank INTEGER,
  status public.team_status NOT NULL DEFAULT 'confirmed',
  slot_position INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tournament_teams ENABLE ROW LEVEL SECURITY;

-- Teams policies
CREATE POLICY "Club owners can view their tournament teams" ON public.tournament_teams
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can manage tournament teams" ON public.tournament_teams
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can update tournament teams" ON public.tournament_teams
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can delete tournament teams" ON public.tournament_teams
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

-- Groups table (for group stage)
CREATE TABLE public.tournament_groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.club_tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  group_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tournament_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Club owners can manage groups" ON public.tournament_groups
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

-- Group teams (assignment of teams to groups)
CREATE TABLE public.group_teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_id UUID NOT NULL REFERENCES public.tournament_groups(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES public.tournament_teams(id) ON DELETE CASCADE,
  points INTEGER NOT NULL DEFAULT 0,
  matches_played INTEGER NOT NULL DEFAULT 0,
  matches_won INTEGER NOT NULL DEFAULT 0,
  matches_lost INTEGER NOT NULL DEFAULT 0,
  sets_won INTEGER NOT NULL DEFAULT 0,
  sets_lost INTEGER NOT NULL DEFAULT 0,
  games_won INTEGER NOT NULL DEFAULT 0,
  games_lost INTEGER NOT NULL DEFAULT 0,
  ranking_position INTEGER,
  UNIQUE(group_id, team_id)
);

-- Enable RLS
ALTER TABLE public.group_teams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Club owners can manage group teams" ON public.group_teams
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.tournament_groups tg
      JOIN public.club_tournaments ct ON ct.id = tg.tournament_id
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE tg.id = group_id AND c.user_id = auth.uid()
    )
  );

-- Matches table
CREATE TABLE public.tournament_matches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.club_tournaments(id) ON DELETE CASCADE,
  group_id UUID REFERENCES public.tournament_groups(id) ON DELETE CASCADE,
  round_name TEXT NOT NULL,
  round_order INTEGER NOT NULL DEFAULT 0,
  match_order INTEGER NOT NULL DEFAULT 0,
  team_a_id UUID REFERENCES public.tournament_teams(id) ON DELETE SET NULL,
  team_b_id UUID REFERENCES public.tournament_teams(id) ON DELETE SET NULL,
  is_bye BOOLEAN NOT NULL DEFAULT false,
  score_a TEXT,
  score_b TEXT,
  winner_id UUID REFERENCES public.tournament_teams(id) ON DELETE SET NULL,
  next_match_id UUID REFERENCES public.tournament_matches(id) ON DELETE SET NULL,
  slot_index INTEGER,
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tournament_matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Club owners can view matches" ON public.tournament_matches
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can manage matches" ON public.tournament_matches
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can update matches" ON public.tournament_matches
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Club owners can delete matches" ON public.tournament_matches
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.club_tournaments ct
      JOIN public.clubs c ON c.id = ct.club_id
      WHERE ct.id = tournament_id AND c.user_id = auth.uid()
    )
  );

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Triggers for updated_at
CREATE TRIGGER update_clubs_updated_at
  BEFORE UPDATE ON public.clubs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_club_tournaments_updated_at
  BEFORE UPDATE ON public.club_tournaments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tournament_teams_updated_at
  BEFORE UPDATE ON public.tournament_teams
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tournament_matches_updated_at
  BEFORE UPDATE ON public.tournament_matches
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();