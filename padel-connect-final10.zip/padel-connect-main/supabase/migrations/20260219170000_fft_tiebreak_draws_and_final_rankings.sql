-- FFT P25 -> P500
-- Persist "tirage au sort" orders for unresolved pool ties
-- and allow organizers to store final rankings / points overrides.

create table if not exists public.tournament_tiebreak_draws (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null,
  group_label text not null default 'GLOBAL',
  tie_key text not null,
  order_team_ids uuid[] not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tournament_id, group_label, tie_key)
);

create index if not exists tournament_tiebreak_draws_tournament_id_idx
  on public.tournament_tiebreak_draws (tournament_id);

create table if not exists public.tournament_final_rankings (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null,
  team_id uuid not null,
  final_rank integer not null,
  points_per_player integer not null default 0,
  reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tournament_id, team_id)
);

create index if not exists tournament_final_rankings_tournament_id_idx
  on public.tournament_final_rankings (tournament_id);
